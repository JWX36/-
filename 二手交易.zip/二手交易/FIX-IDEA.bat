@echo off
cd /d "%~dp0"
echo ==========================================================
echo  Fix IntelliJ IDEA SDK for this project (JDK 21)
echo.
echo  IMPORTANT: close IntelliJ IDEA completely BEFORE running.
echo  Otherwise IDEA will overwrite these settings on exit.
echo ==========================================================
pause
python fix_idea_sdk.py
echo.
echo Done. Now reopen the project in IntelliJ IDEA.
pause
