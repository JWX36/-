package com.example.demo.dto;

import java.io.Serializable;
import javax.validation.constraints.*;

/**
 * 分页请求基类，供各列表页复用。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class PageQuery implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 页码，从 1 开始 */
    @Min(value = 1, message = "页码必须大于 0")
    private Integer pageNum = 1;

    /** 每页条数 */
    @Min(value = 1, message = "每页条数必须大于 0")
    @Max(value = 100, message = "每页最多 100 条")
    private Integer pageSize = 10;

    /** 获取页码，从 1 开始 */
    public Integer getPageNum() {
        return pageNum;
    }

    /** 设置页码，从 1 开始 */
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    /** 获取每页条数 */
    public Integer getPageSize() {
        return pageSize;
    }

    /** 设置每页条数 */
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

}
