package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.ChatSession;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 客服会话数据访问层：会话列表的多表关联查询见 mapper/ChatSessionMapper.xml。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface ChatSessionMapper extends BaseMapper<ChatSession> {

    /** 我参与的会话列表：带出物品信息、对方昵称头像、当前用户未读数 */
    List<ChatSession> selectMine(@Param("userId") Long userId);

    /** 全站会话列表（管理员监管）：带买卖双方昵称、商品信息与消息条数 */
    List<ChatSession> selectAll();
}
