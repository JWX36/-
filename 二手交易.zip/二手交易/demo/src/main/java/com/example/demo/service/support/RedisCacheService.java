package com.example.demo.service.support;

import com.example.demo.util.CacheJson;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * Redis 缓存实现（进阶/高阶必选考点）。
 * 将 app.feature.redis-enabled 置为 true 并启动 Redis 后自动生效。
 * 采用「缓存空值 + TTL 随机抖动 + setIfAbsent 互斥」缓解穿透、雪崩与击穿问题。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
@ConditionalOnProperty(prefix = "app.feature", name = "redis-enabled", havingValue = "true")
public class RedisCacheService implements CacheService {

    private final StringRedisTemplate redisTemplate;

    public RedisCacheService(StringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public <T> T get(String key, Class<T> type) {
        return CacheJson.read(redisTemplate.opsForValue().get(key), type);
    }

    @Override
    public <T> T get(String key, TypeReference<T> type) {
        return CacheJson.read(redisTemplate.opsForValue().get(key), type);
    }

    /** 写入时增加 0~30 秒随机抖动，避免大量热点 key 同时过期导致雪崩 */
    @Override
    public void set(String key, Object value, long ttlSeconds) {
        long ttl = Math.max(1L, ttlSeconds) + (long) (Math.random() * 30);
        redisTemplate.opsForValue().set(key, CacheJson.write(value), ttl, TimeUnit.SECONDS);
    }

    @Override
    public void delete(String key) {
        redisTemplate.delete(key);
    }

    @Override
    public boolean exists(String key) {
        return Boolean.TRUE.equals(redisTemplate.hasKey(key));
    }

    /** Redis 原生 SETNX 语义，用于幂等键与缓存击穿互斥锁 */
    @Override
    public boolean setIfAbsent(String key, Object value, long ttlSeconds) {
        return Boolean.TRUE.equals(redisTemplate.opsForValue()
                .setIfAbsent(key, CacheJson.write(value), Math.max(1L, ttlSeconds), TimeUnit.SECONDS));
    }
}
