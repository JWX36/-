package com.example.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.dto.OrderForm;
import com.example.demo.dto.PageQuery;
import com.example.demo.entity.TradeOrder;

import java.util.Map;

/**
 * 订单模块业务接口：下单（幂等 + 防超卖）、模拟支付、确认交易、取消与超时自动取消。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface TradeOrderService {

    /** 创建订单：幂等键防重复提交、库存条件扣减防超卖 */
    TradeOrder create(Long buyerId, OrderForm form);

    /** 模拟支付：待支付 → 已支付待确认 */
    void pay(Long orderId, Long buyerId);

    /** 买家确认交易：已支付待确认 → 已完成 */
    void confirm(Long orderId, Long userId);

    /** 取消订单并恢复库存 */
    void cancel(Long orderId, Long userId, String reason);

    /** 订单分页：买家 / 卖家 / 后台共用 */
    IPage<TradeOrder> pageOrders(PageQuery query, Long buyerId, Long sellerId, Integer status);

    /**
     * 按买家 / 卖家视角统计指定状态的订单数。
     * 用于导航栏「待支付」红点、订单中心状态分组数字，不受通知已读状态影响，实时反映待办。
     */
    long countByStatus(Long buyerId, Long sellerId, Integer status);

    /** 一次返回 0~5 各状态订单数，避免订单中心重复查库；key 为订单状态码 */
    Map<Integer, Long> countGroupByStatus(Long buyerId, Long sellerId);

    /** 订单详情（带数据归属校验，防水平越权） */
    TradeOrder detail(Long id, Long userId, boolean admin);

    /** 定时任务：取消超时未支付订单，返回处理条数 */
    int cancelTimeoutOrders(int minutes);
}
