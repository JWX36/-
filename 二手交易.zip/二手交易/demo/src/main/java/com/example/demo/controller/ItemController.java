package com.example.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.dto.ItemForm;
import com.example.demo.dto.ItemQuery;
import com.example.demo.dto.MessageForm;
import com.example.demo.dto.OrderForm;
import com.example.demo.entity.Item;
import com.example.demo.entity.User;
import com.example.demo.service.ChatService;
import com.example.demo.service.FavoriteService;
import com.example.demo.service.ItemService;
import com.example.demo.service.MessageService;
import com.example.demo.util.PageUrl;
import com.example.demo.util.UserContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * 物品模块页面控制器：检索列表、详情与留言、发布/编辑/下架、我的发布。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
public class ItemController {

    private final ItemService itemService;
    private final MessageService messageService;
    private final FavoriteService favoriteService;
    private final ChatService chatService;
    private final UserContext userContext;

    public ItemController(ItemService itemService, MessageService messageService,
                          FavoriteService favoriteService, ChatService chatService,
                          UserContext userContext) {
        this.itemService = itemService;
        this.messageService = messageService;
        this.favoriteService = favoriteService;
        this.chatService = chatService;
        this.userContext = userContext;
    }

    /** 物品列表：关键词、分类、价格区间、排序、分页 */
    @GetMapping({"/items", "/items/list", "/search"})
    public String list(ItemQuery query, Model model) {
        model.addAttribute("items", itemService.search(query, 1));
        model.addAttribute("query", query);
        model.addAttribute("pageBase", PageUrl.build("/items/list",
                "keyword", query.getKeyword(), "categoryId", query.getCategoryId(),
                "minPrice", query.getMinPrice(), "maxPrice", query.getMaxPrice(),
                "sortBy", query.getSortBy()));
        return "items/list";
    }

    /**
     * 详情页（淘宝式商品页）：多图轮播图集、卖家客服、购买区、评价登录门禁、
     * 「看了又看」推荐购买、收藏/想要人数。
     */
    @GetMapping("/items/detail/{id}")
    public String detail(@PathVariable("id") Long id, Model model) {
        User user = userContext.currentUserOrNull();
        Long userId = user == null ? null : user.getId();
        Item item = itemService.detail(id, userId);
        boolean owner = userId != null && item.getSellerId().equals(userId);
        boolean loggedIn = userId != null;

        model.addAttribute("item", item);
        model.addAttribute("isOwner", owner);
        // 评价（留言）内容登录后可见；未登录只展示条数与登录引导
        model.addAttribute("commentsVisible", loggedIn);
        model.addAttribute("commentCount", messageService.countByItem(id));
        model.addAttribute("messages", loggedIn ? messageService.listByItem(id) : Collections.emptyList());
        // 「大家都在问」：该商品所有客服咨询消息，买家 / 卖家 / 管理员登录后均可见
        model.addAttribute("publicQuestions",
                loggedIn ? chatService.publicMessagesByItem(id) : Collections.emptyList());
        MessageForm messageForm = new MessageForm();
        messageForm.setItemId(id);
        model.addAttribute("messageForm", messageForm);

        OrderForm orderForm = new OrderForm();
        orderForm.setItemId(id);
        orderForm.setQuantity(1);
        orderForm.setRequestNo(UUID.randomUUID().toString());
        model.addAttribute("orderForm", orderForm);
        model.addAttribute("quickQuestions", java.util.Arrays.asList(
                "这个宝贝还在吗？可以校内面交吗？",
                "能再便宜一点吗？",
                "成色怎么样？方便发一下实拍图吗？"));

        // 推荐购买：同分类优先 + 价格接近 + 热度排序（结果缓存 120 秒）
        model.addAttribute("recommendItems",
                itemService.recommend(id, item.getCategoryId(), item.getPrice(), 6));
        model.addAttribute("favoriteCount", favoriteService.countByItem(id));
        model.addAttribute("favorited", loggedIn && favoriteService.isFavorite(userId, id));
        return "items/detail";
    }

    /**
     * 「查看全部评价」登录门禁。
     * 该路径在 SecurityConfig 中要求登录：未登录访问会被 Spring Security 保存请求并跳转登录页，
     * 登录成功后自动跳回这里，再重定向到详情页评价区，体验与淘宝「登录后查看评价」一致。
     */
    @GetMapping("/items/comments/{id}")
    public String comments(@PathVariable("id") Long id) {
        return "redirect:/items/detail/" + id + "#comments";
    }

    /** 发布页 */
    @GetMapping("/items/publish")
    public String publishForm(Model model) {
        if (!model.containsAttribute("itemForm")) {
            model.addAttribute("itemForm", new ItemForm());
        }
        model.addAttribute("editing", false);
        return "items/form";
    }

    /** 编辑页：把实体转换成表单对象回填 */
    @GetMapping("/items/edit/{id}")
    public String editForm(@PathVariable("id") Long id, Model model) {
        Item item = itemService.detail(id, null);
        ItemForm form = new ItemForm();
        form.setItemId(item.getId());
        form.setTitle(item.getTitle());
        form.setCategoryId(item.getCategoryId());
        form.setPrice(item.getPrice());
        form.setOriginalPrice(item.getOriginalPrice());
        form.setCampusZone(item.getCampusZone());
        form.setDescription(item.getDescription());
        form.setStock(item.getStock());
        model.addAttribute("itemForm", form);
        model.addAttribute("editing", true);
        return "items/form";
    }

    /** 保存（新增或修改）：支持多图上传，表单校验失败回填表单页 */
    @PostMapping("/items/save")
    public String save(@Valid @ModelAttribute("itemForm") ItemForm form,
                       BindingResult bindingResult,
                       @RequestParam(value = "images", required = false) MultipartFile[] images,
                       Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("errorMessage", bindingResult.getFieldError() == null
                    ? "请检查表单填写" : bindingResult.getFieldError().getDefaultMessage());
            model.addAttribute("editing", form.getItemId() != null);
            return "items/form";
        }
        Long userId = userContext.currentUserId();
        try {
            if (form.getItemId() == null) {
                itemService.publish(userId, form, images);
            } else {
                itemService.update(form.getItemId(), userId, form, images);
            }
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("editing", form.getItemId() != null);
            return "items/form";
        }
        return "redirect:/items/mine";
    }

    /** 下架自己的物品 */
    @PostMapping("/items/off-shelf/{id}")
    public String offShelf(@PathVariable("id") Long id) {
        itemService.offShelf(id, userContext.currentUserId(), false);
        return "redirect:/items/mine";
    }

    /** 我发布的物品（所有状态）：额外统计每件商品的实拍图张数 */
    @GetMapping("/items/mine")
    public String mine(ItemQuery query, Model model) {
        query.setSellerId(userContext.currentUserId());
        IPage<Item> page = itemService.search(query, null);
        List<Long> itemIds = page.getRecords().stream().map(Item::getId).collect(Collectors.toList());
        Map<Long, Integer> counts = itemService.imageCounts(itemIds);
        model.addAttribute("items", page);
        model.addAttribute("imageCounts", counts);
        model.addAttribute("maxImages", itemService.maxImagesPerItem());
        model.addAttribute("onSaleCount", page.getRecords().stream()
                .filter(it -> it.getStatus() != null && it.getStatus() == 1).count());
        model.addAttribute("totalImages", counts.values().stream().mapToInt(Integer::intValue).sum());
        model.addAttribute("query", query);
        model.addAttribute("pageBase", PageUrl.build("/items/mine", "sortBy", query.getSortBy()));
        return "items/mine";
    }

    /* ==================== 卖家商品图片管理：查看 / 追加 / 删除 / 设封面 ==================== */

    /** 打开某件已发布商品的图片管理页（只限本人） */
    @GetMapping("/items/images/{id}")
    public String imageManager(@PathVariable("id") Long id, Model model) {
        Long userId = userContext.currentUserId();
        model.addAttribute("item", itemService.ownedItem(id, userId));
        model.addAttribute("images", itemService.ownedImages(id, userId));
        model.addAttribute("maxImages", itemService.maxImagesPerItem());
        return "items/images";
    }

    /** 为已存在的商品继续追加实拍图，追加后详情页自动轮播立即生效 */
    @PostMapping("/items/images/{id}/add")
    public String addImages(@PathVariable("id") Long id,
                            @RequestParam(value = "images", required = false) MultipartFile[] images,
                            RedirectAttributes redirectAttributes) {
        try {
            int count = itemService.appendImages(id, userContext.currentUserId(), images);
            redirectAttributes.addFlashAttribute("successMessage",
                    "已追加 " + count + " 张实拍图，商品详情页会自动轮播展示");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/items/images/" + id;
    }

    /** 删除自己商品的一张图片（至少保留 1 张） */
    @PostMapping("/items/images/{id}/delete/{imageId}")
    public String deleteImage(@PathVariable("id") Long id, @PathVariable("imageId") Long imageId,
                              RedirectAttributes redirectAttributes) {
        try {
            itemService.removeImage(id, imageId, userContext.currentUserId());
            redirectAttributes.addFlashAttribute("successMessage", "图片已删除，轮播顺序已自动更新");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/items/images/" + id;
    }

    /** 把某张图片设为商品封面（首页卡片、推荐位与轮播首图同步更新） */
    @PostMapping("/items/images/{id}/cover/{imageId}")
    public String setCover(@PathVariable("id") Long id, @PathVariable("imageId") Long imageId,
                           RedirectAttributes redirectAttributes) {
        try {
            itemService.markCover(id, imageId, userContext.currentUserId());
            redirectAttributes.addFlashAttribute("successMessage", "已设为商品封面");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/items/images/" + id;
    }
}
