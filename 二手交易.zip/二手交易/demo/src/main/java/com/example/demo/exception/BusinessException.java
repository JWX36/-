package com.example.demo.exception;

import com.example.demo.common.ResultCode;

/**
 * 自定义业务异常：Service 层校验不通过时抛出，由全局异常处理器统一转成提示信息或 JSON。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class BusinessException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /** 业务状态码 */
    private final int code;

    public BusinessException(String message) {
        super(message);
        this.code = ResultCode.BUSINESS_ERROR;
    }

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
