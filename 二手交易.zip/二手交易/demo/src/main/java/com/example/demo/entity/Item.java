package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 闲置物品实体，对应 tb_item。状态机：0 待审核 → 1 在售 → 3 已售出 / 2 已下架 / 4 违规下架。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_item")
public class Item implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 卖家用户 ID */
    private Long sellerId;

    /** 分类 ID */
    private Long categoryId;

    /** 物品标题 */
    private String title;

    /** 物品描述 */
    private String description;

    /** 当前售价 */
    private BigDecimal price;

    /** 原价 / 入手价 */
    private BigDecimal originalPrice;

    /** 封面图访问路径 */
    private String coverImage;

    /** 交易校区 / 自提地点 */
    private String campusZone;

    /** 库存数量（默认 1 件） */
    private Integer stock;

    /** 状态：0 待审核 1 在售 2 已下架 3 已售出 4 违规下架 */
    private Integer status;

    /** 浏览量 */
    private Integer viewCount;

    /** 审核驳回原因（违规下架原因） */
    private String rejectReason;

    /** 下架时间，定时任务据此清理过期物品 */
    private LocalDateTime offShelfTime;

    /** 发布时间 */
    private LocalDateTime createTime;

    /** 更新时间 */
    private LocalDateTime updateTime;

    /** 非数据库字段：卖家昵称（关联查询） */
    @TableField(exist = false)
    private String sellerName;

    /** 非数据库字段：卖家头像（关联查询） */
    @TableField(exist = false)
    private String sellerAvatar;

    /** 非数据库字段：分类名称（关联查询） */
    @TableField(exist = false)
    private String categoryName;

    /** 非数据库字段：物品图集（关联查询） */
    @TableField(exist = false)
    private List<String> imageList;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取卖家用户 ID */
    public Long getSellerId() {
        return sellerId;
    }

    /** 设置卖家用户 ID */
    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    /** 获取分类 ID */
    public Long getCategoryId() {
        return categoryId;
    }

    /** 设置分类 ID */
    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    /** 获取物品标题 */
    public String getTitle() {
        return title;
    }

    /** 设置物品标题 */
    public void setTitle(String title) {
        this.title = title;
    }

    /** 获取物品描述 */
    public String getDescription() {
        return description;
    }

    /** 设置物品描述 */
    public void setDescription(String description) {
        this.description = description;
    }

    /** 获取当前售价 */
    public BigDecimal getPrice() {
        return price;
    }

    /** 设置当前售价 */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /** 获取原价 / 入手价 */
    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    /** 设置原价 / 入手价 */
    public void setOriginalPrice(BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    /** 获取封面图访问路径 */
    public String getCoverImage() {
        return coverImage;
    }

    /** 设置封面图访问路径 */
    public void setCoverImage(String coverImage) {
        this.coverImage = coverImage;
    }

    /** 获取交易校区 / 自提地点 */
    public String getCampusZone() {
        return campusZone;
    }

    /** 设置交易校区 / 自提地点 */
    public void setCampusZone(String campusZone) {
        this.campusZone = campusZone;
    }

    /** 获取库存数量（默认 1 件） */
    public Integer getStock() {
        return stock;
    }

    /** 设置库存数量（默认 1 件） */
    public void setStock(Integer stock) {
        this.stock = stock;
    }

    /** 获取状态：0 待审核 1 在售 2 已下架 3 已售出 4 违规下架 */
    public Integer getStatus() {
        return status;
    }

    /** 设置状态：0 待审核 1 在售 2 已下架 3 已售出 4 违规下架 */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /** 获取浏览量 */
    public Integer getViewCount() {
        return viewCount;
    }

    /** 设置浏览量 */
    public void setViewCount(Integer viewCount) {
        this.viewCount = viewCount;
    }

    /** 获取审核驳回原因（违规下架原因） */
    public String getRejectReason() {
        return rejectReason;
    }

    /** 设置审核驳回原因（违规下架原因） */
    public void setRejectReason(String rejectReason) {
        this.rejectReason = rejectReason;
    }

    /** 获取下架时间，定时任务据此清理过期物品 */
    public LocalDateTime getOffShelfTime() {
        return offShelfTime;
    }

    /** 设置下架时间，定时任务据此清理过期物品 */
    public void setOffShelfTime(LocalDateTime offShelfTime) {
        this.offShelfTime = offShelfTime;
    }

    /** 获取发布时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置发布时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    /** 获取更新时间 */
    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    /** 设置更新时间 */
    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    /** 获取非数据库字段：卖家昵称（关联查询） */
    public String getSellerName() {
        return sellerName;
    }

    /** 设置非数据库字段：卖家昵称（关联查询） */
    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    /** 获取非数据库字段：卖家头像（关联查询） */
    public String getSellerAvatar() {
        return sellerAvatar;
    }

    /** 设置非数据库字段：卖家头像（关联查询） */
    public void setSellerAvatar(String sellerAvatar) {
        this.sellerAvatar = sellerAvatar;
    }

    /** 获取非数据库字段：分类名称（关联查询） */
    public String getCategoryName() {
        return categoryName;
    }

    /** 设置非数据库字段：分类名称（关联查询） */
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    /** 获取非数据库字段：物品图集（关联查询） */
    public List<String> getImageList() {
        return imageList;
    }

    /** 设置非数据库字段：物品图集（关联查询） */
    public void setImageList(List<String> imageList) {
        this.imageList = imageList;
    }

}
