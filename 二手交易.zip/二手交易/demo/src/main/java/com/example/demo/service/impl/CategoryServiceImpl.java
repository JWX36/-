package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.dto.CategoryForm;
import com.example.demo.dto.PageQuery;
import com.example.demo.entity.Category;
import com.example.demo.entity.Item;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.CategoryMapper;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.service.CategoryService;
import com.example.demo.service.support.CacheService;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 分类模块业务实现：分类列表是典型的读多写少数据，使用缓存并采用 Cache-Aside 模式。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class CategoryServiceImpl implements CategoryService {

    /** 全部分类缓存 key */
    public static final String CACHE_KEY = "category:all";

    private final CategoryMapper categoryMapper;
    private final ItemMapper itemMapper;
    private final CacheService cacheService;

    public CategoryServiceImpl(CategoryMapper categoryMapper, ItemMapper itemMapper, CacheService cacheService) {
        this.categoryMapper = categoryMapper;
        this.itemMapper = itemMapper;
        this.cacheService = cacheService;
    }

    /** 先读缓存，未命中回源数据库并回填；空结果同样写入缓存，防止缓存穿透 */
    @Override
    public List<Category> listAll() {
        List<Category> cached = cacheService.get(CACHE_KEY, new TypeReference<List<Category>>() {
        });
        if (cached != null) {
            return cached;
        }
        List<Category> list = categoryMapper.selectList(new LambdaQueryWrapper<Category>()
                .eq(Category::getStatus, 1)
                .orderByAsc(Category::getSortNo, Category::getId));
        cacheService.set(CACHE_KEY, list, 3600);
        return list;
    }

    @Override
    public IPage<Category> pageCategories(PageQuery query) {
        Page<Category> page = new Page<>(query.getPageNum(), query.getPageSize());
        return categoryMapper.selectPage(page, new LambdaQueryWrapper<Category>()
                .orderByAsc(Category::getSortNo, Category::getId));
    }

    @Override
    public Category getById(Long id) {
        Category category = categoryMapper.selectById(id);
        if (category == null) {
            throw new BusinessException("分类不存在");
        }
        return category;
    }

    @Override
    public void save(CategoryForm form) {
        Category category = new Category();
        category.setName(form.getName());
        category.setSortNo(form.getSortNo());
        category.setStatus(form.getStatus());
        category.setCreateTime(LocalDateTime.now());
        categoryMapper.insert(category);
        cacheService.delete(CACHE_KEY);
    }

    @Override
    public void update(Long id, CategoryForm form) {
        Category category = getById(id);
        category.setName(form.getName());
        category.setSortNo(form.getSortNo());
        category.setStatus(form.getStatus());
        categoryMapper.updateById(category);
        cacheService.delete(CACHE_KEY);
    }

    /** 存在关联物品时拒绝物理删除，避免产生孤儿数据 */
    @Override
    public void remove(Long id) {
        getById(id);
        Long count = itemMapper.selectCount(new LambdaQueryWrapper<Item>().eq(Item::getCategoryId, id));
        if (count != null && count > 0) {
            throw new BusinessException("该分类下仍有物品，请先转移或删除物品");
        }
        categoryMapper.deleteById(id);
        cacheService.delete(CACHE_KEY);
    }
}
