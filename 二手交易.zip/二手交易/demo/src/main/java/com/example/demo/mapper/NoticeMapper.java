package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.Notice;

/**
 * 站内通知数据访问层。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface NoticeMapper extends BaseMapper<Notice> {
}
