package com.example.demo.service.impl;

import com.example.demo.dto.MessageForm;
import com.example.demo.entity.Item;
import com.example.demo.entity.Message;
import com.example.demo.entity.User;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.mapper.MessageMapper;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.MessageService;
import com.example.demo.service.support.EventPublisher;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 留言模块业务实现：主留言提醒发布者，回复提醒被回复人，全部通过事件异步解耦。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class MessageServiceImpl implements MessageService {

    private final MessageMapper messageMapper;
    private final ItemMapper itemMapper;
    private final UserMapper userMapper;
    private final EventPublisher eventPublisher;

    public MessageServiceImpl(MessageMapper messageMapper, ItemMapper itemMapper,
                              UserMapper userMapper, EventPublisher eventPublisher) {
        this.messageMapper = messageMapper;
        this.itemMapper = itemMapper;
        this.userMapper = userMapper;
        this.eventPublisher = eventPublisher;
    }

    /** 发表留言/回复：自动确定接收人，发布 message.created 事件触发邮件+站内通知 */
    @Override
    public void leave(Long senderId, MessageForm form) {
        Item item = itemMapper.selectById(form.getItemId());
        if (item == null) {
            throw new BusinessException("物品不存在");
        }
        Long parentId = form.getParentId() == null ? 0L : form.getParentId();
        Long receiverId = item.getSellerId();
        if (parentId != null && parentId > 0) {
            Message parent = messageMapper.selectById(parentId);
            if (parent == null) {
                throw new BusinessException("被回复的留言不存在");
            }
            // 回复给原留言人；若回复自己，仍提醒物品发布者
            receiverId = parent.getSenderId().equals(senderId) ? item.getSellerId() : parent.getSenderId();
        }
        Message message = new Message();
        message.setItemId(item.getId());
        message.setSenderId(senderId);
        message.setReceiverId(receiverId);
        message.setParentId(parentId);
        message.setContent(form.getContent());
        message.setRating(form.getRating() == null || form.getRating() < 1 || form.getRating() > 5
                ? 5 : form.getRating());
        message.setIsRead(0);
        message.setCreateTime(LocalDateTime.now());
        messageMapper.insert(message);

        if (!receiverId.equals(senderId)) {
            User sender = userMapper.selectById(senderId);
            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("receiverId", receiverId);
            payload.put("senderName", sender == null ? "某位同学" : sender.getRealName());
            payload.put("itemTitle", item.getTitle());
            payload.put("content", form.getContent());
            eventPublisher.publish("message.created", payload);
        }
    }

    @Override
    public List<Message> listByItem(Long itemId) {
        return messageMapper.selectItemMessages(itemId);
    }

    @Override
    public List<Message> listMine(Long userId) {
        return messageMapper.selectUserMessages(userId);
    }

    @Override
    public long countByItem(Long itemId) {
        return messageMapper.selectCount(new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Message>()
                .eq(Message::getItemId, itemId));
    }
}
