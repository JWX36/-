package com.example.demo.service;

import java.util.Map;

/**
 * 数据看板业务接口：概览指标与 ECharts 图表数据。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface DashboardService {

    /** 平台概览指标 */
    Map<String, Object> summary();

    /** 近 days 天的交易金额、用户增长、分类占比图表数据 */
    Map<String, Object> charts(int days);
}
