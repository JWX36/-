package com.example.demo.controller;

import com.example.demo.dto.PasswordForm;
import com.example.demo.dto.ProfileForm;
import com.example.demo.entity.User;
import com.example.demo.service.FavoriteService;
import com.example.demo.service.UserService;
import com.example.demo.service.support.FileStorageService;
import com.example.demo.service.support.NotificationService;
import com.example.demo.util.UserContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;

/**
 * 个人中心：资料修改、密码修改、头像上传、站内通知。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
public class UserController {

    private final UserService userService;
    private final FileStorageService fileStorageService;
    private final NotificationService notificationService;
    private final FavoriteService favoriteService;
    private final UserContext userContext;

    public UserController(UserService userService, FileStorageService fileStorageService,
                          NotificationService notificationService, FavoriteService favoriteService,
                          UserContext userContext) {
        this.userService = userService;
        this.fileStorageService = fileStorageService;
        this.notificationService = notificationService;
        this.favoriteService = favoriteService;
        this.userContext = userContext;
    }

    /** 个人中心页面：回填资料，准备两个表单对象 */
    @GetMapping("/user/profile")
    public String profile(Model model) {
        User user = userService.getById(userContext.currentUserId());
        if (!model.containsAttribute("profileForm")) {
            ProfileForm form = new ProfileForm();
            form.setRealName(user.getRealName());
            form.setEmail(user.getEmail());
            form.setPhone(user.getPhone());
            model.addAttribute("profileForm", form);
        }
        if (!model.containsAttribute("passwordForm")) {
            model.addAttribute("passwordForm", new PasswordForm());
        }
        model.addAttribute("profile", user);
        model.addAttribute("browseHistory", java.util.Collections.emptyList());
        return "user/profile";
    }

    /** 保存个人资料 */
    @PostMapping("/user/profile")
    public String saveProfile(@Valid @ModelAttribute("profileForm") ProfileForm form,
                              BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("errorMessage", bindingResult.getFieldError().getDefaultMessage());
            return profile(model);
        }
        userService.updateProfile(userContext.currentUserId(), form);
        return "redirect:/user/profile?updated";
    }

    /** 修改密码 */
    @PostMapping("/user/password")
    public String changePassword(@Valid @ModelAttribute("passwordForm") PasswordForm form,
                                 BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("errorMessage", bindingResult.getFieldError().getDefaultMessage());
            return profile(model);
        }
        try {
            userService.changePassword(userContext.currentUserId(), form);
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return profile(model);
        }
        return "redirect:/user/profile?pwdUpdated";
    }

    /** 头像上传 */
    @PostMapping("/user/avatar")
    public String uploadAvatar(@RequestParam(value = "avatar", required = false) MultipartFile avatar,
                               Model model) {
        try {
            String url = fileStorageService.store(avatar, "avatars");
            if (url == null) {
                model.addAttribute("errorMessage", "请选择要上传的头像图片");
                return profile(model);
            }
            userService.updateAvatar(userContext.currentUserId(), url);
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return profile(model);
        }
        return "redirect:/user/profile?avatarUpdated";
    }

    /** 我的收藏 / 想要的宝贝 */
    @GetMapping("/user/favorites")
    public String favorites(Model model) {
        model.addAttribute("favorites", favoriteService.listMine(userContext.currentUserId()));
        return "user/favorites";
    }

    /** 我的站内通知 */
    @GetMapping("/notices")
    public String notices(Model model) {
        Long userId = userContext.currentUserId();
        List<?> notices = notificationService.listMine(userId);
        model.addAttribute("notices", notices);
        return "user/notices";
    }

    /** 一键已读 */
    @PostMapping("/notices/read")
    public String markRead() {
        notificationService.markAllRead(userContext.currentUserId());
        return "redirect:/notices";
    }
}
