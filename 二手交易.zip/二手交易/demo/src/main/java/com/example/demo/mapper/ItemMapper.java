package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.dto.ItemQuery;
import com.example.demo.entity.Item;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

/**
 * 物品数据访问层：分页动态 SQL、多表关联详情、浏览量自增均定义在 mapper/ItemMapper.xml。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface ItemMapper extends BaseMapper<Item> {

    /** 多条件分页检索（动态 SQL + 关联用户表、分类表） */
    IPage<Item> searchPage(IPage<Item> page, @Param("q") ItemQuery query);

    /** 物品详情关联卖家昵称、头像与分类名称 */
    Item selectDetail(@Param("id") Long id);

    /** 浏览量自增，使用数据库原子更新避免并发丢失 */
    int incrementViewCount(@Param("id") Long id);

    /** 扣减库存（下单），带库存条件防止超卖 */
    int deductStock(@Param("id") Long id, @Param("quantity") int quantity);

    /** 恢复库存（订单取消 / 超时取消） */
    int restoreStock(@Param("id") Long id, @Param("quantity") int quantity);

    /** 详情页推荐购买：同分类优先、价格接近、浏览量高者靠前 */
    List<Item> selectRecommend(@Param("itemId") Long itemId,
                               @Param("categoryId") Long categoryId,
                               @Param("price") BigDecimal price,
                               @Param("limit") int limit);
}
