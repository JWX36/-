package com.example.demo.service.support;

import com.fasterxml.jackson.core.type.TypeReference;

/**
 * 缓存抽象接口（多级缓存体系考点）。
 * 默认演示环境使用进程内实现；把 app.feature.redis-enabled 改为 true 即切换为 Redis 实现，
 * 上层业务代码零改动，且不会因为本机没装 Redis 而无法启动。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface CacheService {

    /** 读取缓存并转成指定类型 */
    <T> T get(String key, Class<T> type);

    /** 读取缓存并转成泛型类型（列表、Map 等） */
    <T> T get(String key, TypeReference<T> type);

    /** 写入缓存并设置过期时间（秒） */
    void set(String key, Object value, long ttlSeconds);

    /** 删除缓存（数据变更时同步刷新，防止脏读） */
    void delete(String key);

    /** 判断 key 是否存在，用于幂等控制 */
    boolean exists(String key);

    /** 仅当 key 不存在时写入，返回 true 表示抢锁/占位成功 */
    boolean setIfAbsent(String key, Object value, long ttlSeconds);
}
