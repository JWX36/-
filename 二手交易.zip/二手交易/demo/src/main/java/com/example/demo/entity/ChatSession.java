package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 买卖家客服会话（一个买家 + 一个卖家 + 一件物品构成唯一会话），对应 tb_chat_session。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_chat_session")
public class ChatSession implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 咨询的物品 ID */
    private Long itemId;

    /** 买家（咨询发起方）ID */
    private Long buyerId;

    /** 卖家（客服）ID */
    private Long sellerId;

    /** 最后一条消息内容，用于会话列表预览 */
    private String lastContent;

    /** 最后一条消息时间，用于会话排序 */
    private LocalDateTime lastTime;

    /** 买家未读消息数 */
    private Integer buyerUnread;

    /** 卖家未读消息数 */
    private Integer sellerUnread;

    /** 会话创建时间 */
    private LocalDateTime createTime;

    /** 会话更新时间 */
    private LocalDateTime updateTime;

    /** 非数据库字段：物品标题（关联查询） */
    @TableField(exist = false)
    private String itemTitle;

    /** 非数据库字段：物品封面（关联查询） */
    @TableField(exist = false)
    private String itemCover;

    /** 非数据库字段：物品价格（关联查询） */
    @TableField(exist = false)
    private BigDecimal itemPrice;

    /** 非数据库字段：对方昵称（关联查询） */
    @TableField(exist = false)
    private String peerName;

    /** 非数据库字段：对方头像（关联查询） */
    @TableField(exist = false)
    private String peerAvatar;

    /** 非数据库字段：当前登录人的未读数（关联查询） */
    @TableField(exist = false)
    private Integer unread;

    /** 非数据库字段：对方身份 BUYER / SELLER / PLATFORM */
    @TableField(exist = false)
    private String peerRole;

    /** 非数据库字段：买家昵称（管理员监管视角关联查询） */
    @TableField(exist = false)
    private String buyerName;

    /** 非数据库字段：卖家昵称（管理员监管视角关联查询） */
    @TableField(exist = false)
    private String sellerName;

    /** 非数据库字段：会话内消息条数（管理员监管视角关联查询） */
    @TableField(exist = false)
    private Integer messageCount;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取咨询的物品 ID */
    public Long getItemId() {
        return itemId;
    }

    /** 设置咨询的物品 ID */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取买家（咨询发起方）ID */
    public Long getBuyerId() {
        return buyerId;
    }

    /** 设置买家（咨询发起方）ID */
    public void setBuyerId(Long buyerId) {
        this.buyerId = buyerId;
    }

    /** 获取卖家（客服）ID */
    public Long getSellerId() {
        return sellerId;
    }

    /** 设置卖家（客服）ID */
    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    /** 获取最后一条消息内容，用于会话列表预览 */
    public String getLastContent() {
        return lastContent;
    }

    /** 设置最后一条消息内容，用于会话列表预览 */
    public void setLastContent(String lastContent) {
        this.lastContent = lastContent;
    }

    /** 获取最后一条消息时间，用于会话排序 */
    public LocalDateTime getLastTime() {
        return lastTime;
    }

    /** 设置最后一条消息时间，用于会话排序 */
    public void setLastTime(LocalDateTime lastTime) {
        this.lastTime = lastTime;
    }

    /** 获取买家未读消息数 */
    public Integer getBuyerUnread() {
        return buyerUnread;
    }

    /** 设置买家未读消息数 */
    public void setBuyerUnread(Integer buyerUnread) {
        this.buyerUnread = buyerUnread;
    }

    /** 获取卖家未读消息数 */
    public Integer getSellerUnread() {
        return sellerUnread;
    }

    /** 设置卖家未读消息数 */
    public void setSellerUnread(Integer sellerUnread) {
        this.sellerUnread = sellerUnread;
    }

    /** 获取会话创建时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置会话创建时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    /** 获取会话更新时间 */
    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    /** 设置会话更新时间 */
    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    /** 获取非数据库字段：物品标题（关联查询） */
    public String getItemTitle() {
        return itemTitle;
    }

    /** 设置非数据库字段：物品标题（关联查询） */
    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }

    /** 获取非数据库字段：物品封面（关联查询） */
    public String getItemCover() {
        return itemCover;
    }

    /** 设置非数据库字段：物品封面（关联查询） */
    public void setItemCover(String itemCover) {
        this.itemCover = itemCover;
    }

    /** 获取非数据库字段：物品价格（关联查询） */
    public BigDecimal getItemPrice() {
        return itemPrice;
    }

    /** 设置非数据库字段：物品价格（关联查询） */
    public void setItemPrice(BigDecimal itemPrice) {
        this.itemPrice = itemPrice;
    }

    /** 获取非数据库字段：对方昵称（关联查询） */
    public String getPeerName() {
        return peerName;
    }

    /** 设置非数据库字段：对方昵称（关联查询） */
    public void setPeerName(String peerName) {
        this.peerName = peerName;
    }

    /** 获取非数据库字段：对方头像（关联查询） */
    public String getPeerAvatar() {
        return peerAvatar;
    }

    /** 设置非数据库字段：对方头像（关联查询） */
    public void setPeerAvatar(String peerAvatar) {
        this.peerAvatar = peerAvatar;
    }

    /** 获取非数据库字段：当前登录人的未读数（关联查询） */
    public Integer getUnread() {
        return unread;
    }

    /** 设置非数据库字段：当前登录人的未读数（关联查询） */
    public void setUnread(Integer unread) {
        this.unread = unread;
    }

    /** 获取非数据库字段：对方身份 BUYER / SELLER */
    public String getPeerRole() {
        return peerRole;
    }

    /** 设置非数据库字段：对方身份 BUYER / SELLER / PLATFORM */
    public void setPeerRole(String peerRole) {
        this.peerRole = peerRole;
    }

    /** 获取非数据库字段：买家昵称 */
    public String getBuyerName() {
        return buyerName;
    }

    /** 设置非数据库字段：买家昵称 */
    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    /** 获取非数据库字段：卖家昵称 */
    public String getSellerName() {
        return sellerName;
    }

    /** 设置非数据库字段：卖家昵称 */
    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    /** 获取非数据库字段：会话内消息条数 */
    public Integer getMessageCount() {
        return messageCount;
    }

    /** 设置非数据库字段：会话内消息条数 */
    public void setMessageCount(Integer messageCount) {
        this.messageCount = messageCount;
    }

}
