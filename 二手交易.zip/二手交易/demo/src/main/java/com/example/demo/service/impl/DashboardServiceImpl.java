package com.example.demo.service.impl;

import com.example.demo.mapper.StatisticsMapper;
import com.example.demo.service.DashboardService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * 数据看板业务实现：把统计 SQL 的原始结果整理成 ECharts 直接可用的 JSON 结构。
 * 日期归一化在 Java 层完成，避免 H2 / MySQL 日期函数方言差异。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class DashboardServiceImpl implements DashboardService {

    private static final DateTimeFormatter LABEL = DateTimeFormatter.ofPattern("MM-dd");

    private final StatisticsMapper statisticsMapper;

    public DashboardServiceImpl(StatisticsMapper statisticsMapper) {
        this.statisticsMapper = statisticsMapper;
    }

    /** 平台概览：用户数、在售物品数、订单数、成交金额、待审核数、留言数 */
    @Override
    public Map<String, Object> summary() {
        Map<String, Object> raw = normalize(statisticsMapper.tradeSummary());
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("userCount", number(raw.get("user_count")));
        result.put("onSaleCount", number(raw.get("on_sale_count")));
        result.put("orderCount", number(raw.get("order_count")));
        result.put("tradeAmount", toDecimal(raw.get("trade_amount")).doubleValue());
        result.put("pendingCount", number(raw.get("pending_count")));
        result.put("messageCount", number(raw.get("message_count")));
        return result;
    }

    /** 近 days 天交易额曲线 + 用户累计增长曲线 + 分类成交占比 + 分类在售数量 */
    @Override
    public Map<String, Object> charts(int days) {
        int range = Math.max(7, Math.min(days, 60));
        LocalDate today = LocalDate.now();
        LocalDate from = today.minusDays(range - 1L);
        LocalDateTime fromTime = from.atStartOfDay();

        List<String> labels = new ArrayList<>();
        List<LocalDate> dateList = new ArrayList<>();
        for (int i = 0; i < range; i++) {
            LocalDate date = from.plusDays(i);
            dateList.add(date);
            labels.add(date.format(LABEL));
        }

        // ① 交易金额按日汇总
        Map<LocalDate, BigDecimal> amountByDay = new TreeMap<>();
        for (Map<String, Object> row : normalizeList(statisticsMapper.tradeDetail(fromTime))) {
            LocalDate date = toLocalDate(row.get("trade_time"));
            BigDecimal amount = toDecimal(row.get("amount"));
            amountByDay.merge(date, amount, BigDecimal::add);
        }
        List<Double> amounts = new ArrayList<>();
        for (LocalDate date : dateList) {
            amounts.add(amountByDay.getOrDefault(date, BigDecimal.ZERO).doubleValue());
        }

        // ② 用户累计增长：取全部注册记录，按天累计后截取展示区间
        Map<LocalDate, Long> regByDay = new TreeMap<>();
        for (Map<String, Object> row : normalizeList(
                statisticsMapper.userRegDetail(LocalDateTime.of(2000, 1, 1, 0, 0)))) {
            LocalDate date = toLocalDate(row.get("reg_time"));
            regByDay.merge(date, 1L, Long::sum);
        }
        long running = 0L;
        TreeMap<LocalDate, Long> cumulative = new TreeMap<>();
        for (Map.Entry<LocalDate, Long> entry : regByDay.entrySet()) {
            running += entry.getValue();
            cumulative.put(entry.getKey(), running);
        }
        List<Long> userTotals = new ArrayList<>();
        long last = 0L;
        for (LocalDate date : dateList) {
            Long value = cumulative.get(date);
            if (value != null) {
                last = value;
            }
            // 没有注册记录的日期沿用前一天的累计值
            if (value == null && !cumulative.isEmpty()) {
                Map.Entry<LocalDate, Long> floor = cumulative.floorEntry(date);
                if (floor != null) {
                    last = floor.getValue();
                }
            }
            userTotals.add(last);
        }

        // ③ 分类成交占比
        List<String> categoryNames = new ArrayList<>();
        List<Long> categoryValues = new ArrayList<>();
        for (Map<String, Object> row : normalizeList(statisticsMapper.categoryTradeShare())) {
            categoryNames.add(String.valueOf(row.getOrDefault("category_name", "未分类")));
            categoryValues.add(number(row.get("trade_count")).longValue());
        }

        // ④ 分类在售物品数量
        List<String> itemCategoryNames = new ArrayList<>();
        List<Long> itemCounts = new ArrayList<>();
        for (Map<String, Object> row : normalizeList(statisticsMapper.categoryItemCount())) {
            itemCategoryNames.add(String.valueOf(row.getOrDefault("category_name", "未分类")));
            itemCounts.add(number(row.get("item_count")).longValue());
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("labels", labels);
        result.put("amounts", amounts);
        result.put("userLabels", labels);
        result.put("userTotals", userTotals);
        result.put("categoryNames", categoryNames);
        result.put("categoryValues", categoryValues);
        result.put("itemCategoryNames", itemCategoryNames);
        result.put("itemCounts", itemCounts);
        return result;
    }

    /** H2 返回大写列名、MySQL 返回小写列名，这里统一成小写，消除数据库差异 */
    private Map<String, Object> normalize(Map<String, Object> raw) {
        Map<String, Object> map = new LinkedHashMap<>();
        if (raw == null) {
            return map;
        }
        for (Map.Entry<String, Object> entry : raw.entrySet()) {
            map.put(entry.getKey().toLowerCase(Locale.ROOT), entry.getValue());
        }
        return map;
    }

    private List<Map<String, Object>> normalizeList(List<Map<String, Object>> rows) {
        List<Map<String, Object>> list = new ArrayList<>();
        if (rows == null) {
            return list;
        }
        for (Map<String, Object> row : rows) {
            list.add(normalize(row));
        }
        return list;
    }

    /** 兼容 Timestamp / LocalDateTime / String 三种 JDBC 时间返回类型 */
    private LocalDate toLocalDate(Object value) {
        if (value instanceof LocalDateTime) {
            return ((LocalDateTime) value).toLocalDate();
        }
        if (value instanceof Timestamp) {
            return ((Timestamp) value).toLocalDateTime().toLocalDate();
        }
        if (value instanceof java.sql.Date) {
            return ((java.sql.Date) value).toLocalDate();
        }
        if (value instanceof java.util.Date) {
            return ((java.util.Date) value).toInstant()
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate();
        }
        if (value instanceof String && ((String) value).length() >= 10) {
            try {
                return LocalDate.parse(((String) value).substring(0, 10));
            } catch (Exception ignored) {
                // 解析失败回退到今天
            }
        }
        return LocalDate.now();
    }

    private BigDecimal toDecimal(Object value) {
        if (value instanceof BigDecimal) {
            return (BigDecimal) value;
        }
        if (value instanceof Number) {
            return BigDecimal.valueOf(((Number) value).doubleValue());
        }
        return BigDecimal.ZERO;
    }

    /** 任意数字类型统一转 Long */
    private Long number(Object value) {
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        if (value == null) {
            return 0L;
        }
        try {
            return Long.valueOf(String.valueOf(value));
        } catch (NumberFormatException e) {
            return 0L;
        }
    }
}
