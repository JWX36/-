package com.example.demo.service.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 本地事件处理器（演示/测试环境默认）：无需安装 RabbitMQ 即可观察完整的异步解耦业务效果。
 * 开启 app.feature.mq-enabled=true 后，本实现自动让位给 RabbitEventPublisher。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
@ConditionalOnProperty(prefix = "app.feature", name = "mq-enabled", havingValue = "false", matchIfMissing = true)
public class InMemoryEventPublisher implements EventPublisher {

    private static final Logger log = LoggerFactory.getLogger(InMemoryEventPublisher.class);

    private final EventProcessor eventProcessor;

    public InMemoryEventPublisher(EventProcessor eventProcessor) {
        this.eventProcessor = eventProcessor;
    }

    /** 演示模式：本地立即处理事件；生产模式由 RabbitMQ 消费者异步处理 */
    @Override
    public void publish(String eventType, Map<String, Object> payload) {
        log.info("本地事件处理（演示模式）：{}", eventType);
        eventProcessor.handle(eventType, payload);
    }
}
