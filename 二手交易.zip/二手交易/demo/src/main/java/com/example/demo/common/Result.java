package com.example.demo.common;

import java.io.Serializable;

/**
 * 全局统一返回结果封装。
 * 所有 REST 接口（/api/**）均返回该结构，页面请求则由 Thymeleaf 直接渲染视图。
 *
 * @param <T> 业务数据类型
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class Result<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 业务状态码，0 表示成功 */
    private int code;

    /** 提示信息 */
    private String message;

    /** 业务数据 */
    private T data;

    public Result() {
    }

    public Result(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    /** 构造成功结果（携带数据） */
    public static <T> Result<T> ok(T data) {
        return new Result<>(ResultCode.SUCCESS, "操作成功", data);
    }

    /** 构造成功结果（不携带数据） */
    public static <T> Result<T> ok() {
        return ok(null);
    }

    /** 构造成功结果（自定义提示） */
    public static <T> Result<T> ok(String message, T data) {
        return new Result<>(ResultCode.SUCCESS, message, data);
    }

    /** 构造失败结果（统一业务异常码） */
    public static <T> Result<T> fail(String message) {
        return new Result<>(ResultCode.BUSINESS_ERROR, message, null);
    }

    /** 构造失败结果（自定义状态码） */
    public static <T> Result<T> fail(int code, String message) {
        return new Result<>(code, message, null);
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
