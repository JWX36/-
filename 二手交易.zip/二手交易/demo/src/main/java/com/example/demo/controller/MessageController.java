package com.example.demo.controller;

import com.example.demo.dto.MessageForm;
import com.example.demo.service.MessageService;
import com.example.demo.util.UserContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

/**
 * 留言咨询控制器：物品详情页留言 / 回复、我的留言列表。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
public class MessageController {

    private final MessageService messageService;
    private final UserContext userContext;

    public MessageController(MessageService messageService, UserContext userContext) {
        this.messageService = messageService;
        this.userContext = userContext;
    }

    /** 发表留言或回复，成功后回到详情页留言区 */
    @PostMapping("/messages/save")
    public String save(@Valid @ModelAttribute("messageForm") MessageForm form,
                       BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "redirect:/items/detail/" + form.getItemId() + "#messages";
        }
        messageService.leave(userContext.currentUserId(), form);
        return "redirect:/items/detail/" + form.getItemId() + "#messages";
    }

    /** 与我相关的留言 */
    @GetMapping("/messages/mine")
    public String mine(Model model) {
        model.addAttribute("messages", messageService.listMine(userContext.currentUserId()));
        return "messages/mine";
    }
}
