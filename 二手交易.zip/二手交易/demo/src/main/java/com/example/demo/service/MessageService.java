package com.example.demo.service;

import com.example.demo.dto.MessageForm;
import com.example.demo.entity.Message;

import java.util.List;

/**
 * 留言咨询模块业务接口：留言、发布者回复、列表展示与异步通知。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface MessageService {

    /** 发表留言或回复（自动判定接收人，异步提醒对方） */
    void leave(Long senderId, MessageForm form);

    /** 某物品下的留言列表（含回复） */
    List<Message> listByItem(Long itemId);

    /** 与我相关的留言 */
    List<Message> listMine(Long userId);

    /** 某物品下的评价 / 留言总数（未登录时用于展示「登录后查看 N 条评价」） */
    long countByItem(Long itemId);
}
