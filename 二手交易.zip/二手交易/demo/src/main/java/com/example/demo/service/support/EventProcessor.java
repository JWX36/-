package com.example.demo.service.support;

import com.example.demo.util.CacheJson;
import com.fasterxml.jackson.core.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Map;

/**
 * 领域事件统一处理器：RabbitMQ 消费者与本地演示实现共用同一套业务逻辑，
 * 因此无论是否启动消息中间件，通知行为完全一致。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class EventProcessor {

    private static final Logger log = LoggerFactory.getLogger(EventProcessor.class);

    private final NotificationService notificationService;

    public EventProcessor(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    /** 处理 JSON 格式事件消息（RabbitMQ 消费者入口） */
    public void handleJson(String eventType, String json) {
        Map<String, Object> payload = CacheJson.read(json, new TypeReference<Map<String, Object>>() {
        });
        handle(eventType, payload == null ? Collections.emptyMap() : payload);
    }

    /** 按事件类型分发：写站内信 + 触发邮件提醒 */
    public void handle(String eventType, Map<String, Object> payload) {
        if (payload == null) {
            payload = Collections.emptyMap();
        }
        String orderNo = str(payload.get("orderNo"));
        String itemTitle = str(payload.get("itemTitle"));
        switch (eventType) {
            case "order.created":
                // 场景①：下单成功，给买家一条明确的「待支付」提醒（与导航红点、订单中心提醒条同源）
                notificationService.notifyUser(toLong(payload.get("buyerId")),
                        "订单待支付", "订单 " + orderNo + " 已创建，商品《" + itemTitle
                                + "》，金额 ¥" + str(payload.get("amount"))
                                + "。请在 30 分钟内完成模拟支付，可在「我的订单」待支付提醒中一键进入；超时将自动取消并恢复库存。",
                        "ORDER", true);
                notificationService.notifyUser(toLong(payload.get("sellerId")),
                        "有新订单待处理", "您的物品《" + itemTitle + "》已被下单，订单号 " + orderNo
                                + "，买家支付后请及时确认交付。",
                        "ORDER", true);
                break;
            case "order.status":
                // 场景②：订单状态变更异步推送
                String statusText = str(payload.get("statusText"));
                String message = "订单 " + orderNo + "（" + itemTitle + "）状态变更为：" + statusText;
                notificationService.notifyUser(toLong(payload.get("buyerId")), "订单状态更新", message, "ORDER", true);
                notificationService.notifyUser(toLong(payload.get("sellerId")), "订单状态更新", message, "ORDER", true);
                break;
            case "item.audit":
                // 场景③：物品审核结果邮件通知用户
                boolean pass = Boolean.parseBoolean(str(payload.get("pass")));
                String result = pass ? "审核通过，已上架展示" : "审核未通过：" + str(payload.get("reason"));
                notificationService.notifyUser(toLong(payload.get("userId")),
                        "物品审核结果", "您发布的《" + itemTitle + "》" + result + "。", "AUDIT", true);
                break;
            case "message.created":
                // 场景④：留言提醒发布者
                notificationService.notifyUser(toLong(payload.get("receiverId")),
                        "收到新留言", str(payload.get("senderName")) + " 在《" + itemTitle
                                + "》下留言：" + str(payload.get("content")), "MESSAGE", true);
                break;
            default:
                log.warn("未知事件类型：{}", eventType);
                break;
        }
    }

    /** 安全地把事件载荷转成 Long ID */
    private Long toLong(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return Long.valueOf(String.valueOf(value));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** 安全地把事件载荷转成字符串 */
    private String str(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
