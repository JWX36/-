package com.example.demo.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ 拓扑配置（高阶必选考点）：一个 Topic 交换机 + 四个业务队列。
 * 仅在 app.feature.mq-enabled=true 时装配，未启动 RabbitMQ 的机器也能正常启动本系统。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Configuration
@ConditionalOnProperty(prefix = "app.feature", name = "mq-enabled", havingValue = "true")
public class RabbitConfig {

    /** 业务事件交换机 */
    public static final String EXCHANGE = "campus.market.topic";

    /** 下单成功队列：异步邮件通知 */
    public static final String QUEUE_ORDER_CREATED = "campus.queue.order.created";

    /** 订单状态变更队列：异步推送买家/卖家 */
    public static final String QUEUE_ORDER_STATUS = "campus.queue.order.status";

    /** 物品审核结果队列 */
    public static final String QUEUE_ITEM_AUDIT = "campus.queue.item.audit";

    /** 留言通知队列 */
    public static final String QUEUE_MESSAGE = "campus.queue.message.created";

    /** 路由键常量 */
    public static final String RK_ORDER_CREATED = "order.created";
    public static final String RK_ORDER_STATUS = "order.status";
    public static final String RK_ITEM_AUDIT = "item.audit";
    public static final String RK_MESSAGE_CREATED = "message.created";

    /** 声明持久化交换机 */
    @Bean
    public TopicExchange marketTopicExchange() {
        return new TopicExchange(EXCHANGE, true, false);
    }

    /** 声明四个持久化队列 */
    @Bean
    public Queue queueOrderCreated() {
        return new Queue(QUEUE_ORDER_CREATED, true);
    }

    @Bean
    public Queue queueOrderStatus() {
        return new Queue(QUEUE_ORDER_STATUS, true);
    }

    @Bean
    public Queue queueItemAudit() {
        return new Queue(QUEUE_ITEM_AUDIT, true);
    }

    @Bean
    public Queue queueMessageCreated() {
        return new Queue(QUEUE_MESSAGE, true);
    }

    /** 绑定关系：直接以队列名构造，避免多个 Queue Bean 注入时的歧义 */
    @Bean
    public Binding bindingOrderCreated(TopicExchange marketTopicExchange) {
        return BindingBuilder.bind(new Queue(QUEUE_ORDER_CREATED, true))
                .to(marketTopicExchange).with(RK_ORDER_CREATED);
    }

    @Bean
    public Binding bindingOrderStatus(TopicExchange marketTopicExchange) {
        return BindingBuilder.bind(new Queue(QUEUE_ORDER_STATUS, true))
                .to(marketTopicExchange).with(RK_ORDER_STATUS);
    }

    @Bean
    public Binding bindingItemAudit(TopicExchange marketTopicExchange) {
        return BindingBuilder.bind(new Queue(QUEUE_ITEM_AUDIT, true))
                .to(marketTopicExchange).with(RK_ITEM_AUDIT);
    }

    @Bean
    public Binding bindingMessageCreated(TopicExchange marketTopicExchange) {
        return BindingBuilder.bind(new Queue(QUEUE_MESSAGE, true))
                .to(marketTopicExchange).with(RK_MESSAGE_CREATED);
    }
}
