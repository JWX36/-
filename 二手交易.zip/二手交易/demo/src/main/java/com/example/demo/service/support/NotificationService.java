package com.example.demo.service.support;

import com.example.demo.entity.Notice;
import com.example.demo.entity.User;
import com.example.demo.mapper.NoticeMapper;
import com.example.demo.mapper.UserMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 通知服务：站内信必达 + 邮件尽力而为。
 * 邮件发送失败不会影响交易主流程，且站内信始终保留，满足「通知不丢失」要求。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    private final NoticeMapper noticeMapper;
    private final UserMapper userMapper;
    private final MailService mailService;

    public NotificationService(NoticeMapper noticeMapper, UserMapper userMapper, MailService mailService) {
        this.noticeMapper = noticeMapper;
        this.userMapper = userMapper;
        this.mailService = mailService;
    }

    /**
     * 写入站内通知，并在开启邮件功能时异步发送邮件提醒。
     *
     * @param userId    接收人
     * @param title     标题
     * @param content   正文
     * @param type      通知类型 ORDER / AUDIT / MESSAGE / SYSTEM
     * @param withMail  该业务场景是否需要邮件提醒
     */
    public void notifyUser(Long userId, String title, String content, String type, boolean withMail) {
        if (userId == null) {
            return;
        }
        Notice notice = new Notice();
        notice.setUserId(userId);
        notice.setTitle(title);
        notice.setContent(content);
        notice.setType(type);
        notice.setIsRead(0);
        notice.setCreateTime(LocalDateTime.now());
        noticeMapper.insert(notice);
        if (withMail) {
            User user = userMapper.selectById(userId);
            if (user != null && user.getEmail() != null && !user.getEmail().isEmpty()) {
                mailService.sendAsync(user.getEmail(), title, content);
            }
        }
        log.debug("站内通知已生成：userId={}, type={}, title={}", userId, type, title);
    }

    /** 我收到的通知列表（最新在前） */
    public List<Notice> listMine(Long userId) {
        return noticeMapper.selectList(new LambdaQueryWrapper<Notice>()
                .eq(Notice::getUserId, userId)
                .orderByDesc(Notice::getCreateTime, Notice::getId));
    }

    /** 未读通知数量，用于导航栏红点 */
    public long countUnread(Long userId) {
        return noticeMapper.selectCount(new LambdaQueryWrapper<Notice>()
                .eq(Notice::getUserId, userId)
                .eq(Notice::getIsRead, 0));
    }

    /** 一键标记已读 */
    public void markAllRead(Long userId) {
        List<Notice> notices = noticeMapper.selectList(new LambdaQueryWrapper<Notice>()
                .eq(Notice::getUserId, userId)
                .eq(Notice::getIsRead, 0));
        for (Notice notice : notices) {
            notice.setIsRead(1);
            noticeMapper.updateById(notice);
        }
    }
}
