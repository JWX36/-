package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 操作日志实体，对应 tb_operation_log，由 AOP 切面统一记录后台关键操作。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_operation_log")
public class OperationLog implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 操作人账号 */
    private String username;

    /** 操作描述 */
    private String operation;

    /** HTTP 方法 */
    private String requestMethod;

    /** 请求地址 */
    private String requestUri;

    /** 客户端 IP */
    private String ip;

    /** 耗时（毫秒） */
    private Long costMs;

    /** 操作时间 */
    private LocalDateTime createTime;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取操作人账号 */
    public String getUsername() {
        return username;
    }

    /** 设置操作人账号 */
    public void setUsername(String username) {
        this.username = username;
    }

    /** 获取操作描述 */
    public String getOperation() {
        return operation;
    }

    /** 设置操作描述 */
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /** 获取HTTP 方法 */
    public String getRequestMethod() {
        return requestMethod;
    }

    /** 设置HTTP 方法 */
    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    /** 获取请求地址 */
    public String getRequestUri() {
        return requestUri;
    }

    /** 设置请求地址 */
    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }

    /** 获取客户端 IP */
    public String getIp() {
        return ip;
    }

    /** 设置客户端 IP */
    public void setIp(String ip) {
        this.ip = ip;
    }

    /** 获取耗时（毫秒） */
    public Long getCostMs() {
        return costMs;
    }

    /** 设置耗时（毫秒） */
    public void setCostMs(Long costMs) {
        this.costMs = costMs;
    }

    /** 获取操作时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置操作时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

}
