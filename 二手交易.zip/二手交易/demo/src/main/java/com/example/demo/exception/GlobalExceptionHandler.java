package com.example.demo.exception;

import com.example.demo.common.Result;
import com.example.demo.common.ResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.ui.Model;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.stream.Collectors;

/**
 * 全局异常处理器（工程化规范考点）。
 * 页面请求渲染统一错误页，/api/** 的 REST 请求返回统一 Result JSON，互不干扰。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /** 业务异常：可直接把提示语展示给用户 */
    @ExceptionHandler(BusinessException.class)
    public Object handleBusiness(BusinessException e, HttpServletRequest request, Model model) {
        log.warn("业务异常 uri={} message={}", request.getRequestURI(), e.getMessage());
        if (isApi(request)) {
            return ResponseEntity.ok(Result.fail(e.getCode(), e.getMessage()));
        }
        model.addAttribute("errorMessage", e.getMessage());
        return "error/500";
    }

    /** Spring Security 方法级鉴权失败 */
    @ExceptionHandler(AccessDeniedException.class)
    public Object handleAccessDenied(AccessDeniedException e, HttpServletRequest request) {
        if (isApi(request)) {
            return ResponseEntity.ok(Result.fail(ResultCode.FORBIDDEN, "没有权限执行该操作"));
        }
        return "redirect:/403";
    }

    /** JSR-303 表单对象校验失败 */
    @ExceptionHandler({MethodArgumentNotValidException.class, BindException.class})
    public Object handleBind(BindException e, HttpServletRequest request, Model model) {
        String message = e.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining("；"));
        if (message.isEmpty()) {
            message = "参数校验失败";
        }
        if (isApi(request)) {
            return ResponseEntity.ok(Result.fail(ResultCode.PARAM_ERROR, message));
        }
        model.addAttribute("errorMessage", message);
        return "error/500";
    }

    /** 方法参数上的约束校验失败 */
    @ExceptionHandler(ConstraintViolationException.class)
    public Object handleConstraint(ConstraintViolationException e, HttpServletRequest request, Model model) {
        String message = e.getMessage() == null ? "参数校验失败" : e.getMessage();
        if (isApi(request)) {
            return ResponseEntity.ok(Result.fail(ResultCode.PARAM_ERROR, message));
        }
        model.addAttribute("errorMessage", message);
        return "error/500";
    }

    /** 上传文件超过 spring.servlet.multipart 限制 */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public Object handleUpload(MaxUploadSizeExceededException e, HttpServletRequest request, Model model) {
        String message = "上传文件过大，单张图片不能超过 5MB";
        if (isApi(request)) {
            return ResponseEntity.ok(Result.fail(ResultCode.PARAM_ERROR, message));
        }
        model.addAttribute("errorMessage", message);
        return "error/500";
    }

    /** 兜底异常：记录完整堆栈，页面只显示友好提示，不泄漏系统信息 */
    @ExceptionHandler(Exception.class)
    public Object handleException(Exception e, HttpServletRequest request, Model model) {
        log.error("系统异常 uri={}", request.getRequestURI(), e);
        if (isApi(request)) {
            return ResponseEntity.ok(Result.fail(ResultCode.SYSTEM_ERROR, "系统繁忙，请稍后再试"));
        }
        model.addAttribute("errorMessage", "系统繁忙，请稍后再试，或查看控制台日志");
        return "error/500";
    }

    /** 判断当前请求是否需要 JSON 响应 */
    private boolean isApi(HttpServletRequest request) {
        String uri = request.getRequestURI();
        String accept = request.getHeader("Accept");
        return uri.startsWith("/api/")
                || (accept != null && accept.contains("application/json"));
    }
}
