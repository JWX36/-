package com.example.demo.controller;

import com.example.demo.dto.OrderForm;
import com.example.demo.dto.PageQuery;
import com.example.demo.entity.TradeOrder;
import com.example.demo.service.ChatService;
import com.example.demo.service.RefundService;
import com.example.demo.service.TradeOrderService;
import com.example.demo.util.PageUrl;
import com.example.demo.util.UserContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.Map;

/**
 * 订单控制器：下单（幂等）、模拟支付、确认交易、取消订单、订单列表与详情。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
public class TradeOrderController {

    private final TradeOrderService tradeOrderService;
    private final ChatService chatService;
    private final RefundService refundService;
    private final UserContext userContext;

    public TradeOrderController(TradeOrderService tradeOrderService, ChatService chatService,
                                RefundService refundService, UserContext userContext) {
        this.tradeOrderService = tradeOrderService;
        this.chatService = chatService;
        this.refundService = refundService;
        this.userContext = userContext;
    }

    /** 下单：成功后直接跳转订单详情 */
    @PostMapping("/orders/create")
    public String create(@Valid @ModelAttribute("orderForm") OrderForm form,
                         BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    bindingResult.getFieldError() == null ? "请检查下单信息"
                            : bindingResult.getFieldError().getDefaultMessage());
            return "redirect:/items/detail/" + form.getItemId() + "#buy";
        }
        try {
            TradeOrder order = tradeOrderService.create(userContext.currentUserId(), form);
            return "redirect:/orders/detail/" + order.getId();
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/items/detail/" + form.getItemId() + "#buy";
        }
    }

    /**
     * 订单列表：view=buyer 我买到的；view=seller 我卖出的。
     */
    @GetMapping("/orders")
    public String list(PageQuery query,
                       @RequestParam(value = "view", defaultValue = "buyer") String view,
                       @RequestParam(value = "status", required = false) Integer status,
                       Model model) {
        Long userId = userContext.currentUserId();
        boolean seller = "seller".equals(view);
        model.addAttribute("orders", tradeOrderService.pageOrders(query,
                seller ? null : userId, seller ? userId : null, status));
        model.addAttribute("query", query);
        model.addAttribute("view", view);
        model.addAttribute("statusFilter", status);
        model.addAttribute("pageBase", PageUrl.build("/orders", "view", view, "status", status));
        // 淘宝式状态分组：每个 Tab 实时显示该状态订单数，切换买家 / 卖家视角时按对应身份统计
        Map<Integer, Long> counts = tradeOrderService.countGroupByStatus(
                seller ? null : userId, seller ? userId : null);
        model.addAttribute("countAll", counts.values().stream().mapToLong(Long::longValue).sum());
        model.addAttribute("countWaitPay", counts.getOrDefault(0, 0L));
        model.addAttribute("countPaid", counts.getOrDefault(1, 0L));
        model.addAttribute("countFinished", counts.getOrDefault(2, 0L));
        model.addAttribute("countCanceled", counts.getOrDefault(3, 0L) + counts.getOrDefault(4, 0L));
        model.addAttribute("countRefunded", counts.getOrDefault(5, 0L));
        return "orders/list";
    }

    /** 订单详情：Service 内校验数据归属，防止越权查看 */
    @GetMapping("/orders/detail/{id}")
    public String detail(@PathVariable("id") Long id, Model model) {
        TradeOrder order = tradeOrderService.detail(id, userContext.currentUserId(),
                userContext.isAdmin());
        Long userId = userContext.currentUserId();
        model.addAttribute("order", order);
        // 订单详情页同时展示退款进度与「申请退款 / 带订单咨询」入口
        model.addAttribute("refund", refundService.findByOrder(id, userId, userContext.isAdmin()));
        model.addAttribute("canApplyRefund", !userContext.isAdmin()
                && order.getBuyerId().equals(userId) && refundService.canApply(order));
        return "orders/detail";
    }

    /** 模拟支付 */
    @PostMapping("/orders/pay/{id}")
    public String pay(@PathVariable("id") Long id) {
        tradeOrderService.pay(id, userContext.currentUserId());
        return "redirect:/orders/detail/" + id;
    }

    /** 确认交易 */
    @PostMapping("/orders/confirm/{id}")
    public String confirm(@PathVariable("id") Long id) {
        tradeOrderService.confirm(id, userContext.currentUserId());
        return "redirect:/orders/detail/" + id;
    }

    /**
     * 订单详情页「带订单咨询卖家」：复用该商品的买卖家会话，并把订单卡片发给对方。
     * 买家咨询售后、卖家主动沟通发货都能一键带着订单信息发起，不必再手动描述订单号。
     */
    @GetMapping("/orders/consult/{id}")
    public String consult(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        try {
            Long sessionId = chatService.openForOrder(id, userContext.currentUserId());
            return "redirect:/chat/" + sessionId;
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/orders/detail/" + id;
        }
    }

    /** 取消订单 */
    @PostMapping("/orders/cancel/{id}")
    public String cancel(@PathVariable("id") Long id,
                         @RequestParam(value = "reason", defaultValue = "用户主动取消") String reason) {
        tradeOrderService.cancel(id, userContext.currentUserId(), reason);
        return "redirect:/orders/detail/" + id;
    }
}
