package com.example.demo.service;

import com.example.demo.entity.RefundApply;
import com.example.demo.entity.TradeOrder;

import java.util.List;

/**
 * 退款 / 售后业务接口（二手闲置场景的「合理退款」）。
 *
 * 规则摘要：
 * ① 仅「已支付待确认」「已完成」订单可申请，且必须在支付 / 完成后配置的窗口天数内；
 * ② 二手闲置当面验货，不支持七天无理由，只受理四种有理由退款；
 * ③ 同一订单只允许一笔处理中的申请，退款成功后不可重复申请；
 * ④ 卖家在配置时限内处理，超时由定时任务代表系统自动同意；
 * ⑤ 卖家拒绝后买家可申请平台介入，由管理员裁定同意退款或驳回；
 * ⑥ 退款成功后订单标记为「已退款」、恢复商品库存并重新上架，站内通知买卖双方。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface RefundService {

    /** 状态：待卖家处理 */
    int WAIT_SELLER = 0;
    /** 状态：退款成功 */
    int REFUNDED = 1;
    /** 状态：卖家拒绝 */
    int SELLER_REJECTED = 2;
    /** 状态：平台介入中 */
    int PLATFORM_REVIEW = 3;
    /** 状态：平台驳回 */
    int PLATFORM_REJECTED = 4;
    /** 状态：买家撤销 */
    int BUYER_CANCELED = 5;

    /** 订单详情页判断当前买家能否申请退款（含时限、状态、重复申请校验的轻量版） */
    boolean canApply(TradeOrder order);

    /** 买家提交退款申请 */
    RefundApply apply(Long orderId, Long buyerId, String reasonType, String reason);

    /** 退款申请详情（校验买家 / 卖家 / 管理员归属，防水平越权） */
    RefundApply detail(Long id, Long userId, boolean admin);

    /** 某订单最近一笔退款申请，供订单详情页展示；无申请返回 null */
    RefundApply findByOrder(Long orderId, Long userId, boolean admin);

    /** 我的退款：view=buyer 我申请的 / view=seller 待我处理的 */
    List<RefundApply> listMine(Long userId, String view);

    /** 后台：全站退款申请 */
    List<RefundApply> listAll();

    /** 卖家同意 / 拒绝退款申请 */
    void handle(Long id, Long sellerId, boolean approve, String note);

    /** 卖家拒绝后，买家申请平台介入 */
    void escalate(Long id, Long buyerId);

    /** 买家撤销待处理的退款申请 */
    void cancel(Long id, Long buyerId);

    /** 管理员裁定：同意退款 / 驳回申请 */
    void decide(Long id, Long adminId, boolean approve, String note);

    /** 定时任务：卖家超过 hours 小时未处理的申请自动同意，返回处理笔数 */
    int autoApproveExpired(int hours);
}
