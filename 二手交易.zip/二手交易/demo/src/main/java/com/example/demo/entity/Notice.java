package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 站内通知实体，对应 tb_notice。邮件发送失败时仍保留站内信，保证通知不丢失。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_notice")
public class Notice implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 接收用户 ID */
    private Long userId;

    /** 通知标题 */
    private String title;

    /** 通知内容 */
    private String content;

    /** 通知类型：ORDER / AUDIT / MESSAGE / SYSTEM */
    private String type;

    /** 是否已读：1 是，0 否 */
    private Integer isRead;

    /** 创建时间 */
    private LocalDateTime createTime;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取接收用户 ID */
    public Long getUserId() {
        return userId;
    }

    /** 设置接收用户 ID */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /** 获取通知标题 */
    public String getTitle() {
        return title;
    }

    /** 设置通知标题 */
    public void setTitle(String title) {
        this.title = title;
    }

    /** 获取通知内容 */
    public String getContent() {
        return content;
    }

    /** 设置通知内容 */
    public void setContent(String content) {
        this.content = content;
    }

    /** 获取通知类型：ORDER / AUDIT / MESSAGE / SYSTEM */
    public String getType() {
        return type;
    }

    /** 设置通知类型：ORDER / AUDIT / MESSAGE / SYSTEM */
    public void setType(String type) {
        this.type = type;
    }

    /** 获取是否已读：1 是，0 否 */
    public Integer getIsRead() {
        return isRead;
    }

    /** 设置是否已读：1 是，0 否 */
    public void setIsRead(Integer isRead) {
        this.isRead = isRead;
    }

    /** 获取创建时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置创建时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

}
