package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 留言咨询实体，对应 tb_message。parent_id 非 0 表示对某条留言的回复。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_message")
public class Message implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 被咨询的物品 ID */
    private Long itemId;

    /** 留言人 ID */
    private Long senderId;

    /** 接收人（物品发布者）ID */
    private Long receiverId;

    /** 父留言 ID，0 表示主留言 */
    private Long parentId;

    /** 留言内容 */
    private String content;

    /** 是否已读：1 是，0 否 */
    private Integer isRead;

    /** 评价星级：1~5 星（留言咨询默认 5 星，不展示） */
    private Integer rating;

    /** 留言时间 */
    private LocalDateTime createTime;

    /** 非数据库字段：留言人昵称（关联查询） */
    @TableField(exist = false)
    private String senderName;

    /** 非数据库字段：留言人头像（关联查询） */
    @TableField(exist = false)
    private String senderAvatar;

    /** 非数据库字段：物品标题（关联查询） */
    @TableField(exist = false)
    private String itemTitle;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取被咨询的物品 ID */
    public Long getItemId() {
        return itemId;
    }

    /** 设置被咨询的物品 ID */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取留言人 ID */
    public Long getSenderId() {
        return senderId;
    }

    /** 设置留言人 ID */
    public void setSenderId(Long senderId) {
        this.senderId = senderId;
    }

    /** 获取接收人（物品发布者）ID */
    public Long getReceiverId() {
        return receiverId;
    }

    /** 设置接收人（物品发布者）ID */
    public void setReceiverId(Long receiverId) {
        this.receiverId = receiverId;
    }

    /** 获取父留言 ID，0 表示主留言 */
    public Long getParentId() {
        return parentId;
    }

    /** 设置父留言 ID，0 表示主留言 */
    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    /** 获取留言内容 */
    public String getContent() {
        return content;
    }

    /** 设置留言内容 */
    public void setContent(String content) {
        this.content = content;
    }

    /** 获取是否已读：1 是，0 否 */
    public Integer getIsRead() {
        return isRead;
    }

    /** 设置是否已读：1 是，0 否 */
    public void setIsRead(Integer isRead) {
        this.isRead = isRead;
    }

    /** 获取评价星级 */
    public Integer getRating() {
        return rating;
    }

    /** 设置评价星级 */
    public void setRating(Integer rating) {
        this.rating = rating;
    }

    /** 获取留言时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置留言时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    /** 获取非数据库字段：留言人昵称（关联查询） */
    public String getSenderName() {
        return senderName;
    }

    /** 设置非数据库字段：留言人昵称（关联查询） */
    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    /** 获取非数据库字段：留言人头像（关联查询） */
    public String getSenderAvatar() {
        return senderAvatar;
    }

    /** 设置非数据库字段：留言人头像（关联查询） */
    public void setSenderAvatar(String senderAvatar) {
        this.senderAvatar = senderAvatar;
    }

    /** 获取非数据库字段：物品标题（关联查询） */
    public String getItemTitle() {
        return itemTitle;
    }

    /** 设置非数据库字段：物品标题（关联查询） */
    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }

}
