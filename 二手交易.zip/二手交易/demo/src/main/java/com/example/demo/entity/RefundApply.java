package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 退款 / 售后申请实体，对应 tb_refund_apply。
 *
 * 二手闲置平台规则：不支持「七天无理由」，只受理有明确理由的退款；
 * 状态：0 待卖家处理 / 1 退款成功 / 2 卖家拒绝 / 3 平台介入中 / 4 平台驳回 / 5 买家撤销。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_refund_apply")
public class RefundApply implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 订单 ID */
    private Long orderId;

    /** 订单编号快照 */
    private String orderNo;

    /** 买家 ID */
    private Long buyerId;

    /** 卖家 ID */
    private Long sellerId;

    /** 物品 ID */
    private Long itemId;

    /** 申请退款金额（演示环境为订单全额） */
    private BigDecimal amount;

    /** 理由类型：DESC_MISMATCH / QUALITY / NOT_RECEIVED / AGREED */
    private String reasonType;

    /** 退款说明 */
    private String reason;

    /** 申请状态：0 待卖家处理 1 退款成功 2 卖家拒绝 3 平台介入中 4 平台驳回 5 买家撤销 */
    private Integer status;

    /** 处理来源：SELLER / SYSTEM / ADMIN */
    private String handlerType;

    /** 处理说明 / 平台裁定意见 */
    private String handleNote;

    /** 处理人 ID（系统自动处理时为 null） */
    private Long handlerId;

    /** 申请时间 */
    private LocalDateTime applyTime;

    /** 卖家处理截止时间 */
    private LocalDateTime deadlineTime;

    /** 实际处理时间 */
    private LocalDateTime handleTime;

    /** 创建时间 */
    private LocalDateTime createTime;

    /** 更新时间 */
    private LocalDateTime updateTime;

    /** 非数据库字段：物品标题（关联展示） */
    @TableField(exist = false)
    private String itemTitle;

    /** 非数据库字段：物品封面（关联展示） */
    @TableField(exist = false)
    private String itemCover;

    /** 非数据库字段：买家昵称 */
    @TableField(exist = false)
    private String buyerName;

    /** 非数据库字段：卖家昵称 */
    @TableField(exist = false)
    private String sellerName;

    /** 非数据库字段：订单当前状态 */
    @TableField(exist = false)
    private Integer orderStatus;

    /** 非数据库字段：退款理由中文名称 */
    @TableField(exist = false)
    private String reasonText;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Long getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(Long buyerId) {
        this.buyerId = buyerId;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getReasonType() {
        return reasonType;
    }

    public void setReasonType(String reasonType) {
        this.reasonType = reasonType;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getHandlerType() {
        return handlerType;
    }

    public void setHandlerType(String handlerType) {
        this.handlerType = handlerType;
    }

    public String getHandleNote() {
        return handleNote;
    }

    public void setHandleNote(String handleNote) {
        this.handleNote = handleNote;
    }

    public Long getHandlerId() {
        return handlerId;
    }

    public void setHandlerId(Long handlerId) {
        this.handlerId = handlerId;
    }

    public LocalDateTime getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(LocalDateTime applyTime) {
        this.applyTime = applyTime;
    }

    public LocalDateTime getDeadlineTime() {
        return deadlineTime;
    }

    public void setDeadlineTime(LocalDateTime deadlineTime) {
        this.deadlineTime = deadlineTime;
    }

    public LocalDateTime getHandleTime() {
        return handleTime;
    }

    public void setHandleTime(LocalDateTime handleTime) {
        this.handleTime = handleTime;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getItemTitle() {
        return itemTitle;
    }

    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }

    public String getItemCover() {
        return itemCover;
    }

    public void setItemCover(String itemCover) {
        this.itemCover = itemCover;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getReasonText() {
        return reasonText;
    }

    public void setReasonText(String reasonText) {
        this.reasonText = reasonText;
    }
}
