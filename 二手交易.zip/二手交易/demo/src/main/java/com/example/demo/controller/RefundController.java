package com.example.demo.controller;

import com.example.demo.config.AppProperties;
import com.example.demo.entity.RefundApply;
import com.example.demo.entity.TradeOrder;
import com.example.demo.service.RefundService;
import com.example.demo.service.TradeOrderService;
import com.example.demo.util.UserContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 退款 / 售后前台控制器：买家申请、卖家处理、平台介入、撤销与进度查看。
 * 所有操作都在 Service 层做数据归属校验（防水平越权），业务异常转成页面友好提示。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
@RequestMapping("/refunds")
public class RefundController {

    private final RefundService refundService;
    private final TradeOrderService tradeOrderService;
    private final UserContext userContext;
    private final AppProperties appProperties;

    public RefundController(RefundService refundService, TradeOrderService tradeOrderService,
                            UserContext userContext, AppProperties appProperties) {
        this.refundService = refundService;
        this.tradeOrderService = tradeOrderService;
        this.userContext = userContext;
        this.appProperties = appProperties;
    }

    /** 退款中心：我申请的 / 待我处理的（卖家视角） */
    @GetMapping
    public String list(@RequestParam(value = "view", defaultValue = "buyer") String view, Model model) {
        Long userId = userContext.currentUserId();
        model.addAttribute("refunds", refundService.listMine(userId, view));
        model.addAttribute("view", "seller".equals(view) ? "seller" : "buyer");
        addRules(model);
        return "refunds/list";
    }

    /** 申请退款表单：校验订单归属与售后资格，展示平台规则 */
    @GetMapping("/apply/{orderId}")
    public String applyForm(@PathVariable("orderId") Long orderId, Model model,
                            RedirectAttributes redirectAttributes) {
        Long userId = userContext.currentUserId();
        try {
            TradeOrder order = tradeOrderService.detail(orderId, userId, userContext.isAdmin());
            model.addAttribute("order", order);
            if (userContext.isAdmin() || !order.getBuyerId().equals(userId)) {
                redirectAttributes.addFlashAttribute("errorMessage", "只有订单买家可以申请退款");
                return "redirect:/orders/detail/" + orderId;
            }
            if (!refundService.canApply(order)) {
                redirectAttributes.addFlashAttribute("errorMessage", "该订单当前不符合退款条件（需已支付 / 已完成、在售后期内且无进行中的申请）");
                return "redirect:/orders/detail/" + orderId;
            }
            addRules(model);
            return "refunds/apply";
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/orders";
        }
    }

    /** 提交退款申请 */
    @PostMapping("/apply/{orderId}")
    public String apply(@PathVariable("orderId") Long orderId,
                        @RequestParam("reasonType") String reasonType,
                        @RequestParam("reason") String reason,
                        RedirectAttributes redirectAttributes) {
        try {
            RefundApply apply = refundService.apply(orderId, userContext.currentUserId(), reasonType, reason);
            redirectAttributes.addFlashAttribute("successMessage", "退款申请已提交，请等待卖家处理");
            return "redirect:/refunds/detail/" + apply.getId();
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/orders/detail/" + orderId;
        }
    }

    /** 退款详情（含处理进度时间线与按角色显示的操作按钮） */
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Long id, Model model) {
        model.addAttribute("refund", refundService.detail(id, userContext.currentUserId(), userContext.isAdmin()));
        addRules(model);
        return "refunds/detail";
    }

    /** 卖家同意 / 拒绝 */
    @PostMapping("/handle/{id}")
    public String handle(@PathVariable("id") Long id,
                         @RequestParam(value = "approve", defaultValue = "false") boolean approve,
                         @RequestParam(value = "note", required = false) String note,
                         RedirectAttributes redirectAttributes) {
        try {
            refundService.handle(id, userContext.currentUserId(), approve, note);
            redirectAttributes.addFlashAttribute("successMessage",
                    approve ? "已同意退款，订单状态已更新为「已退款」" : "已拒绝退款申请，买家可申请平台介入");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/refunds/detail/" + id;
    }

    /** 买家申请平台介入 */
    @PostMapping("/escalate/{id}")
    public String escalate(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        try {
            refundService.escalate(id, userContext.currentUserId());
            redirectAttributes.addFlashAttribute("successMessage", "已申请平台介入，管理员会在后台作出裁定");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/refunds/detail/" + id;
    }

    /** 买家撤销申请 */
    @PostMapping("/cancel/{id}")
    public String cancel(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        try {
            refundService.cancel(id, userContext.currentUserId());
            redirectAttributes.addFlashAttribute("successMessage", "退款申请已撤销");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/refunds/detail/" + id;
    }

    /** 页面共享：四类退款理由与规则参数 */
    private void addRules(Model model) {
        List<Map<String, String>> reasons = new ArrayList<>();
        reasons.add(option("DESC_MISMATCH", "宝贝与描述不符", "成色、配件、数量、功能与商品页描述明显不一致"));
        reasons.add(option("QUALITY", "质量问题 / 功能故障", "面交时未发现、使用后才暴露的故障，需说明具体现象"));
        reasons.add(option("NOT_RECEIVED", "未收到货 / 卖家未交付", "已支付但卖家未按约定时间地点交付"));
        reasons.add(option("AGREED", "买卖双方协商一致", "已在客服会话中沟通好退货退款，请附上协商结果"));
        model.addAttribute("reasonOptions", reasons);
        model.addAttribute("applyWindowDays", appProperties.getRefund().getApplyWindowDays());
        model.addAttribute("sellerHandleHours", appProperties.getRefund().getSellerHandleHours());
    }

    private Map<String, String> option(String code, String name, String desc) {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("code", code);
        map.put("name", name);
        map.put("desc", desc);
        return map;
    }
}
