package com.example.demo.service;

import com.example.demo.entity.ChatMessage;
import com.example.demo.entity.ChatSession;

import java.util.List;

/**
 * 买卖家客服（站内私信）业务接口：会话复用、消息发送、增量拉取、已读与未读数。
 * 仿淘宝「联系卖家 / 客服消息」：一个买家 + 一个卖家 + 一件物品 = 一个会话。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface ChatService {

    /** 从商品详情页发起咨询：复用已有会话，可携带一条快捷咨询语 */
    ChatSession open(Long itemId, Long buyerId, String firstQuestion);

    /** 我的客服会话列表（含对方信息与未读数）；管理员返回全站会话 */
    List<ChatSession> listMine(Long userId);

    /** 平台消息监管：全站会话列表（含买卖双方昵称、消息条数） */
    List<ChatSession> listAll();

    /** 某件商品的公开咨询消息：买家 / 卖家 / 管理员在详情页均可见 */
    List<ChatMessage> publicMessagesByItem(Long itemId);

    /** 平台消息监管：全站最近客服消息（含发送人身份与商品标题） */
    List<ChatMessage> recentMessages(int limit);

    /** 打开单个会话：校验归属并装配对方 / 物品信息 */
    ChatSession getForUser(Long sessionId, Long userId);

    /** 拉取会话消息；afterId 大于 0 时只返回增量消息，并把发给自己的消息标记已读 */
    List<ChatMessage> messages(Long sessionId, Long userId, Long afterId);

    /** 发送一条私信，同步更新会话预览、未读数与站内通知 */
    ChatMessage send(Long sessionId, Long userId, String content);

    /**
     * 从订单详情页发起「带订单咨询」：校验订单归属 → 复用该商品的买卖家会话
     * → 把订单卡片作为一条消息发给对方，返回会话 ID。买家 / 卖家 / 管理员均可发起。
     */
    Long openForOrder(Long orderId, Long userId);

    /** 在已有会话中重发订单卡片（聊天页「附上订单」按钮） */
    ChatMessage sendOrderCard(Long sessionId, Long userId, Long orderId);

    /** 会话最近一次关联的订单 ID，用于聊天页展示「附上订单」入口；没有则返回 null */
    Long latestOrderId(Long sessionId);

    /** 我所有客服会话的未读消息总数（导航栏红点） */
    long countUnread(Long userId);
}
