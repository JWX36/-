package com.example.demo.dto;

import java.io.Serializable;
import javax.validation.constraints.*;

/**
 * 商品评价 / 留言 / 回复表单：支持淘宝式五星评分与回复父级。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class MessageForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 物品 ID */
    @NotNull(message = "物品不存在")
    private Long itemId;

    /** 父留言 ID（回复时传入） */
    private Long parentId = 0L;

    /** 评价星级：1~5 星，默认 5 星 */
    @Min(value = 1, message = "评分至少 1 星")
    @Max(value = 5, message = "评分最多 5 星")
    private Integer rating = 5;

    /** 留言内容 */
    @NotBlank(message = "留言内容不能为空")
    @Size(max = 500, message = "留言最多 500 字")
    private String content;

    /** 获取物品 ID */
    public Long getItemId() {
        return itemId;
    }

    /** 设置物品 ID */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取父留言 ID */
    public Long getParentId() {
        return parentId;
    }

    /** 设置父留言 ID */
    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    /** 获取评价星级 */
    public Integer getRating() {
        return rating;
    }

    /** 设置评价星级 */
    public void setRating(Integer rating) {
        this.rating = rating;
    }

    /** 获取留言内容 */
    public String getContent() {
        return content;
    }

    /** 设置留言内容 */
    public void setContent(String content) {
        this.content = content;
    }

}
