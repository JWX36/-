package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.entity.ChatMessage;
import com.example.demo.entity.ChatSession;
import com.example.demo.entity.Item;
import com.example.demo.entity.TradeOrder;
import com.example.demo.entity.User;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.ChatMessageMapper;
import com.example.demo.mapper.ChatSessionMapper;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.mapper.TradeOrderMapper;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.ChatService;
import com.example.demo.service.support.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 客服会话业务实现。
 * 关键点：① 会话按 itemId + buyerId 复用，避免重复开会话；
 * ② 所有读写都做「会话参与人」归属校验（管理员作为平台客服监管可查看全部会话）；
 * ③ 消息 id 作为增量游标，前端轮询只取新消息；
 * ④ 发送后同步更新会话预览/未读数并写入站内通知，形成业务闭环；
 * ⑤ 公开咨询消息按商品汇总，买家 / 卖家 / 管理员在详情页均可见；
 * ⑥ 支持 ORDER 类型的「订单卡片」消息：订单详情页可带订单咨询卖家，聊天页可一键重发。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class ChatServiceImpl implements ChatService {

    private static final DateTimeFormatter CARD_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final ChatSessionMapper chatSessionMapper;
    private final ChatMessageMapper chatMessageMapper;
    private final ItemMapper itemMapper;
    private final TradeOrderMapper tradeOrderMapper;
    private final UserMapper userMapper;
    private final NotificationService notificationService;

    public ChatServiceImpl(ChatSessionMapper chatSessionMapper, ChatMessageMapper chatMessageMapper,
                           ItemMapper itemMapper, TradeOrderMapper tradeOrderMapper,
                           UserMapper userMapper, NotificationService notificationService) {
        this.chatSessionMapper = chatSessionMapper;
        this.chatMessageMapper = chatMessageMapper;
        this.itemMapper = itemMapper;
        this.tradeOrderMapper = tradeOrderMapper;
        this.userMapper = userMapper;
        this.notificationService = notificationService;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ChatSession open(Long itemId, Long buyerId, String firstQuestion) {
        Item item = itemMapper.selectById(itemId);
        if (item == null) {
            throw new BusinessException("物品不存在或已被删除");
        }
        if (item.getSellerId().equals(buyerId)) {
            throw new BusinessException("不能咨询自己发布的物品");
        }
        ChatSession session = ensureSession(item, buyerId);
        if (firstQuestion != null && !firstQuestion.trim().isEmpty()) {
            send(session.getId(), buyerId, firstQuestion.trim());
        }
        return session;
    }

    /**
     * 订单详情页「带订单咨询」：订单买家 / 卖家 / 管理员都能发起，
     * 复用该商品原有的买卖家会话，并把订单卡片作为一条消息发给对方。
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long openForOrder(Long orderId, Long userId) {
        TradeOrder order = tradeOrderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        boolean participant = userId.equals(order.getBuyerId()) || userId.equals(order.getSellerId());
        if (!participant && !isAdmin(userId)) {
            throw new BusinessException("无权咨询该订单");
        }
        if (order.getStatus() != null && (order.getStatus() == 3 || order.getStatus() == 4)) {
            throw new BusinessException("已取消的订单不能发起咨询，请先联系平台客服");
        }
        Item item = itemMapper.selectById(order.getItemId());
        if (item == null) {
            throw new BusinessException("订单关联的宝贝已下架，无法发起咨询");
        }
        ChatSession session = ensureSession(item, order.getBuyerId());
        sendOrderCard(session.getId(), userId, orderId);
        return session.getId();
    }

    /** 复用或创建会话：一个买家 + 一件商品 + 对应卖家只存在一条会话 */
    private ChatSession ensureSession(Item item, Long buyerId) {
        ChatSession session = chatSessionMapper.selectOne(new LambdaQueryWrapper<ChatSession>()
                .eq(ChatSession::getItemId, item.getId())
                .eq(ChatSession::getBuyerId, buyerId)
                .last("LIMIT 1"));
        if (session != null) {
            return session;
        }
        session = new ChatSession();
        session.setItemId(item.getId());
        session.setBuyerId(buyerId);
        session.setSellerId(item.getSellerId());
        session.setLastContent("会话已建立，向对方打个招呼吧～");
        session.setLastTime(LocalDateTime.now());
        session.setBuyerUnread(0);
        session.setSellerUnread(0);
        session.setCreateTime(LocalDateTime.now());
        session.setUpdateTime(LocalDateTime.now());
        chatSessionMapper.insert(session);
        return session;
    }

    @Override
    public List<ChatSession> listMine(Long userId) {
        // 管理员在「客服消息」页直接看到全站会话，便于平台监管与介入协调
        return isAdmin(userId) ? listAll() : chatSessionMapper.selectMine(userId);
    }

    @Override
    public List<ChatSession> listAll() {
        return chatSessionMapper.selectAll();
    }

    @Override
    public ChatSession getForUser(Long sessionId, Long userId) {
        ChatSession session = requireParticipant(sessionId, userId);
        fillSessionView(session, userId);
        return session;
    }

    @Override
    public List<ChatMessage> messages(Long sessionId, Long userId, Long afterId) {
        requireParticipant(sessionId, userId);
        List<ChatMessage> list = chatMessageMapper.selectAfter(sessionId, afterId == null ? 0L : afterId);
        chatMessageMapper.markRead(sessionId, userId);
        clearSessionUnread(sessionId, userId);
        for (ChatMessage msg : list) {
            msg.setMine(userId.equals(msg.getSenderId()));
        }
        return list;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ChatMessage send(Long sessionId, Long userId, String content) {
        ChatSession session = requireParticipant(sessionId, userId);
        if (content == null || content.trim().isEmpty()) {
            throw new BusinessException("消息内容不能为空");
        }
        String text = content.trim();
        if (text.length() > 500) {
            throw new BusinessException("单条消息最多 500 字");
        }
        return persistMessage(session, userId, text, "TEXT", null);
    }

    /** 在已有会话里发送订单卡片：校验订单确实属于该会话的买卖双方与商品 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ChatMessage sendOrderCard(Long sessionId, Long userId, Long orderId) {
        ChatSession session = requireParticipant(sessionId, userId);
        TradeOrder order = tradeOrderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        boolean related = order.getItemId().equals(session.getItemId())
                && (order.getBuyerId().equals(session.getBuyerId())
                || order.getSellerId().equals(session.getSellerId()));
        if (!related) {
            throw new BusinessException("该订单与当前会话无关，不能发送");
        }
        Item item = itemMapper.selectById(order.getItemId());
        String card = "订单号：" + order.getOrderNo() + "\n"
                + "宝贝：" + (item == null ? "闲置物品" : item.getTitle()) + "\n"
                + "金额：¥" + order.getAmount() + " × " + (order.getQuantity() == null ? 1 : order.getQuantity()) + "\n"
                + "状态：" + orderStatusText(order.getStatus()) + "\n"
                + "下单：" + (order.getCreateTime() == null ? "-" : order.getCreateTime().format(CARD_TIME));
        return persistMessage(session, userId, card, "ORDER", orderId);
    }

    @Override
    public Long latestOrderId(Long sessionId) {
        ChatMessage msg = chatMessageMapper.selectOne(new LambdaQueryWrapper<ChatMessage>()
                .eq(ChatMessage::getSessionId, sessionId)
                .eq(ChatMessage::getMsgType, "ORDER")
                .orderByDesc(ChatMessage::getId)
                .last("LIMIT 1"));
        return msg == null ? null : msg.getOrderId();
    }

    /**
     * 统一的消息落库逻辑（普通文本 / 订单卡片共用）：
     * 写消息 → 更新会话预览与未读数 → 装配发送人信息 → 给接收方写站内通知。
     */
    private ChatMessage persistMessage(ChatSession session, Long userId, String text,
                                       String msgType, Long orderId) {
        boolean buyerSide = userId.equals(session.getBuyerId());
        boolean sellerSide = userId.equals(session.getSellerId());
        boolean platform = !buyerSide && !sellerSide;     // 管理员以平台客服身份介入
        Long receiverId = platform ? session.getBuyerId()
                : (buyerSide ? session.getSellerId() : session.getBuyerId());

        ChatMessage msg = new ChatMessage();
        msg.setSessionId(session.getId());
        msg.setSenderId(userId);
        msg.setReceiverId(receiverId);
        msg.setContent(text);
        msg.setMsgType(msgType);
        msg.setOrderId(orderId);
        msg.setIsRead(0);
        msg.setCreateTime(LocalDateTime.now());
        chatMessageMapper.insert(msg);

        String preview = "ORDER".equals(msgType) ? "📦 分享了一笔订单，点开查看明细" : text;
        session.setLastContent(preview);
        session.setLastTime(msg.getCreateTime());
        session.setUpdateTime(msg.getCreateTime());
        int buyerUnread = session.getBuyerUnread() == null ? 0 : session.getBuyerUnread();
        int sellerUnread = session.getSellerUnread() == null ? 0 : session.getSellerUnread();
        if (platform) {
            // 平台客服发言对买卖双方都可见，双方各计一条未读
            session.setBuyerUnread(buyerUnread + 1);
            session.setSellerUnread(sellerUnread + 1);
        } else if (buyerSide) {
            session.setSellerUnread(sellerUnread + 1);
        } else {
            session.setBuyerUnread(buyerUnread + 1);
        }
        chatSessionMapper.updateById(session);

        User sender = userMapper.selectById(userId);
        msg.setSenderName(sender == null ? "同学" : sender.getRealName());
        msg.setSenderAvatar(sender == null ? "/images/default-avatar.svg" : sender.getAvatar());
        msg.setSenderRole(platform ? "平台客服" : (buyerSide ? "买家" : "卖家"));
        msg.setMine(true);
        Item item = itemMapper.selectById(session.getItemId());
        String itemTitle = item == null ? "闲置物品" : item.getTitle();
        String notice = (sender == null ? "同学" : sender.getRealName()) + " 在《" + itemTitle + "》中"
                + ("ORDER".equals(msgType) ? "分享了一笔订单" : "发来消息：" + text);
        notificationService.notifyUser(receiverId,
                "ORDER".equals(msgType) ? "收到订单卡片" : "收到新的客服消息", notice, "MESSAGE", false);
        if (platform) {
            notificationService.notifyUser(session.getSellerId(), "平台客服消息", notice, "MESSAGE", false);
        }
        return msg;
    }

    /** 订单卡片里的可读状态文案（与 layout.html 的 orderStatus 徽章保持一致） */
    private String orderStatusText(Integer status) {
        if (status == null) { return "未知"; }
        switch (status) {
            case 0: return "待支付";
            case 1: return "已支付待确认";
            case 2: return "已完成";
            case 3: return "已取消";
            case 4: return "超时取消";
            case 5: return "已退款";
            default: return "未知";
        }
    }

    @Override
    public List<ChatMessage> publicMessagesByItem(Long itemId) {
        return chatMessageMapper.selectPublicByItem(itemId);
    }

    @Override
    public List<ChatMessage> recentMessages(int limit) {
        return chatMessageMapper.selectRecent(Math.max(1, Math.min(limit, 100)));
    }

    @Override
    public long countUnread(Long userId) {
        long total = 0L;
        for (ChatSession session : chatSessionMapper.selectMine(userId)) {
            total += session.getUnread() == null ? 0 : session.getUnread();
        }
        return total;
    }

    /**
     * 会话归属校验：买家、卖家本人可读写；管理员（平台客服 / 消息监管）可查看全部会话。
     * 普通用户改 ID 访问他人聊天记录仍会被拦截，保证越权防护考点不被破坏。
     */
    private ChatSession requireParticipant(Long sessionId, Long userId) {
        ChatSession session = chatSessionMapper.selectById(sessionId);
        if (session == null) {
            throw new BusinessException("会话不存在");
        }
        if (!userId.equals(session.getBuyerId()) && !userId.equals(session.getSellerId())
                && !isAdmin(userId)) {
            throw new BusinessException("无权查看该会话");
        }
        return session;
    }

    /** 是否超级管理员（从用户表读取角色，避免依赖 Web 层上下文） */
    private boolean isAdmin(Long userId) {
        User user = userMapper.selectById(userId);
        return user != null && "ADMIN".equals(user.getRole());
    }

    /** 进入会话后把当前用户的未读计数清零 */
    private void clearSessionUnread(Long sessionId, Long userId) {
        ChatSession session = chatSessionMapper.selectById(sessionId);
        if (session == null) {
            return;
        }
        if (userId.equals(session.getBuyerId()) && session.getBuyerUnread() != null
                && session.getBuyerUnread() > 0) {
            session.setBuyerUnread(0);
            chatSessionMapper.updateById(session);
        } else if (userId.equals(session.getSellerId()) && session.getSellerUnread() != null
                && session.getSellerUnread() > 0) {
            session.setSellerUnread(0);
            chatSessionMapper.updateById(session);
        }
    }

    /** 装配聊天页需要的对方昵称/头像与物品信息（复用关联结果，避免多次查询） */
    private void fillSessionView(ChatSession session, Long userId) {
        boolean buyerSide = userId.equals(session.getBuyerId());
        boolean sellerSide = userId.equals(session.getSellerId());
        User buyer = userMapper.selectById(session.getBuyerId());
        User seller = userMapper.selectById(session.getSellerId());
        if (!buyerSide && !sellerSide) {
            // 管理员以平台客服身份查看：同时展示买家与卖家
            session.setPeerName("买家 " + (buyer == null ? "同学" : buyer.getRealName())
                    + " ↔ 卖家 " + (seller == null ? "同学" : seller.getRealName()));
            session.setPeerAvatar(buyer == null ? "/images/default-avatar.svg" : buyer.getAvatar());
            session.setPeerRole("PLATFORM");
        } else {
            User peer = buyerSide ? seller : buyer;
            session.setPeerName(peer == null ? "同学" : peer.getRealName());
            session.setPeerAvatar(peer == null ? "/images/default-avatar.svg" : peer.getAvatar());
            session.setPeerRole(buyerSide ? "SELLER" : "BUYER");
        }
        session.setUnread(0);
        Item item = itemMapper.selectById(session.getItemId());
        if (item != null) {
            session.setItemTitle(item.getTitle());
            session.setItemCover(item.getCoverImage());
            session.setItemPrice(item.getPrice());
        }
    }
}
