package com.example.demo.aspect;

import com.example.demo.entity.OperationLog;
import com.example.demo.mapper.OperationLogMapper;
import com.example.demo.util.UserContext;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

/**
 * 操作日志切面（AOP 考点）：统一记录所有 POST 写操作的操作人、URI、IP 与耗时。
 * 日志写入失败只打印告警，绝不影响业务请求。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Aspect
@Component
public class OperationLogAspect {

    private static final Logger log = LoggerFactory.getLogger(OperationLogAspect.class);

    private final OperationLogMapper operationLogMapper;
    private final UserContext userContext;

    public OperationLogAspect(OperationLogMapper operationLogMapper, UserContext userContext) {
        this.operationLogMapper = operationLogMapper;
        this.userContext = userContext;
    }

    /** 切点：controller 包下所有标注 @PostMapping 的方法 */
    @Pointcut("execution(* com.example.demo.controller..*(..)) "
            + "&& @annotation(org.springframework.web.bind.annotation.PostMapping)")
    public void writeOperation() {
    }

    /** 环绕通知：无论成功或异常都记录日志 */
    @Around("writeOperation()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        try {
            return joinPoint.proceed();
        } finally {
            try {
                saveLog(joinPoint, System.currentTimeMillis() - start);
            } catch (Exception e) {
                log.warn("操作日志写入失败：{}", e.getMessage());
            }
        }
    }

    /** 组装并持久化操作日志 */
    private void saveLog(ProceedingJoinPoint joinPoint, long costMs) {
        OperationLog record = new OperationLog();
        record.setUsername(userContext.currentUsername());
        record.setOperation(joinPoint.getSignature().getDeclaringType().getSimpleName()
                + "." + joinPoint.getSignature().getName());
        record.setCreateTime(LocalDateTime.now());
        record.setCostMs(costMs);
        ServletRequestAttributes attributes =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes != null) {
            HttpServletRequest request = attributes.getRequest();
            record.setRequestMethod(request.getMethod());
            record.setRequestUri(request.getRequestURI());
            String ip = request.getHeader("X-Forwarded-For");
            record.setIp(ip == null || ip.isEmpty() ? request.getRemoteAddr() : ip.split(",")[0].trim());
        } else {
            record.setRequestMethod("POST");
            record.setRequestUri("-");
            record.setIp("-");
        }
        operationLogMapper.insert(record);
    }
}
