package com.example.demo.service.support;

import com.example.demo.config.RabbitConfig;
import com.example.demo.util.CacheJson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 基于 RabbitMQ 的真实异步事件发布实现（高阶考点）。
 * 消息体统一为 JSON 字符串，投递失败仅记录日志，不影响主交易流程。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
@ConditionalOnProperty(prefix = "app.feature", name = "mq-enabled", havingValue = "true")
public class RabbitEventPublisher implements EventPublisher {

    private static final Logger log = LoggerFactory.getLogger(RabbitEventPublisher.class);

    private final RabbitTemplate rabbitTemplate;
    private final EventProcessor eventProcessor;

    public RabbitEventPublisher(RabbitTemplate rabbitTemplate, EventProcessor eventProcessor) {
        this.rabbitTemplate = rabbitTemplate;
        this.eventProcessor = eventProcessor;
    }

    /** 把事件投递到 Topic 交换机，由 OrderEventConsumer 异步消费 */
    @Override
    public void publish(String eventType, Map<String, Object> payload) {
        try {
            rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE, eventType, CacheJson.write(payload));
            log.info("MQ 事件已投递：{}", eventType);
        } catch (Exception e) {
            // 消息中间件不可用时降级为本地处理，保证通知不丢失、业务不中断
            log.warn("MQ 暂不可用，事件 {} 降级为本地处理：{}", eventType, e.getMessage());
            eventProcessor.handle(eventType, payload);
        }
    }
}
