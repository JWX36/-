package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.User;

/**
 * 用户数据访问层，单表 CRUD 由 MyBatis-Plus BaseMapper 提供。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface UserMapper extends BaseMapper<User> {
}
