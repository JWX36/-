package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 用户实体，对应 tb_user。系统包含 USER / SELLER / ADMIN 三级角色，密码使用 BCrypt 加密存储。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_user")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 登录账号（唯一） */
    private String username;

    /** BCrypt 加密后的密码 */
    private String password;

    /** 真实姓名 / 昵称 */
    private String realName;

    /** 邮箱，用于接收订单与审核通知 */
    private String email;

    /** 手机号 */
    private String phone;

    /** 头像相对访问路径 */
    private String avatar;

    /** 角色：USER 普通用户 / SELLER 认证卖家 / ADMIN 超级管理员 */
    private String role;

    /** 状态：1 正常，0 禁用 */
    private Integer status;

    /** 注册时间 */
    private LocalDateTime createTime;

    /** 最后更新时间 */
    private LocalDateTime updateTime;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取登录账号（唯一） */
    public String getUsername() {
        return username;
    }

    /** 设置登录账号（唯一） */
    public void setUsername(String username) {
        this.username = username;
    }

    /** 获取BCrypt 加密后的密码 */
    public String getPassword() {
        return password;
    }

    /** 设置BCrypt 加密后的密码 */
    public void setPassword(String password) {
        this.password = password;
    }

    /** 获取真实姓名 / 昵称 */
    public String getRealName() {
        return realName;
    }

    /** 设置真实姓名 / 昵称 */
    public void setRealName(String realName) {
        this.realName = realName;
    }

    /** 获取邮箱，用于接收订单与审核通知 */
    public String getEmail() {
        return email;
    }

    /** 设置邮箱，用于接收订单与审核通知 */
    public void setEmail(String email) {
        this.email = email;
    }

    /** 获取手机号 */
    public String getPhone() {
        return phone;
    }

    /** 设置手机号 */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /** 获取头像相对访问路径 */
    public String getAvatar() {
        return avatar;
    }

    /** 设置头像相对访问路径 */
    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    /** 获取角色：USER 普通用户 / SELLER 认证卖家 / ADMIN 超级管理员 */
    public String getRole() {
        return role;
    }

    /** 设置角色：USER 普通用户 / SELLER 认证卖家 / ADMIN 超级管理员 */
    public void setRole(String role) {
        this.role = role;
    }

    /** 获取状态：1 正常，0 禁用 */
    public Integer getStatus() {
        return status;
    }

    /** 设置状态：1 正常，0 禁用 */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /** 获取注册时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置注册时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    /** 获取最后更新时间 */
    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    /** 设置最后更新时间 */
    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

}
