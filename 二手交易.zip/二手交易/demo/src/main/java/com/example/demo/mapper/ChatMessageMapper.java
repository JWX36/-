package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.ChatMessage;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 客服私信数据访问层：增量拉取与批量已读见 mapper/ChatMessageMapper.xml。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface ChatMessageMapper extends BaseMapper<ChatMessage> {

    /** 会话消息；afterId 大于 0 时只取新消息，实现前端轮询 */
    List<ChatMessage> selectAfter(@Param("sessionId") Long sessionId,
                                  @Param("afterId") Long afterId);

    /** 进入聊天页后，把发给自己的消息批量标记已读（防越权） */
    int markRead(@Param("sessionId") Long sessionId,
                 @Param("receiverId") Long receiverId);

    /** 某件商品的公开咨询消息：带发送人身份，买家 / 卖家 / 管理员均可见 */
    List<ChatMessage> selectPublicByItem(@Param("itemId") Long itemId);

    /** 全站最近客服消息：后台消息监管页使用 */
    List<ChatMessage> selectRecent(@Param("limit") int limit);
}
