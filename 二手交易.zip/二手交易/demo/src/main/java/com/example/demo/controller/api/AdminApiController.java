package com.example.demo.controller.api;

import com.example.demo.common.Result;
import com.example.demo.service.DashboardService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 后台统计 REST 接口：为 ECharts 数据看板提供 JSON 数据（统一 Result 封装）。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminApiController {

    private final DashboardService dashboardService;

    public AdminApiController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    /** 概览指标 */
    @GetMapping("/dashboard/summary")
    public Result<Map<String, Object>> summary() {
        return Result.ok(dashboardService.summary());
    }

    /** 图表数据：交易金额趋势、用户增长、分类占比 */
    @GetMapping("/dashboard/charts")
    public Result<Map<String, Object>> charts(
            @RequestParam(value = "days", defaultValue = "7") int days) {
        return Result.ok(dashboardService.charts(days));
    }
}
