package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Spring Security 安全配置（进阶/高阶考点：自定义登录页 + 三级角色 + 菜单级与接口级双重权限）。
 * 角色层级通过 hasAnyRole 显式授权，避免版本差异导致的兼容问题。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final AppProperties appProperties;

    public SecurityConfig(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    /**
     * 配置 URL 级权限、自定义登录页、退出、记住我、拒绝访问页与 CSRF 策略。
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                // ① 公共资源：首页、物品浏览、注册登录、静态资源、演示用 H2 控制台
                .antMatchers("/", "/index", "/items", "/items/list", "/items/detail/**", "/search",
                        "/login", "/register", "/do-register", "/403", "/error",
                        "/css/**", "/js/**", "/images/**", "/photos/**", "/uploads/**", "/favicon.ico",
                        "/h2-console/**", "/api/public/**").permitAll()
                // ② 后台管理端 + 统计接口：仅超级管理员
                .antMatchers("/admin/**", "/api/admin/**").hasRole("ADMIN")
                // ③ 认证卖家专属模块
                .antMatchers("/seller/**").hasAnyRole("SELLER", "ADMIN")
                // ④ 登录用户模块：发布、留言、下单、购物车、个人中心、评价、收藏、客服会话
                .antMatchers("/user/**", "/items/publish", "/items/edit/**", "/items/save",
                        "/items/off-shelf/**", "/items/mine", "/items/images/**", "/items/comments/**",
                        "/messages/**", "/orders/**", "/refunds/**", "/cart/**", "/notices/**",
                        "/chat/**", "/favorites/**",
                        "/api/user/**", "/api/cart/**", "/api/chat/**", "/api/favorites/**")
                .hasAnyRole("USER", "SELLER", "ADMIN")
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .usernameParameter("username")
                .passwordParameter("password")
                // false = 使用 SavedRequest：从「查看评价 / 联系卖家」被拦截到登录后自动跳回原页面
                .defaultSuccessUrl("/", false)
                .failureUrl("/login?error")
                .permitAll()
                .and()
                .logout()
                .logoutUrl("/logout")
                .logoutSuccessUrl("/?logout")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID", "remember-me")
                .permitAll()
                .and()
                .rememberMe()
                .key(appProperties.getSecurity().getRememberMeKey())
                .tokenValiditySeconds(7 * 24 * 60 * 60)
                .and()
                .exceptionHandling()
                .accessDeniedPage("/403")
                .and()
                // H2 控制台使用 iframe，必须放开同源 frame 限制
                .headers().frameOptions().sameOrigin()
                .and()
                // REST 接口与 H2 控制台不使用 CSRF；Thymeleaf 页面表单保留 CSRF 令牌
                .csrf().ignoringAntMatchers("/h2-console/**", "/api/**");
        return http.build();
    }
}
