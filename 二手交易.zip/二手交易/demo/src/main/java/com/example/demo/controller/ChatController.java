package com.example.demo.controller;

import com.example.demo.dto.ChatForm;
import com.example.demo.entity.ChatMessage;
import com.example.demo.entity.ChatSession;
import com.example.demo.exception.BusinessException;
import com.example.demo.service.ChatService;
import com.example.demo.util.UserContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

/**
 * 买卖家客服页面控制器（淘宝「联系卖家 / 客服消息」）。
 * /chat/start/{itemId} 由 Spring Security 保护：未登录点击「联系卖家」会先跳登录，
 * 登录成功后由 SavedRequest 自动跳回并创建会话，体验与淘宝一致。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
@RequestMapping("/chat")
public class ChatController {

    private final ChatService chatService;
    private final UserContext userContext;

    public ChatController(ChatService chatService, UserContext userContext) {
        this.chatService = chatService;
        this.userContext = userContext;
    }

    /** 我的客服会话列表；管理员默认看到全站会话（平台消息监管视角） */
    @GetMapping
    public String list(Model model) {
        Long userId = userContext.currentUserId();
        model.addAttribute("sessions", chatService.listMine(userId));
        model.addAttribute("unreadTotal", chatService.countUnread(userId));
        model.addAttribute("platformView", userContext.isAdmin());
        return "chat/list";
    }

    /** 从商品详情页发起咨询：复用会话 + 携带快捷咨询语 */
    @GetMapping("/start/{itemId}")
    public String start(@PathVariable("itemId") Long itemId,
                        @RequestParam(value = "q", required = false) String question,
                        RedirectAttributes redirectAttributes) {
        try {
            ChatSession session = chatService.open(itemId, userContext.currentUserId(), question);
            return "redirect:/chat/" + session.getId();
        } catch (BusinessException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/items/detail/" + itemId;
        }
    }

    /** 聊天窗口：左侧会话列表 + 右侧消息气泡，消息由 JS 轮询增量拉取 */
    @GetMapping("/{sessionId}")
    public String room(@PathVariable("sessionId") Long sessionId, Model model) {
        Long userId = userContext.currentUserId();
        ChatSession session = chatService.getForUser(sessionId, userId);
        List<ChatMessage> messages = chatService.messages(sessionId, userId, 0L);
        // 变量名不能叫 session：Thymeleaf 中 session 是内置隐式对象（HttpSession 属性 Map），
        // 会遮蔽 Controller 传入的 ChatSession，导致 ${session.id} 取到空值，
        // 进而让 data-chat / 表单 action / 对方昵称 / 商品标题全部失效，消息发不出去。
        model.addAttribute("chatSession", session);
        model.addAttribute("messages", messages);
        model.addAttribute("sessions", chatService.listMine(userId));
        model.addAttribute("platformView", userContext.isAdmin());
        model.addAttribute("chatForm", new ChatForm());
        model.addAttribute("maxId", messages.isEmpty() ? 0L : messages.get(messages.size() - 1).getId());
        // 会话里最近分享过的订单：聊天页据此显示「附上订单」快捷入口
        model.addAttribute("relatedOrderId", chatService.latestOrderId(sessionId));
        return "chat/room";
    }

    /** 表单兜底发送（JavaScript 被禁用时仍可用；正常情况由 /api/chat 无刷新接管） */
    @PostMapping("/{sessionId}/send")
    public String send(@PathVariable("sessionId") Long sessionId,
                       @RequestParam(value = "content", required = false) String content,
                       RedirectAttributes redirectAttributes) {
        try {
            chatService.send(sessionId, userContext.currentUserId(), content);
        } catch (BusinessException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/chat/" + sessionId;
    }
}
