package com.example.demo.controller;

import com.example.demo.dto.RegisterForm;
import com.example.demo.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

/**
 * 认证页面控制器：自定义登录页（Spring Security 接管 POST /login）与用户注册。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    /** 登录页；表单提交地址由 Spring Security 的 loginProcessingUrl 处理 */
    @GetMapping("/login")
    public String login() {
        return "auth/login";
    }

    /** 注册页 */
    @GetMapping("/register")
    public String register(Model model) {
        if (!model.containsAttribute("registerForm")) {
            model.addAttribute("registerForm", new RegisterForm());
        }
        return "auth/register";
    }

    /** 注册提交：JSR-303 校验 + 账号唯一性校验，成功后跳转登录页 */
    @PostMapping("/do-register")
    public String doRegister(@Valid @ModelAttribute("registerForm") RegisterForm form,
                             BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("errorMessage", bindingResult.getFieldError() == null
                    ? "请检查表单填写" : bindingResult.getFieldError().getDefaultMessage());
            return "auth/register";
        }
        try {
            userService.register(form);
        } catch (RuntimeException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return "auth/register";
        }
        return "redirect:/login?registered";
    }
}
