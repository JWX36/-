package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.Message;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 留言数据访问层，关联用户表与物品表的查询定义在 mapper/MessageMapper.xml。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface MessageMapper extends BaseMapper<Message> {

    /** 某物品下的全部留言及回复（带留言人昵称、头像） */
    List<Message> selectItemMessages(@Param("itemId") Long itemId);

    /** 与我相关的留言（我发出的 + 收到的），带物品标题 */
    List<Message> selectUserMessages(@Param("userId") Long userId);

    /** 平台消息监管：全站最近评价 / 留言（带留言人与商品标题） */
    List<Message> selectRecentComments(@Param("limit") int limit);
}
