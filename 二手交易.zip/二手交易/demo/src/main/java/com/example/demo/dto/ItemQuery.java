package com.example.demo.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.validation.constraints.*;

/**
 * 物品检索条件，全部条件均为可选，交给 MyBatis 动态 SQL 拼装。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class ItemQuery implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 标题 / 描述关键词 */
    private String keyword;

    /** 分类 ID */
    private Long categoryId;

    /** 最低价格 */
    private BigDecimal minPrice;

    /** 最高价格 */
    private BigDecimal maxPrice;

    /** 物品状态（后台使用） */
    private Integer status;

    /** 卖家 ID（我的发布使用） */
    private Long sellerId;

    /** 排序方式：newest / priceAsc / priceDesc / hot */
    private String sortBy = "newest";

    /** 页码 */
    @Min(value = 1, message = "页码必须大于 0")
    private Integer pageNum = 1;

    /** 每页条数 */
    @Min(value = 1, message = "每页条数必须大于 0")
    private Integer pageSize = 8;

    /** 获取标题 / 描述关键词 */
    public String getKeyword() {
        return keyword;
    }

    /** 设置标题 / 描述关键词 */
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    /** 获取分类 ID */
    public Long getCategoryId() {
        return categoryId;
    }

    /** 设置分类 ID */
    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    /** 获取最低价格 */
    public BigDecimal getMinPrice() {
        return minPrice;
    }

    /** 设置最低价格 */
    public void setMinPrice(BigDecimal minPrice) {
        this.minPrice = minPrice;
    }

    /** 获取最高价格 */
    public BigDecimal getMaxPrice() {
        return maxPrice;
    }

    /** 设置最高价格 */
    public void setMaxPrice(BigDecimal maxPrice) {
        this.maxPrice = maxPrice;
    }

    /** 获取物品状态（后台使用） */
    public Integer getStatus() {
        return status;
    }

    /** 设置物品状态（后台使用） */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /** 获取卖家 ID（我的发布使用） */
    public Long getSellerId() {
        return sellerId;
    }

    /** 设置卖家 ID（我的发布使用） */
    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    /** 获取排序方式：newest / priceAsc / priceDesc / hot */
    public String getSortBy() {
        return sortBy;
    }

    /** 设置排序方式：newest / priceAsc / priceDesc / hot */
    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    /** 获取页码 */
    public Integer getPageNum() {
        return pageNum;
    }

    /** 设置页码 */
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    /** 获取每页条数 */
    public Integer getPageSize() {
        return pageSize;
    }

    /** 设置每页条数 */
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

}
