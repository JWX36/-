package com.example.demo.dto;

import java.io.Serializable;
import javax.validation.constraints.*;

/**
 * 密码修改表单。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class PasswordForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 原密码 */
    @NotBlank(message = "请输入原密码")
    private String oldPassword;

    /** 新密码 */
    @NotBlank(message = "请输入新密码")
    @Size(min = 6, max = 20, message = "新密码长度需在 6~20 位之间")
    private String newPassword;

    /** 确认新密码 */
    @NotBlank(message = "请再次输入新密码")
    private String confirmPassword;

    /** 获取原密码 */
    public String getOldPassword() {
        return oldPassword;
    }

    /** 设置原密码 */
    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    /** 获取新密码 */
    public String getNewPassword() {
        return newPassword;
    }

    /** 设置新密码 */
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    /** 获取确认新密码 */
    public String getConfirmPassword() {
        return confirmPassword;
    }

    /** 设置确认新密码 */
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

}
