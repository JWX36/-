package com.example.demo.controller;

import com.example.demo.dto.ItemQuery;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ItemService;
import com.example.demo.util.UserContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 首页与公共错误页控制器。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
public class HomeController {

    private final ItemService itemService;
    private final CategoryService categoryService;
    private final UserContext userContext;

    public HomeController(ItemService itemService, CategoryService categoryService, UserContext userContext) {
        this.itemService = itemService;
        this.categoryService = categoryService;
        this.userContext = userContext;
    }

    /** 首页：分类导航 + 最新在售物品分页 + 热点物品（缓存） */
    @GetMapping("/")
    public String index(ItemQuery query, Model model) {
        query.setPageSize(8);
        model.addAttribute("items", itemService.search(query, 1));
        model.addAttribute("hotItems", itemService.hotItems(5));
        model.addAttribute("query", query);
        model.addAttribute("pageBase", "/?_=1");
        model.addAttribute("categoryCount", categoryService.listAll().size());
        model.addAttribute("loggedIn", userContext.currentUserOrNull() != null);
        return "index";
    }

    /** 兼容直接访问 /index */
    @GetMapping("/index")
    public String indexAlias() {
        return "redirect:/";
    }

    /** 权限不足提示页 */
    @GetMapping("/403")
    public String forbidden() {
        return "error/403";
    }
}
