package com.example.demo.controller.api;

import com.example.demo.common.Result;
import com.example.demo.service.FavoriteService;
import com.example.demo.util.UserContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 商品收藏 REST 接口：详情页心形按钮无刷新切换，实时返回最新「想要人数」。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@RestController
@RequestMapping("/api/favorites")
public class FavoriteApiController {

    private final FavoriteService favoriteService;
    private final UserContext userContext;

    public FavoriteApiController(FavoriteService favoriteService, UserContext userContext) {
        this.favoriteService = favoriteService;
        this.userContext = userContext;
    }

    /** 收藏 / 取消收藏，返回 {favorited, count} */
    @PostMapping("/toggle/{itemId}")
    public Result<Map<String, Object>> toggle(@PathVariable("itemId") Long itemId) {
        boolean favorited = favoriteService.toggle(userContext.currentUserId(), itemId);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("favorited", favorited);
        data.put("count", favoriteService.countByItem(itemId));
        return Result.ok(data);
    }

    /** 查询某物品的想要人数 */
    @GetMapping("/count/{itemId}")
    public Result<Long> count(@PathVariable("itemId") Long itemId) {
        return Result.ok(favoriteService.countByItem(itemId));
    }
}
