package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * 密码编码器配置。全系统只允许使用 BCrypt 存储密码，禁止明文。
 * 单独成类可避免与安全配置、用户服务之间出现 Bean 创建循环依赖。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Configuration
public class PasswordConfig {

    /** BCrypt 强度 10，注册、改密、SQL 初始账号均使用同一算法 */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(10);
    }
}
