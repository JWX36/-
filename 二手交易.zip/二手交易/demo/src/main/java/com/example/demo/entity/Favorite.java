package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 商品收藏 / 想要（用户 + 物品唯一），对应 tb_favorite。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_favorite")
public class Favorite implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 收藏人 ID */
    private Long userId;

    /** 物品 ID */
    private Long itemId;

    /** 收藏时间 */
    private LocalDateTime createTime;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取收藏人 ID */
    public Long getUserId() {
        return userId;
    }

    /** 设置收藏人 ID */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /** 获取物品 ID */
    public Long getItemId() {
        return itemId;
    }

    /** 设置物品 ID */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取收藏时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置收藏时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

}
