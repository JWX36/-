package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.entity.TradeOrder;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 订单数据访问层，关联查询与超时扫描定义在 mapper/TradeOrderMapper.xml。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface TradeOrderMapper extends BaseMapper<TradeOrder> {

    /** 订单详情（带买家/卖家昵称与物品信息） */
    TradeOrder selectDetail(@Param("id") Long id);

    /** 后台订单分页：可按买家、卖家、状态过滤 */
    IPage<TradeOrder> selectOrderPage(IPage<TradeOrder> page,
                                      @Param("buyerId") Long buyerId,
                                      @Param("sellerId") Long sellerId,
                                      @Param("status") Integer status);

    /** 扫描超过支付时限仍未支付的订单，供定时任务自动取消 */
    List<TradeOrder> selectTimeoutOrders(@Param("deadline") LocalDateTime deadline);
}
