package com.example.demo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Spring MVC 扩展配置：把「工程根目录下独立的素材目录」映射成 /photos/** 与 /uploads/** 静态资源。
 *
 * <p>设计要点（换电脑 / 换目录 / 直接跑 jar 都不会丢图）：
 * <ol>
 *     <li>实拍照片源文件放在 demo/assets/photos/，与 Spring 框架源码目录 src/main 完全分离；</li>
 *     <li>运行时按多个候选工作目录自动定位素材目录（IDEA 打开 demo 或打开外层目录都能命中）；</li>
 *     <li>构建期 pom.xml 会把同一批照片复制进 classpath:/static/photos/，
 *         即使只拷走 jar、不带 assets 目录，也能从 jar 内部回退加载照片。</li>
 * </ol>
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private static final Logger log = LoggerFactory.getLogger(WebMvcConfig.class);

    private final AppProperties appProperties;

    public WebMvcConfig(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    /** 注册独立照片目录与上传目录的多路径静态资源映射 */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // ① 平台内置实拍照片：文件目录优先，jar 内 classpath 副本兜底
        List<String> photoLocations = candidateLocations(appProperties.getPhotos().getDir());
        photoLocations.add("classpath:/static/photos/");
        registry.addResourceHandler(appProperties.getPhotos().getPublicPath())
                .addResourceLocations(photoLocations.toArray(new String[0]))
                .setCachePeriod(3600);

        // ② 卖家自主上传的图片：定位到工程目录，不写入 target/classes，mvn clean 不会丢失
        List<String> uploadLocations = candidateLocations(appProperties.getUpload().getDir());
        registry.addResourceHandler(appProperties.getUpload().getPublicPath())
                .addResourceLocations(uploadLocations.toArray(new String[0]))
                .setCachePeriod(0);

        log.info("实拍照片目录已映射：{} -> {}", appProperties.getPhotos().getPublicPath(), photoLocations);
        log.info("卖家上传目录已映射：{} -> {}", appProperties.getUpload().getPublicPath(), uploadLocations);
    }

    /**
     * 生成候选目录的绝对 file: URL。
     * 覆盖三种常见启动位置：demo/（IDEA 打开内层）、外层项目目录（IDEA 打开外层）、
     * 以及 demo/ 的同级目录，保证相对路径变化后仍能找到同一批图片文件。
     */
    private List<String> candidateLocations(String configuredDir) {
        String clean = configuredDir == null ? "" : configuredDir.trim().replace('\\', '/');
        while (clean.startsWith("./")) {
            clean = clean.substring(2);
        }
        Set<String> candidates = new LinkedHashSet<>();
        candidates.add(clean);
        candidates.add("demo/" + clean);
        candidates.add("../" + clean);
        candidates.add("../demo/" + clean);

        List<String> locations = new ArrayList<>();
        for (String candidate : candidates) {
            try {
                Path path = Paths.get(candidate).toAbsolutePath().normalize();
                String uri = path.toUri().toString();
                if (!uri.endsWith("/")) {
                    uri = uri + "/";
                }
                locations.add(uri);
            } catch (Exception e) {
                log.warn("跳过不可用的素材目录 {}：{}", candidate, e.getMessage());
            }
        }
        return locations;
    }
}
