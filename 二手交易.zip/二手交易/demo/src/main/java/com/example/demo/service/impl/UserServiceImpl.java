package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.dto.PageQuery;
import com.example.demo.dto.PasswordForm;
import com.example.demo.dto.ProfileForm;
import com.example.demo.dto.RegisterForm;
import com.example.demo.entity.User;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * 用户模块业务实现。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class UserServiceImpl implements UserService {

    /** 允许分配的角色白名单，防止越权把自己提升为管理员 */
    private static final Set<String> ALLOWED_ROLES = new HashSet<>(Arrays.asList("USER", "SELLER", "ADMIN"));

    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserMapper userMapper, PasswordEncoder passwordEncoder) {
        this.userMapper = userMapper;
        this.passwordEncoder = passwordEncoder;
    }

    /** 注册：校验账号唯一、两次密码一致，密码必须用 BCrypt 加密后入库 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void register(RegisterForm form) {
        if (!form.getPassword().equals(form.getConfirmPassword())) {
            throw new BusinessException("两次输入的密码不一致");
        }
        Long exists = userMapper.selectCount(new LambdaQueryWrapper<User>()
                .eq(User::getUsername, form.getUsername()));
        if (exists != null && exists > 0) {
            throw new BusinessException("该账号已被注册，请更换账号");
        }
        User user = new User();
        user.setUsername(form.getUsername().trim());
        user.setPassword(passwordEncoder.encode(form.getPassword()));
        user.setRealName(form.getRealName());
        user.setEmail(form.getEmail());
        user.setPhone(form.getPhone());
        user.setAvatar("/images/default-avatar.svg");
        user.setRole("USER");
        user.setStatus(1);
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());
        userMapper.insert(user);
    }

    @Override
    public User findByUsername(String username) {
        if (!StringUtils.hasText(username)) {
            return null;
        }
        return userMapper.selectOne(new LambdaQueryWrapper<User>()
                .eq(User::getUsername, username)
                .last("LIMIT 1"));
    }

    @Override
    public User getById(Long id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        return user;
    }

    @Override
    public void updateProfile(Long userId, ProfileForm form) {
        User user = getById(userId);
        user.setRealName(form.getRealName());
        user.setEmail(form.getEmail());
        user.setPhone(form.getPhone());
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);
    }

    /** 改密必须校验原密码，禁止明文存储新密码 */
    @Override
    public void changePassword(Long userId, PasswordForm form) {
        User user = getById(userId);
        if (!passwordEncoder.matches(form.getOldPassword(), user.getPassword())) {
            throw new BusinessException("原密码不正确");
        }
        if (!form.getNewPassword().equals(form.getConfirmPassword())) {
            throw new BusinessException("两次输入的新密码不一致");
        }
        user.setPassword(passwordEncoder.encode(form.getNewPassword()));
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);
    }

    @Override
    public void updateAvatar(Long userId, String avatarUrl) {
        User user = getById(userId);
        user.setAvatar(avatarUrl);
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);
    }

    /** 后台用户分页：支持账号/昵称模糊搜索与角色筛选 */
    @Override
    public IPage<User> pageUsers(PageQuery query, String keyword, String role) {
        Page<User> page = new Page<>(query.getPageNum(), query.getPageSize());
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            wrapper.and(w -> w.like(User::getUsername, keyword).or().like(User::getRealName, keyword));
        }
        if (StringUtils.hasText(role)) {
            wrapper.eq(User::getRole, role);
        }
        wrapper.orderByDesc(User::getCreateTime, User::getId);
        return userMapper.selectPage(page, wrapper);
    }

    @Override
    public void changeStatus(Long id, Integer status) {
        User user = getById(id);
        user.setStatus(status == null ? 1 : status);
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);
    }

    /** 角色变更使用白名单校验，避免传入非法角色造成权限提升 */
    @Override
    public void changeRole(Long id, String role) {
        if (!ALLOWED_ROLES.contains(role)) {
            throw new BusinessException("角色值不合法");
        }
        User user = getById(id);
        user.setRole(role);
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);
    }
}
