package com.example.demo.service.support;

import com.example.demo.config.AppProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * 邮件发送服务（进阶考点：Spring Task + JavaMailSender）。
 * 只有 app.feature.mail-enabled=true 且配置了 SMTP 账号时才真正发信；
 * 发送过程 @Async 异步执行且捕获全部异常，绝不影响下单、审核等主流程。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class MailService {

    private static final Logger log = LoggerFactory.getLogger(MailService.class);

    private final ObjectProvider<JavaMailSender> mailSenderProvider;
    private final AppProperties appProperties;

    /** 发件人邮箱，取自 spring.mail.username，未配置时留空 */
    @Value("${spring.mail.username:}")
    private String mailFrom;

    public MailService(ObjectProvider<JavaMailSender> mailSenderProvider, AppProperties appProperties) {
        this.mailSenderProvider = mailSenderProvider;
        this.appProperties = appProperties;
    }

    /**
     * 异步发送纯文本邮件提醒。
     *
     * @param to      收件人
     * @param subject 主题
     * @param text    正文
     */
    @Async
    public void sendAsync(String to, String subject, String text) {
        if (!appProperties.getFeature().isMailEnabled()) {
            log.debug("邮件功能未开启，仅保留站内通知：{} -> {}", subject, to);
            return;
        }
        if (to == null || to.isEmpty()) {
            return;
        }
        try {
            JavaMailSender sender = mailSenderProvider.getIfAvailable();
            if (sender == null) {
                log.warn("未找到 JavaMailSender，跳过邮件发送");
                return;
            }
            SimpleMailMessage message = new SimpleMailMessage();
            if (mailFrom != null && !mailFrom.isEmpty()) {
                message.setFrom(mailFrom);
            }
            message.setTo(to);
            message.setSubject("【校园二手集市】" + subject);
            message.setText(text);
            sender.send(message);
            log.info("邮件已发送：{} -> {}", subject, to);
        } catch (Exception e) {
            // 邮箱未配置 / SMTP 不通时只告警，站内信仍已落库
            log.warn("邮件发送失败（不影响业务）：{}", e.getMessage());
        }
    }
}
