package com.example.demo.util;

import com.example.demo.exception.BusinessException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 缓存与消息体共用的 JSON 工具。
 * 独立构造 ObjectMapper 并注册 JavaTimeModule，确保 LocalDateTime 字段可序列化、可反序列化，
 * 且不受 application.yml 中 spring.jackson.date-format 的影响。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public final class CacheJson {

    private static final Logger log = LoggerFactory.getLogger(CacheJson.class);

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

    private CacheJson() {
        // 工具类禁止实例化
    }

    /** 对象转 JSON 字符串 */
    public static String write(Object value) {
        try {
            return MAPPER.writeValueAsString(value);
        } catch (Exception e) {
            log.error("JSON 序列化失败", e);
            throw new BusinessException("数据转换失败，请稍后重试");
        }
    }

    /** JSON 转普通对象 */
    public static <T> T read(String json, Class<T> type) {
        if (json == null || json.isEmpty()) {
            return null;
        }
        try {
            return MAPPER.readValue(json, type);
        } catch (Exception e) {
            log.error("JSON 反序列化失败", e);
            return null;
        }
    }

    /** JSON 转泛型集合（如 List&lt;Long&gt;） */
    public static <T> T read(String json, TypeReference<T> type) {
        if (json == null || json.isEmpty()) {
            return null;
        }
        try {
            return MAPPER.readValue(json, type);
        } catch (Exception e) {
            log.error("JSON 泛型反序列化失败", e);
            return null;
        }
    }
}
