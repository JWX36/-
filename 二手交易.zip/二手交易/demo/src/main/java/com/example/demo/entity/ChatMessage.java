package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 客服会话内的单条私信（支持轮询增量拉取），对应 tb_chat_message。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_chat_message")
public class ChatMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键，同时作为增量拉取游标 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 所属会话 ID */
    private Long sessionId;

    /** 发送人 ID */
    private Long senderId;

    /** 接收人 ID */
    private Long receiverId;

    /** 消息正文（订单卡片为格式化摘要） */
    private String content;

    /** 消息类型：TEXT 普通文本 / ORDER 订单卡片 */
    private String msgType;

    /** 订单卡片关联的订单 ID，普通消息为 null */
    private Long orderId;

    /** 是否已读：1 是，0 否 */
    private Integer isRead;

    /** 发送时间 */
    private LocalDateTime createTime;

    /** 非数据库字段：发送人昵称（关联查询） */
    @TableField(exist = false)
    private String senderName;

    /** 非数据库字段：发送人头像（关联查询） */
    @TableField(exist = false)
    private String senderAvatar;

    /** 非数据库字段：是否为当前登录人发出（用于气泡左右分栏） */
    @TableField(exist = false)
    private boolean mine;

    /** 非数据库字段：发送人身份 买家 / 卖家 / 平台客服（公开咨询区、后台监管用） */
    @TableField(exist = false)
    private String senderRole;

    /** 非数据库字段：关联商品标题（公开咨询区、后台监管用） */
    @TableField(exist = false)
    private String itemTitle;

    /** 获取主键，同时作为增量拉取游标 */
    public Long getId() {
        return id;
    }

    /** 设置主键，同时作为增量拉取游标 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取所属会话 ID */
    public Long getSessionId() {
        return sessionId;
    }

    /** 设置所属会话 ID */
    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    /** 获取发送人 ID */
    public Long getSenderId() {
        return senderId;
    }

    /** 设置发送人 ID */
    public void setSenderId(Long senderId) {
        this.senderId = senderId;
    }

    /** 获取接收人 ID */
    public Long getReceiverId() {
        return receiverId;
    }

    /** 设置接收人 ID */
    public void setReceiverId(Long receiverId) {
        this.receiverId = receiverId;
    }

    /** 获取消息正文 */
    public String getContent() {
        return content;
    }

    /** 设置消息正文 */
    public void setContent(String content) {
        this.content = content;
    }

    /** 获取消息类型 TEXT / ORDER */
    public String getMsgType() {
        return msgType;
    }

    /** 设置消息类型 TEXT / ORDER */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    /** 获取订单卡片关联的订单 ID */
    public Long getOrderId() {
        return orderId;
    }

    /** 设置订单卡片关联的订单 ID */
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    /** 获取是否已读：1 是，0 否 */
    public Integer getIsRead() {
        return isRead;
    }

    /** 设置是否已读：1 是，0 否 */
    public void setIsRead(Integer isRead) {
        this.isRead = isRead;
    }

    /** 获取发送时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置发送时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    /** 获取非数据库字段：发送人昵称（关联查询） */
    public String getSenderName() {
        return senderName;
    }

    /** 设置非数据库字段：发送人昵称（关联查询） */
    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    /** 获取非数据库字段：发送人头像（关联查询） */
    public String getSenderAvatar() {
        return senderAvatar;
    }

    /** 设置非数据库字段：发送人头像（关联查询） */
    public void setSenderAvatar(String senderAvatar) {
        this.senderAvatar = senderAvatar;
    }

    /** 获取非数据库字段：是否为当前登录人发出（用于气泡左右分栏） */
    public boolean isMine() {
        return mine;
    }

    /** 设置非数据库字段：是否为当前登录人发出（用于气泡左右分栏） */
    public void setMine(boolean mine) {
        this.mine = mine;
    }

    /** 获取非数据库字段：发送人身份 */
    public String getSenderRole() {
        return senderRole;
    }

    /** 设置非数据库字段：发送人身份 */
    public void setSenderRole(String senderRole) {
        this.senderRole = senderRole;
    }

    /** 获取非数据库字段：关联商品标题 */
    public String getItemTitle() {
        return itemTitle;
    }

    /** 设置非数据库字段：关联商品标题 */
    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }

}
