package com.example.demo.service;

import com.example.demo.entity.Item;

import java.util.List;

/**
 * 商品收藏 / 想要业务接口（淘宝「收藏商品」「想要人数」）。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface FavoriteService {

    /** 收藏 / 取消收藏切换，返回切换后是否已收藏 */
    boolean toggle(Long userId, Long itemId);

    /** 当前用户是否已收藏该物品 */
    boolean isFavorite(Long userId, Long itemId);

    /** 我的收藏列表 */
    List<Item> listMine(Long userId);

    /** 某件物品被多少人想要 */
    long countByItem(Long itemId);
}
