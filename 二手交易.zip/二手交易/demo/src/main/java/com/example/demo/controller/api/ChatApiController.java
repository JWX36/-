package com.example.demo.controller.api;

import com.example.demo.common.Result;
import com.example.demo.entity.ChatMessage;
import com.example.demo.service.ChatService;
import com.example.demo.util.UserContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 客服私信 REST 接口：前端 3 秒轮询增量拉取 + 无刷新发送，全部返回统一 Result。
 * 归属校验在 ChatService 内完成，越权访问由全局异常处理器转成 Result.fail。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@RestController
@RequestMapping("/api/chat")
public class ChatApiController {

    private final ChatService chatService;
    private final UserContext userContext;

    public ChatApiController(ChatService chatService, UserContext userContext) {
        this.chatService = chatService;
        this.userContext = userContext;
    }

    /** 拉取 id 大于 afterId 的新消息（首次传 0 取全量） */
    @GetMapping("/{sessionId}/messages")
    public Result<List<ChatMessage>> messages(@PathVariable("sessionId") Long sessionId,
                                              @RequestParam(value = "afterId", defaultValue = "0") Long afterId) {
        return Result.ok(chatService.messages(sessionId, userContext.currentUserId(), afterId));
    }

    /** 发送一条私信 */
    @PostMapping("/{sessionId}/send")
    public Result<ChatMessage> send(@PathVariable("sessionId") Long sessionId,
                                    @RequestParam("content") String content) {
        return Result.ok(chatService.send(sessionId, userContext.currentUserId(), content));
    }

    /** 一键把已购订单卡片重发到当前会话（聊天页「附上订单」按钮） */
    @PostMapping("/{sessionId}/send-order/{orderId}")
    public Result<ChatMessage> sendOrder(@PathVariable("sessionId") Long sessionId,
                                         @PathVariable("orderId") Long orderId) {
        return Result.ok(chatService.sendOrderCard(sessionId, userContext.currentUserId(), orderId));
    }

    /** 未读客服消息总数（导航栏红点） */
    @GetMapping("/unread")
    public Result<Long> unread() {
        return Result.ok(chatService.countUnread(userContext.currentUserId()));
    }
}
