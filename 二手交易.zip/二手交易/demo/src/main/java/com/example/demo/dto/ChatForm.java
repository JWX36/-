package com.example.demo.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 客服私信表单对象（JSR-303 校验，Controller 层使用）。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class ChatForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 消息正文 */
    @NotBlank(message = "消息内容不能为空")
    @Size(max = 500, message = "单条消息最多 500 字")
    private String content;

    /** 获取消息正文 */
    public String getContent() {
        return content;
    }

    /** 设置消息正文 */
    public void setContent(String content) {
        this.content = content;
    }
}
