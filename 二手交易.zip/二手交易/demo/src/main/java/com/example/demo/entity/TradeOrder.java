package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 交易订单实体，对应 tb_order。状态：0 待支付 1 已支付待确认 2 已完成 3 已取消 4 超时自动取消。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_order")
public class TradeOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 订单编号（业务唯一） */
    private String orderNo;

    /** 幂等请求号：同一请求号只允许下单一次 */
    private String requestNo;

    /** 买家 ID */
    private Long buyerId;

    /** 卖家 ID */
    private Long sellerId;

    /** 物品 ID */
    private Long itemId;

    /** 成交单价快照 */
    private BigDecimal price;

    /** 购买数量 */
    private Integer quantity;

    /** 订单总金额 */
    private BigDecimal amount;

    /** 订单状态 */
    private Integer status;

    /** 取消原因 */
    private String cancelReason;

    /** 支付时间 */
    private LocalDateTime payTime;

    /** 交易完成时间 */
    private LocalDateTime finishTime;

    /** 下单时间 */
    private LocalDateTime createTime;

    /** 更新时间 */
    private LocalDateTime updateTime;

    /** 非数据库字段：买家昵称（关联查询） */
    @TableField(exist = false)
    private String buyerName;

    /** 非数据库字段：卖家昵称（关联查询） */
    @TableField(exist = false)
    private String sellerName;

    /** 非数据库字段：物品标题（关联查询） */
    @TableField(exist = false)
    private String itemTitle;

    /** 非数据库字段：物品封面（关联查询） */
    @TableField(exist = false)
    private String itemCover;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取订单编号（业务唯一） */
    public String getOrderNo() {
        return orderNo;
    }

    /** 设置订单编号（业务唯一） */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /** 获取幂等请求号：同一请求号只允许下单一次 */
    public String getRequestNo() {
        return requestNo;
    }

    /** 设置幂等请求号：同一请求号只允许下单一次 */
    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    /** 获取买家 ID */
    public Long getBuyerId() {
        return buyerId;
    }

    /** 设置买家 ID */
    public void setBuyerId(Long buyerId) {
        this.buyerId = buyerId;
    }

    /** 获取卖家 ID */
    public Long getSellerId() {
        return sellerId;
    }

    /** 设置卖家 ID */
    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    /** 获取物品 ID */
    public Long getItemId() {
        return itemId;
    }

    /** 设置物品 ID */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取成交单价快照 */
    public BigDecimal getPrice() {
        return price;
    }

    /** 设置成交单价快照 */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /** 获取购买数量 */
    public Integer getQuantity() {
        return quantity;
    }

    /** 设置购买数量 */
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    /** 获取订单总金额 */
    public BigDecimal getAmount() {
        return amount;
    }

    /** 设置订单总金额 */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /** 获取订单状态 */
    public Integer getStatus() {
        return status;
    }

    /** 设置订单状态 */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /** 获取取消原因 */
    public String getCancelReason() {
        return cancelReason;
    }

    /** 设置取消原因 */
    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    /** 获取支付时间 */
    public LocalDateTime getPayTime() {
        return payTime;
    }

    /** 设置支付时间 */
    public void setPayTime(LocalDateTime payTime) {
        this.payTime = payTime;
    }

    /** 获取交易完成时间 */
    public LocalDateTime getFinishTime() {
        return finishTime;
    }

    /** 设置交易完成时间 */
    public void setFinishTime(LocalDateTime finishTime) {
        this.finishTime = finishTime;
    }

    /** 获取下单时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置下单时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    /** 获取更新时间 */
    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    /** 设置更新时间 */
    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    /** 获取非数据库字段：买家昵称（关联查询） */
    public String getBuyerName() {
        return buyerName;
    }

    /** 设置非数据库字段：买家昵称（关联查询） */
    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    /** 获取非数据库字段：卖家昵称（关联查询） */
    public String getSellerName() {
        return sellerName;
    }

    /** 设置非数据库字段：卖家昵称（关联查询） */
    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    /** 获取非数据库字段：物品标题（关联查询） */
    public String getItemTitle() {
        return itemTitle;
    }

    /** 设置非数据库字段：物品标题（关联查询） */
    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }

    /** 获取非数据库字段：物品封面（关联查询） */
    public String getItemCover() {
        return itemCover;
    }

    /** 设置非数据库字段：物品封面（关联查询） */
    public void setItemCover(String itemCover) {
        this.itemCover = itemCover;
    }

}
