package com.example.demo.service.support;

import com.example.demo.config.RabbitConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;

/**
 * RabbitMQ 消费者（高阶考点：订单/审核/留言三类事件的异步解耦）。
 * 仅在开启 MQ 时装配；监听器是否自动启动由 spring.rabbitmq.listener.simple.auto-startup 控制。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
@ConditionalOnProperty(prefix = "app.feature", name = "mq-enabled", havingValue = "true")
public class OrderEventConsumer {

    private static final Logger log = LoggerFactory.getLogger(OrderEventConsumer.class);

    private final EventProcessor eventProcessor;

    public OrderEventConsumer(EventProcessor eventProcessor) {
        this.eventProcessor = eventProcessor;
    }

    /** 下单成功：异步邮件通知买家与卖家 */
    @RabbitListener(queues = RabbitConfig.QUEUE_ORDER_CREATED)
    public void onOrderCreated(Message message) {
        dispatch(message, "order.created");
    }

    /** 订单状态流转：异步推送状态变更 */
    @RabbitListener(queues = RabbitConfig.QUEUE_ORDER_STATUS)
    public void onOrderStatus(Message message) {
        dispatch(message, "order.status");
    }

    /** 物品审核结果：异步邮件通知发布者 */
    @RabbitListener(queues = RabbitConfig.QUEUE_ITEM_AUDIT)
    public void onItemAudited(Message message) {
        dispatch(message, "item.audit");
    }

    /** 新留言：异步提醒发布者 */
    @RabbitListener(queues = RabbitConfig.QUEUE_MESSAGE)
    public void onMessageCreated(Message message) {
        dispatch(message, "message.created");
    }

    /** 统一解析消息体（JSON 字符串）并交给事件处理器 */
    private void dispatch(Message message, String eventType) {
        try {
            String json = new String(message.getBody(), StandardCharsets.UTF_8);
            eventProcessor.handleJson(eventType, json);
            log.info("MQ 消息消费完成：{}", eventType);
        } catch (Exception e) {
            log.error("MQ 消息消费失败：{}", eventType, e);
        }
    }
}
