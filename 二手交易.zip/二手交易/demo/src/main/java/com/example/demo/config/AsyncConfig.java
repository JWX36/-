package com.example.demo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * 开启 Spring 异步任务能力：邮件通知、消息异步处理使用 @Async，避免阻塞主流程。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Configuration
@EnableAsync
public class AsyncConfig {
}
