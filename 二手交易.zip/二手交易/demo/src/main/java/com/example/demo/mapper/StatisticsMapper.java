package com.example.demo.mapper;

import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 数据看板统计 Mapper：多表关联与聚合查询，SQL 全部使用 #{} 占位符防止注入。
 * 日期聚合放在 Java 层完成，保证 H2 与 MySQL 8 双库 SQL 完全兼容。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface StatisticsMapper {

    /** 首页/后台概览指标 */
    Map<String, Object> tradeSummary();

    /** 指定时间之后已完成订单的成交金额与时间明细 */
    List<Map<String, Object>> tradeDetail(@Param("fromTime") LocalDateTime fromTime);

    /** 全部用户的注册时间明细，用于用户增长曲线 */
    List<Map<String, Object>> userRegDetail(@Param("fromTime") LocalDateTime fromTime);

    /** 各分类成交单量占比（多表 LEFT JOIN） */
    List<Map<String, Object>> categoryTradeShare();

    /** 各分类在售物品数量（仪表盘表格） */
    List<Map<String, Object>> categoryItemCount();
}
