package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.config.AppProperties;
import com.example.demo.entity.Item;
import com.example.demo.entity.RefundApply;
import com.example.demo.entity.TradeOrder;
import com.example.demo.entity.User;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.mapper.RefundApplyMapper;
import com.example.demo.mapper.TradeOrderMapper;
import com.example.demo.mapper.UserMapper;
import com.example.demo.service.RefundService;
import com.example.demo.service.support.CacheService;
import com.example.demo.service.support.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * 退款 / 售后业务实现。
 *
 * 与「七天无理由」不同，二手闲置以校内面交、当面验货为主，因此平台只受理
 * 描述不符、质量故障、未收到货、协商一致四类有理由退款；同时通过申请窗口、
 * 卖家处理时限、超时自动同意、平台仲裁形成闭环，避免买家无限期申诉或卖家拖延。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class RefundServiceImpl implements RefundService {

    /** 允许的退款理由类型 */
    private static final List<String> REASON_TYPES =
            Arrays.asList("DESC_MISMATCH", "QUALITY", "NOT_RECEIVED", "AGREED");

    private final RefundApplyMapper refundApplyMapper;
    private final TradeOrderMapper tradeOrderMapper;
    private final ItemMapper itemMapper;
    private final UserMapper userMapper;
    private final NotificationService notificationService;
    private final CacheService cacheService;
    private final AppProperties appProperties;

    public RefundServiceImpl(RefundApplyMapper refundApplyMapper, TradeOrderMapper tradeOrderMapper,
                             ItemMapper itemMapper, UserMapper userMapper,
                             NotificationService notificationService, CacheService cacheService,
                             AppProperties appProperties) {
        this.refundApplyMapper = refundApplyMapper;
        this.tradeOrderMapper = tradeOrderMapper;
        this.itemMapper = itemMapper;
        this.userMapper = userMapper;
        this.notificationService = notificationService;
        this.cacheService = cacheService;
        this.appProperties = appProperties;
    }

    /**
     * 订单详情页判断能否申请：已支付 / 已完成 + 在申请窗口内 + 无进行中或已成功的申请。
     * 只用于按钮展示，真正的强校验在 apply() 中再做一次，防止绕过页面直接调接口。
     */
    @Override
    public boolean canApply(TradeOrder order) {
        if (order == null || order.getStatus() == null) {
            return false;
        }
        if (order.getStatus() != 1 && order.getStatus() != 2) {
            return false;
        }
        LocalDateTime base = baseTime(order);
        if (base == null || base.plusDays(appProperties.getRefund().getApplyWindowDays())
                .isBefore(LocalDateTime.now())) {
            return false;
        }
        Long active = refundApplyMapper.selectCount(new LambdaQueryWrapper<RefundApply>()
                .eq(RefundApply::getOrderId, order.getId())
                .in(RefundApply::getStatus,
                        Arrays.asList(WAIT_SELLER, PLATFORM_REVIEW, REFUNDED)));
        return active == null || active == 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RefundApply apply(Long orderId, Long buyerId, String reasonType, String reason) {
        TradeOrder order = tradeOrderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        if (!order.getBuyerId().equals(buyerId)) {
            throw new BusinessException("只有订单买家可以申请退款");
        }
        if (!canApply(order)) {
            throw new BusinessException("该订单当前不符合退款条件：需已支付 / 已完成、在售后期内且无进行中的申请");
        }
        if (reasonType == null || !REASON_TYPES.contains(reasonType)) {
            throw new BusinessException("请选择平台支持的退款理由");
        }
        String text = reason == null ? "" : reason.trim();
        if (text.length() < 5) {
            throw new BusinessException("请至少用 5 个字说明具体情况，便于卖家与平台核实");
        }
        if (text.length() > 500) {
            throw new BusinessException("退款说明最多 500 字");
        }

        LocalDateTime now = LocalDateTime.now();
        RefundApply apply = new RefundApply();
        apply.setOrderId(order.getId());
        apply.setOrderNo(order.getOrderNo());
        apply.setBuyerId(order.getBuyerId());
        apply.setSellerId(order.getSellerId());
        apply.setItemId(order.getItemId());
        apply.setAmount(order.getAmount());
        apply.setReasonType(reasonType);
        apply.setReason(text);
        apply.setStatus(WAIT_SELLER);
        apply.setApplyTime(now);
        apply.setDeadlineTime(now.plusHours(appProperties.getRefund().getSellerHandleHours()));
        apply.setCreateTime(now);
        apply.setUpdateTime(now);
        refundApplyMapper.insert(apply);

        notificationService.notifyUser(order.getSellerId(), "收到退款申请",
                "买家对订单 " + order.getOrderNo() + " 发起了退款申请，理由：" + reasonText(reasonType)
                        + "，请在 " + appProperties.getRefund().getSellerHandleHours()
                        + " 小时内处理，超时系统将自动同意退款。", "ORDER", false);
        notificationService.notifyUser(order.getBuyerId(), "退款申请已提交",
                "订单 " + order.getOrderNo() + " 的退款申请已提交，等待卖家处理。", "ORDER", false);
        fill(apply);
        return apply;
    }

    @Override
    public RefundApply detail(Long id, Long userId, boolean admin) {
        RefundApply apply = refundApplyMapper.selectById(id);
        if (apply == null) {
            throw new BusinessException("退款申请不存在");
        }
        if (!admin && !apply.getBuyerId().equals(userId) && !apply.getSellerId().equals(userId)) {
            throw new BusinessException("无权查看该退款申请");
        }
        fill(apply);
        return apply;
    }

    @Override
    public RefundApply findByOrder(Long orderId, Long userId, boolean admin) {
        RefundApply apply = refundApplyMapper.selectOne(new LambdaQueryWrapper<RefundApply>()
                .eq(RefundApply::getOrderId, orderId)
                .orderByDesc(RefundApply::getId)
                .last("LIMIT 1"));
        if (apply == null) {
            return null;
        }
        if (!admin && !apply.getBuyerId().equals(userId) && !apply.getSellerId().equals(userId)) {
            throw new BusinessException("无权查看该退款申请");
        }
        fill(apply);
        return apply;
    }

    @Override
    public List<RefundApply> listMine(Long userId, String view) {
        LambdaQueryWrapper<RefundApply> wrapper = new LambdaQueryWrapper<>();
        if ("seller".equals(view)) {
            wrapper.eq(RefundApply::getSellerId, userId);
        } else {
            wrapper.eq(RefundApply::getBuyerId, userId);
        }
        wrapper.orderByDesc(RefundApply::getApplyTime, RefundApply::getId);
        List<RefundApply> list = refundApplyMapper.selectList(wrapper);
        list.forEach(this::fill);
        return list;
    }

    @Override
    public List<RefundApply> listAll() {
        List<RefundApply> list = refundApplyMapper.selectList(new LambdaQueryWrapper<RefundApply>()
                .orderByDesc(RefundApply::getApplyTime, RefundApply::getId));
        list.forEach(this::fill);
        return list;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void handle(Long id, Long sellerId, boolean approve, String note) {
        RefundApply apply = refundApplyMapper.selectById(id);
        if (apply == null) {
            throw new BusinessException("退款申请不存在");
        }
        if (!apply.getSellerId().equals(sellerId)) {
            throw new BusinessException("只有订单卖家可以处理该退款申请");
        }
        if (apply.getStatus() != WAIT_SELLER) {
            throw new BusinessException("该申请已处理或已结束，不能重复操作");
        }
        if (approve) {
            doRefund(apply, "SELLER", sellerId,
                    note == null || note.trim().isEmpty() ? "卖家同意退款，款项原路退回（模拟）" : note.trim());
        } else {
            String reply = note == null || note.trim().isEmpty() ? "卖家未说明原因" : note.trim();
            apply.setStatus(SELLER_REJECTED);
            apply.setHandlerType("SELLER");
            apply.setHandlerId(sellerId);
            apply.setHandleNote(reply);
            apply.setHandleTime(LocalDateTime.now());
            apply.setUpdateTime(LocalDateTime.now());
            refundApplyMapper.updateById(apply);
            notificationService.notifyUser(apply.getBuyerId(), "退款申请被卖家拒绝",
                    "订单 " + apply.getOrderNo() + " 的退款申请被拒绝：" + reply
                            + "。如仍有异议，可在退款详情页申请平台介入。", "ORDER", false);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void escalate(Long id, Long buyerId) {
        RefundApply apply = refundApplyMapper.selectById(id);
        if (apply == null) {
            throw new BusinessException("退款申请不存在");
        }
        if (!apply.getBuyerId().equals(buyerId)) {
            throw new BusinessException("只有订单买家可以申请平台介入");
        }
        if (apply.getStatus() != SELLER_REJECTED) {
            throw new BusinessException("只有被卖家拒绝的申请才能申请平台介入");
        }
        apply.setStatus(PLATFORM_REVIEW);
        apply.setUpdateTime(LocalDateTime.now());
        refundApplyMapper.updateById(apply);
        notificationService.notifyUser(apply.getBuyerId(), "平台已受理介入申请",
                "订单 " + apply.getOrderNo() + " 已进入平台仲裁，管理员将依据双方说明作出裁定。", "ORDER", false);
        for (User admin : userMapper.selectList(new LambdaQueryWrapper<User>()
                .eq(User::getRole, "ADMIN"))) {
            notificationService.notifyUser(admin.getId(), "有待仲裁的退款申请",
                    "订单 " + apply.getOrderNo() + " 的买家申请了平台介入，请到「退款仲裁」处理。", "ORDER", false);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancel(Long id, Long buyerId) {
        RefundApply apply = refundApplyMapper.selectById(id);
        if (apply == null) {
            throw new BusinessException("退款申请不存在");
        }
        if (!apply.getBuyerId().equals(buyerId)) {
            throw new BusinessException("只有订单买家可以撤销该申请");
        }
        if (apply.getStatus() != WAIT_SELLER) {
            throw new BusinessException("当前状态不允许撤销申请");
        }
        apply.setStatus(BUYER_CANCELED);
        apply.setHandlerType("SELLER");
        apply.setHandleNote("买家主动撤销退款申请");
        apply.setHandleTime(LocalDateTime.now());
        apply.setUpdateTime(LocalDateTime.now());
        refundApplyMapper.updateById(apply);
        notificationService.notifyUser(apply.getSellerId(), "退款申请已撤销",
                "订单 " + apply.getOrderNo() + " 的退款申请已由买家主动撤销。", "ORDER", false);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void decide(Long id, Long adminId, boolean approve, String note) {
        RefundApply apply = refundApplyMapper.selectById(id);
        if (apply == null) {
            throw new BusinessException("退款申请不存在");
        }
        if (apply.getStatus() == REFUNDED || apply.getStatus() == PLATFORM_REJECTED
                || apply.getStatus() == BUYER_CANCELED) {
            throw new BusinessException("该申请已结束，不能重复裁定");
        }
        String opinion = note == null || note.trim().isEmpty()
                ? (approve ? "平台裁定支持买家，执行退款" : "平台裁定驳回申请") : note.trim();
        if (approve) {
            doRefund(apply, "ADMIN", adminId, opinion);
        } else {
            apply.setStatus(PLATFORM_REJECTED);
            apply.setHandlerType("ADMIN");
            apply.setHandlerId(adminId);
            apply.setHandleNote(opinion);
            apply.setHandleTime(LocalDateTime.now());
            apply.setUpdateTime(LocalDateTime.now());
            refundApplyMapper.updateById(apply);
            notificationService.notifyUser(apply.getBuyerId(), "平台裁定结果",
                    "订单 " + apply.getOrderNo() + " 的退款申请被平台驳回：" + opinion, "ORDER", false);
            notificationService.notifyUser(apply.getSellerId(), "平台裁定结果",
                    "订单 " + apply.getOrderNo() + " 的退款申请已由平台驳回：" + opinion, "ORDER", false);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int autoApproveExpired(int hours) {
        List<RefundApply> expired = refundApplyMapper.selectList(new LambdaQueryWrapper<RefundApply>()
                .eq(RefundApply::getStatus, WAIT_SELLER)
                .isNotNull(RefundApply::getDeadlineTime)
                .lt(RefundApply::getDeadlineTime, LocalDateTime.now()));
        for (RefundApply apply : expired) {
            doRefund(apply, "SYSTEM", null,
                    "卖家超过 " + hours + " 小时未处理，系统按平台规则自动同意退款");
        }
        return expired.size();
    }

    /**
     * 统一的退款成功处理：改申请状态 → 订单标记为已退款 → 恢复库存并重新上架 → 通知双方。
     * 演示环境为模拟支付，不涉及真实资金流水，因此退款金额按订单全额处理。
     */
    private void doRefund(RefundApply apply, String handlerType, Long handlerId, String note) {
        LocalDateTime now = LocalDateTime.now();
        apply.setStatus(REFUNDED);
        apply.setHandlerType(handlerType);
        apply.setHandlerId(handlerId);
        apply.setHandleNote(note);
        apply.setHandleTime(now);
        apply.setUpdateTime(now);
        refundApplyMapper.updateById(apply);

        TradeOrder order = tradeOrderMapper.selectById(apply.getOrderId());
        if (order != null && order.getStatus() != null && order.getStatus() != 5) {
            order.setStatus(5);                 // 5 = 已退款
            order.setUpdateTime(now);
            tradeOrderMapper.updateById(order);
            int quantity = order.getQuantity() == null ? 1 : order.getQuantity();
            itemMapper.restoreStock(apply.getItemId(), quantity);
            Item item = itemMapper.selectById(apply.getItemId());
            if (item != null && item.getStatus() != null && item.getStatus() == 3) {
                item.setStatus(1);              // 已售出的宝贝恢复在售（违规下架等状态不动）
                item.setUpdateTime(now);
                itemMapper.updateById(item);
            }
            cacheService.delete("item:hot");
        }
        notificationService.notifyUser(apply.getBuyerId(), "退款成功",
                "订单 " + apply.getOrderNo() + " 退款成功，¥" + apply.getAmount()
                        + " 已原路退回（模拟）。处理说明：" + note, "ORDER", false);
        notificationService.notifyUser(apply.getSellerId(), "订单已退款",
                "订单 " + apply.getOrderNo() + " 已完成退款，宝贝库存已恢复。处理说明：" + note, "ORDER", false);
    }

    /** 售后期起算时间：优先完成时间，其次支付时间，最后下单时间 */
    private LocalDateTime baseTime(TradeOrder order) {
        if (order.getFinishTime() != null) {
            return order.getFinishTime();
        }
        if (order.getPayTime() != null) {
            return order.getPayTime();
        }
        return order.getCreateTime();
    }

    /** 装配页面需要的关联展示字段 */
    private void fill(RefundApply apply) {
        Item item = itemMapper.selectById(apply.getItemId());
        if (item != null) {
            apply.setItemTitle(item.getTitle());
            apply.setItemCover(item.getCoverImage());
        }
        User buyer = userMapper.selectById(apply.getBuyerId());
        User seller = userMapper.selectById(apply.getSellerId());
        apply.setBuyerName(buyer == null ? "同学" : buyer.getRealName());
        apply.setSellerName(seller == null ? "同学" : seller.getRealName());
        apply.setReasonText(reasonText(apply.getReasonType()));
        TradeOrder order = tradeOrderMapper.selectById(apply.getOrderId());
        if (order != null) {
            apply.setOrderStatus(order.getStatus());
        }
    }

    /** 理由类型的中文名称，用于通知文案与页面展示 */
    public static String reasonText(String reasonType) {
        if ("DESC_MISMATCH".equals(reasonType)) { return "宝贝与描述不符"; }
        if ("QUALITY".equals(reasonType)) { return "质量问题 / 功能故障"; }
        if ("NOT_RECEIVED".equals(reasonType)) { return "未收到货 / 卖家未交付"; }
        if ("AGREED".equals(reasonType)) { return "买卖双方协商一致"; }
        return "其他原因";
    }
}
