package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.RefundApply;

/**
 * 退款 / 售后申请数据访问层。
 * 查询条件较简单（按买家、卖家、订单、状态、截止时间），统一使用 MyBatis-Plus
 * LambdaQueryWrapper 构造，避免额外 XML 映射文件，同时保持类型安全。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface RefundApplyMapper extends BaseMapper<RefundApply> {
}
