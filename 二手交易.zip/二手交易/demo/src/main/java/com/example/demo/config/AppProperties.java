package com.example.demo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 自定义业务配置绑定（对应 application.yml 中的 app.* 节点）。
 * 通过配置文件开关控制 Redis / RabbitMQ / 邮件，保证「零中间件」也能一键启动。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Component
@ConfigurationProperties(prefix = "app")
public class AppProperties {

    /** 系统名称 */
    private String name = "校园二手闲置交易平台";

    /** 文件上传配置 */
    private Upload upload = new Upload();

    /** 商品实拍照片配置（独立素材目录，不属于 Spring 内部框架目录） */
    private Photos photos = new Photos();

    /** 高阶功能开关 */
    private Feature feature = new Feature();

    /** 订单相关策略 */
    private Order order = new Order();

    /** 退款 / 售后规则 */
    private Refund refund = new Refund();

    /** 安全相关配置 */
    private Security security = new Security();

    /** 文件上传配置 */
    public static class Upload {

        /** 本地保存目录 */
        private String dir = "./uploads";

        /** 对外暴露的静态资源匹配规则 */
        private String publicPath = "/uploads/**";

        public String getDir() {
            return dir;
        }

        public void setDir(String dir) {
            this.dir = dir;
        }

        public String getPublicPath() {
            return publicPath;
        }

        public void setPublicPath(String publicPath) {
            this.publicPath = publicPath;
        }
    }

    /** 商品实拍照片配置：独立素材目录 + 对外访问路径 + 单件商品图片上限 */
    public static class Photos {

        /** 独立素材目录（相对项目根目录，不在 src/main 内部） */
        private String dir = "./assets/photos";

        /** 对外暴露的静态资源匹配规则 */
        private String publicPath = "/photos/**";

        /** 每件商品最多保留的图片数：保证 3~5 张自动轮播 */
        private int maxPerItem = 5;

        /** 自动轮播间隔（毫秒） */
        private long carouselIntervalMs = 3200;

        public String getDir() {
            return dir;
        }

        public void setDir(String dir) {
            this.dir = dir;
        }

        public String getPublicPath() {
            return publicPath;
        }

        public void setPublicPath(String publicPath) {
            this.publicPath = publicPath;
        }

        public int getMaxPerItem() {
            return maxPerItem;
        }

        public void setMaxPerItem(int maxPerItem) {
            this.maxPerItem = maxPerItem;
        }

        public long getCarouselIntervalMs() {
            return carouselIntervalMs;
        }

        public void setCarouselIntervalMs(long carouselIntervalMs) {
            this.carouselIntervalMs = carouselIntervalMs;
        }
    }

    /** 高阶功能开关：开启后使用真实 Redis / RabbitMQ / SMTP */
    public static class Feature {

        /** 是否启用 Redis 缓存实现 */
        private boolean redisEnabled = false;

        /** 是否启用 RabbitMQ 消息实现 */
        private boolean mqEnabled = false;

        /** 是否发送真实邮件（关闭时仍写入站内通知） */
        private boolean mailEnabled = false;

        public boolean isRedisEnabled() {
            return redisEnabled;
        }

        public void setRedisEnabled(boolean redisEnabled) {
            this.redisEnabled = redisEnabled;
        }

        public boolean isMqEnabled() {
            return mqEnabled;
        }

        public void setMqEnabled(boolean mqEnabled) {
            this.mqEnabled = mqEnabled;
        }

        public boolean isMailEnabled() {
            return mailEnabled;
        }

        public void setMailEnabled(boolean mailEnabled) {
            this.mailEnabled = mailEnabled;
        }
    }

    /** 订单策略 */
    public static class Order {

        /** 未支付订单自动取消的分钟数 */
        private int payTimeoutMinutes = 30;

        /** 已下架物品保留天数 */
        private int cleanupDays = 30;

        public int getPayTimeoutMinutes() {
            return payTimeoutMinutes;
        }

        public void setPayTimeoutMinutes(int payTimeoutMinutes) {
            this.payTimeoutMinutes = payTimeoutMinutes;
        }

        public int getCleanupDays() {
            return cleanupDays;
        }

        public void setCleanupDays(int cleanupDays) {
            this.cleanupDays = cleanupDays;
        }
    }

    /** 二手闲置退款规则：仅支持有理由退款，不支持七天无理由 */
    public static class Refund {

        /** 交易完成 / 支付后可申请售后的天数窗口 */
        private int applyWindowDays = 15;

        /** 卖家处理时限（小时），超时由定时任务自动同意退款 */
        private int sellerHandleHours = 48;

        public int getApplyWindowDays() {
            return applyWindowDays;
        }

        public void setApplyWindowDays(int applyWindowDays) {
            this.applyWindowDays = applyWindowDays;
        }

        public int getSellerHandleHours() {
            return sellerHandleHours;
        }

        public void setSellerHandleHours(int sellerHandleHours) {
            this.sellerHandleHours = sellerHandleHours;
        }
    }

    /** 安全配置 */
    public static class Security {

        /** remember-me 令牌签名密钥 */
        private String rememberMeKey = "campus-market-secret";

        public String getRememberMeKey() {
            return rememberMeKey;
        }

        public void setRememberMeKey(String rememberMeKey) {
            this.rememberMeKey = rememberMeKey;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Upload getUpload() {
        return upload;
    }

    public void setUpload(Upload upload) {
        this.upload = upload;
    }

    public Photos getPhotos() {
        return photos;
    }

    public void setPhotos(Photos photos) {
        this.photos = photos;
    }

    public Feature getFeature() {
        return feature;
    }

    public void setFeature(Feature feature) {
        this.feature = feature;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Refund getRefund() {
        return refund;
    }

    public void setRefund(Refund refund) {
        this.refund = refund;
    }

    public Security getSecurity() {
        return security;
    }

    public void setSecurity(Security security) {
        this.security = security;
    }
}
