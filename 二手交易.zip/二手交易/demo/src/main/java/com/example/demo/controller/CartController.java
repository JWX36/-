package com.example.demo.controller;

import com.example.demo.entity.Item;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.service.support.CacheService;
import com.example.demo.util.UserContext;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 购物车与浏览记录控制器：数据全量存放于缓存（开启 Redis 后即真实 Redis 存储）。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
@RequestMapping("/cart")
public class CartController {

    private static final long TTL = 7 * 24 * 3600L;

    private final CacheService cacheService;
    private final ItemMapper itemMapper;
    private final UserContext userContext;

    public CartController(CacheService cacheService, ItemMapper itemMapper, UserContext userContext) {
        this.cacheService = cacheService;
        this.itemMapper = itemMapper;
        this.userContext = userContext;
    }

    /** 购物车页面：展示购物车物品与最近浏览记录 */
    @GetMapping
    public String cart(Model model) {
        Long userId = userContext.currentUserId();
        List<Long> ids = readIds("user:cart:" + userId);
        List<Item> items = ids.isEmpty() ? Collections.emptyList() : itemMapper.selectBatchIds(ids);
        model.addAttribute("cartItems", items);
        model.addAttribute("cartCount", items.size());
        List<Long> browseIds = readIds("user:browse:" + userId);
        model.addAttribute("browseItems", browseIds.isEmpty()
                ? Collections.emptyList() : itemMapper.selectBatchIds(browseIds));
        return "cart";
    }

    /** 加入购物车（去重） */
    @PostMapping("/add/{id}")
    public String add(@PathVariable("id") Long id) {
        String key = "user:cart:" + userContext.currentUserId();
        List<Long> ids = new ArrayList<>(readIds(key));
        ids.remove(id);
        ids.add(0, id);
        cacheService.set(key, ids, TTL);
        return "redirect:/cart?added";
    }

    /** 移出购物车 */
    @PostMapping("/remove/{id}")
    public String remove(@PathVariable("id") Long id) {
        String key = "user:cart:" + userContext.currentUserId();
        List<Long> ids = new ArrayList<>(readIds(key));
        ids.remove(id);
        cacheService.set(key, ids, TTL);
        return "redirect:/cart";
    }

    /** 清空购物车 */
    @PostMapping("/clear")
    public String clear() {
        cacheService.delete("user:cart:" + userContext.currentUserId());
        return "redirect:/cart";
    }

    /** 从缓存读取 ID 列表，缓存异常或未命中时返回空列表 */
    private List<Long> readIds(String key) {
        List<Long> ids = cacheService.get(key, new TypeReference<List<Long>>() {
        });
        return ids == null ? new ArrayList<>() : ids;
    }
}
