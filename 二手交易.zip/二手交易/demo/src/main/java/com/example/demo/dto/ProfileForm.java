package com.example.demo.dto;

import java.io.Serializable;
import javax.validation.constraints.*;

/**
 * 个人资料修改表单。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class ProfileForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 昵称 */
    @NotBlank(message = "昵称不能为空")
    private String realName;

    /** 邮箱 */
    @NotBlank(message = "邮箱不能为空")
    @Email(message = "邮箱格式不正确")
    private String email;

    /** 手机号 */
    private String phone;

    /** 获取昵称 */
    public String getRealName() {
        return realName;
    }

    /** 设置昵称 */
    public void setRealName(String realName) {
        this.realName = realName;
    }

    /** 获取邮箱 */
    public String getEmail() {
        return email;
    }

    /** 设置邮箱 */
    public void setEmail(String email) {
        this.email = email;
    }

    /** 获取手机号 */
    public String getPhone() {
        return phone;
    }

    /** 设置手机号 */
    public void setPhone(String phone) {
        this.phone = phone;
    }

}
