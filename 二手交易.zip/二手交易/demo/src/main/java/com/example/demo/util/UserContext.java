package com.example.demo.util;

import com.example.demo.entity.User;
import com.example.demo.exception.BusinessException;
import com.example.demo.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

/**
 * 登录用户上下文工具：Controller / AOP / Service 统一通过它取当前登录人，
 * 并在业务层做数据归属比对，杜绝水平越权（改 ID 访问他人数据）。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Component
public class UserContext {

    private final UserService userService;

    public UserContext(UserService userService) {
        this.userService = userService;
    }

    /** 当前登录账号，未登录返回 anonymous */
    public String currentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()
                || "anonymousUser".equals(authentication.getPrincipal())) {
            return "anonymous";
        }
        return authentication.getName();
    }

    /** 当前登录用户实体，未登录返回 null */
    public User currentUserOrNull() {
        String username = currentUsername();
        if ("anonymous".equals(username)) {
            return null;
        }
        return userService.findByUsername(username);
    }

    /** 当前登录用户 ID；未登录抛出业务异常，阻断越权访问 */
    public Long currentUserId() {
        User user = currentUserOrNull();
        if (user == null) {
            throw new BusinessException("请先登录后再操作");
        }
        return user.getId();
    }

    /** 判断当前登录人是否拥有指定角色 */
    public boolean hasRole(String role) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return false;
        }
        for (GrantedAuthority authority : authentication.getAuthorities()) {
            if (("ROLE_" + role).equals(authority.getAuthority())) {
                return true;
            }
        }
        return false;
    }

    /** 当前登录人是否为超级管理员 */
    public boolean isAdmin() {
        return hasRole("ADMIN");
    }
}
