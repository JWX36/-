package com.example.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.dto.PageQuery;
import com.example.demo.dto.PasswordForm;
import com.example.demo.dto.ProfileForm;
import com.example.demo.dto.RegisterForm;
import com.example.demo.entity.User;

/**
 * 用户模块业务接口：注册、个人资料、密码修改、头像上传与后台用户管理。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface UserService {

    /** 用户注册：账号唯一性校验 + BCrypt 加密 */
    void register(RegisterForm form);

    /** 按账号查询（登录认证使用） */
    User findByUsername(String username);

    /** 按主键查询，不存在抛业务异常 */
    User getById(Long id);

    /** 修改个人资料 */
    void updateProfile(Long userId, ProfileForm form);

    /** 修改密码：校验原密码 + 两次输入一致 */
    void changePassword(Long userId, PasswordForm form);

    /** 更新头像路径 */
    void updateAvatar(Long userId, String avatarUrl);

    /** 后台分页查询用户 */
    IPage<User> pageUsers(PageQuery query, String keyword, String role);

    /** 启用 / 禁用账号 */
    void changeStatus(Long id, Integer status);

    /** 调整角色（USER → SELLER 认证卖家） */
    void changeRole(Long id, String role);
}
