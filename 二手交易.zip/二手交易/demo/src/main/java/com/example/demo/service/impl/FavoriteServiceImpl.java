package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.entity.Favorite;
import com.example.demo.entity.Item;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.FavoriteMapper;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.service.FavoriteService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 收藏业务实现：用户 + 物品唯一约束由业务层保证，收藏列表走三表关联 SQL。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class FavoriteServiceImpl implements FavoriteService {

    private final FavoriteMapper favoriteMapper;
    private final ItemMapper itemMapper;

    public FavoriteServiceImpl(FavoriteMapper favoriteMapper, ItemMapper itemMapper) {
        this.favoriteMapper = favoriteMapper;
        this.itemMapper = itemMapper;
    }

    @Override
    public boolean toggle(Long userId, Long itemId) {
        if (itemMapper.selectById(itemId) == null) {
            throw new BusinessException("物品不存在");
        }
        Favorite exist = favoriteMapper.selectOne(new LambdaQueryWrapper<Favorite>()
                .eq(Favorite::getUserId, userId)
                .eq(Favorite::getItemId, itemId)
                .last("LIMIT 1"));
        if (exist != null) {
            favoriteMapper.deleteById(exist.getId());
            return false;
        }
        Favorite favorite = new Favorite();
        favorite.setUserId(userId);
        favorite.setItemId(itemId);
        favorite.setCreateTime(LocalDateTime.now());
        favoriteMapper.insert(favorite);
        return true;
    }

    @Override
    public boolean isFavorite(Long userId, Long itemId) {
        if (userId == null || itemId == null) {
            return false;
        }
        return favoriteMapper.selectCount(new LambdaQueryWrapper<Favorite>()
                .eq(Favorite::getUserId, userId)
                .eq(Favorite::getItemId, itemId)) > 0;
    }

    @Override
    public List<Item> listMine(Long userId) {
        return favoriteMapper.selectFavoriteItems(userId);
    }

    @Override
    public long countByItem(Long itemId) {
        return favoriteMapper.selectCount(new LambdaQueryWrapper<Favorite>()
                .eq(Favorite::getItemId, itemId));
    }
}
