package com.example.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.dto.ItemForm;
import com.example.demo.dto.ItemQuery;
import com.example.demo.entity.Item;
import com.example.demo.entity.ItemImage;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 物品模块业务接口：发布、编辑、下架、审核、检索、详情、热点缓存与定时清理。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface ItemService {

    /** 多条件分页检索 */
    IPage<Item> search(ItemQuery query, Integer defaultStatus);

    /** 物品详情（浏览量 +1、写浏览记录缓存、加载图集） */
    Item detail(Long itemId, Long viewerId);

    /** 首页热点物品（缓存 + 防穿透） */
    List<Item> hotItems(int limit);

    /** 详情页「看了又看 / 推荐购买」：同分类优先 + 价格相近 + 热度排序 */
    List<Item> recommend(Long itemId, Long categoryId, java.math.BigDecimal price, int limit);

    /** 发布闲置物品（多图上传，进入待审核状态） */
    Long publish(Long sellerId, ItemForm form, MultipartFile[] images);

    /** 编辑自己的物品；管理员可编辑任意物品 */
    void update(Long itemId, Long sellerId, ItemForm form, MultipartFile[] images);

    /** 下架 / 违规下架；admin=true 时状态标记为违规下架 */
    void offShelf(Long itemId, Long operatorId, boolean admin);

    /** 后台审核通过 / 驳回，并异步通知发布者 */
    void audit(Long itemId, boolean pass, String reason);

    /** 定时清理超过指定天数的已下架物品（归档标记，保护历史订单） */
    int cleanExpiredItems(int days);

    /** 读取自己发布的商品（含归属校验，不增加浏览量） */
    Item ownedItem(Long itemId, Long operatorId);

    /** 卖家查看自己某件商品的图集（含归属校验，杜绝水平越权） */
    List<ItemImage> ownedImages(Long itemId, Long operatorId);

    /** 批量统计每件商品的图片数量，供「我的发布」展示 */
    Map<Long, Integer> imageCounts(Collection<Long> itemIds);

    /** 卖家为已发布商品追加实拍图片，返回本次成功追加张数 */
    int appendImages(Long itemId, Long operatorId, MultipartFile[] images);

    /** 卖家删除自己商品的一张图片（封面自动顺延，至少保留 1 张） */
    void removeImage(Long itemId, Long imageId, Long operatorId);

    /** 卖家把某张图片设为封面，并同步商品表封面与轮播顺序 */
    void markCover(Long itemId, Long imageId, Long operatorId);

    /** 单件商品图片上限，用于页面提示 */
    int maxImagesPerItem();
}
