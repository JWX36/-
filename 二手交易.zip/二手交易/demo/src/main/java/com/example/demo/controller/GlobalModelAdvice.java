package com.example.demo.controller;

import com.example.demo.config.AppProperties;
import com.example.demo.entity.Category;
import com.example.demo.entity.User;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ChatService;
import com.example.demo.service.TradeOrderService;
import com.example.demo.service.support.NotificationService;
import com.example.demo.util.UserContext;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.List;

/**
 * 全局模型数据：所有 Thymeleaf 页面共享系统名称、分类导航、当前登录人与未读通知数。
 * 避免每个 Controller 重复装配公共数据，也是页面片段复用基础。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@ControllerAdvice
public class GlobalModelAdvice {

    private final CategoryService categoryService;
    private final NotificationService notificationService;
    private final ChatService chatService;
    private final TradeOrderService tradeOrderService;
    private final UserContext userContext;
    private final AppProperties appProperties;

    public GlobalModelAdvice(CategoryService categoryService, NotificationService notificationService,
                             ChatService chatService, TradeOrderService tradeOrderService,
                             UserContext userContext, AppProperties appProperties) {
        this.categoryService = categoryService;
        this.notificationService = notificationService;
        this.chatService = chatService;
        this.tradeOrderService = tradeOrderService;
        this.userContext = userContext;
        this.appProperties = appProperties;
    }

    /** 每个页面请求执行前注入公共模型属性 */
    @ModelAttribute
    public void addCommonAttributes(Model model) {
        model.addAttribute("appName", appProperties.getName());
        List<Category> categoryList = categoryService.listAll();
        model.addAttribute("categories", categoryList);
        // 导航栏专用变量名：避免与 /admin/categories 页面的分页对象 categories 重名冲突
        model.addAttribute("navCategories", categoryList);
        User user = userContext.currentUserOrNull();
        model.addAttribute("currentUser", user);
        model.addAttribute("isAdmin", userContext.isAdmin());
        model.addAttribute("isSeller", userContext.hasRole("SELLER"));
        model.addAttribute("unreadCount", user == null ? 0L : notificationService.countUnread(user.getId()));
        model.addAttribute("chatUnreadCount", user == null ? 0L : chatService.countUnread(user.getId()));
        // 淘宝式待办提醒：待支付订单 / 卖家待确认订单，实时统计，不随「通知已读」消失
        model.addAttribute("pendingPayCount",
                user == null ? 0L : tradeOrderService.countByStatus(user.getId(), null, 0));
        model.addAttribute("sellerPendingCount",
                user == null ? 0L : tradeOrderService.countByStatus(null, user.getId(), 1));
        model.addAttribute("feature", appProperties.getFeature());
        // 图片轮播与卖家图片上限：统一由 application.yml 的 app.photos 配置驱动
        model.addAttribute("carouselInterval", appProperties.getPhotos().getCarouselIntervalMs());
        model.addAttribute("maxItemImages", appProperties.getPhotos().getMaxPerItem());
    }
}
