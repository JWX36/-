package com.example.demo.service.support;

import com.example.demo.config.AppProperties;
import com.example.demo.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * 本地文件存储服务（Spring MVC 文件上传考点）。
 * 白名单校验扩展名 + UUID 重命名 + 目录隔离，杜绝路径穿越与脚本文件上传。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class FileStorageService {

    private static final Logger log = LoggerFactory.getLogger(FileStorageService.class);

    /** 允许上传的图片扩展名白名单 */
    private static final Set<String> ALLOWED_EXT = new HashSet<>(
            Arrays.asList("jpg", "jpeg", "png", "gif", "webp", "bmp"));

    private final AppProperties appProperties;

    public FileStorageService(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    /**
     * 保存单个文件。
     *
     * @param file   上传文件
     * @param subDir 子目录，如 items / avatars
     * @return 页面可访问的 URL；文件为空时返回 null
     */
    public String store(MultipartFile file, String subDir) {
        if (file == null || file.isEmpty()) {
            return null;
        }
        String original = file.getOriginalFilename() == null ? "" : file.getOriginalFilename();
        String ext = extension(original);
        if (!ALLOWED_EXT.contains(ext)) {
            throw new BusinessException("仅支持 jpg / jpeg / png / gif / webp / bmp 格式的图片");
        }
        try {
            Path dir = Paths.get(appProperties.getUpload().getDir(), subDir).toAbsolutePath().normalize();
            Files.createDirectories(dir);
            String filename = UUID.randomUUID().toString().replace("-", "") + "." + ext;
            Path target = dir.resolve(filename);
            file.transferTo(target.toFile());
            log.info("文件上传成功：{}", target);
            return "/uploads/" + subDir + "/" + filename;
        } catch (IOException e) {
            log.error("文件保存失败", e);
            throw new BusinessException("文件保存失败，请稍后重试");
        }
    }

    /** 批量保存物品图片（多图上传），返回 URL 列表 */
    public List<String> storeImages(MultipartFile[] files) {
        List<String> urls = new ArrayList<>();
        if (files == null) {
            return urls;
        }
        for (MultipartFile file : files) {
            String url = store(file, "items");
            if (url != null) {
                urls.add(url);
            }
        }
        return urls;
    }

    /**
     * 删除卖家自主上传的图片文件（仅在本地上传目录内、且路径不含 .. 才执行）。
     * 平台内置的 /photos/** 实拍照片不在可删除范围内，避免误删素材。
     */
    public void deleteByUrl(String url) {
        if (url == null || !url.startsWith("/uploads/items/") || url.contains("..")) {
            return;
        }
        try {
            Path root = Paths.get(appProperties.getUpload().getDir()).toAbsolutePath().normalize();
            Path target = root.resolve(url.substring("/uploads/".length())).normalize();
            if (!target.startsWith(root)) {
                return;
            }
            Files.deleteIfExists(target);
            log.info("已删除卖家上传图片：{}", target);
        } catch (IOException e) {
            log.warn("删除上传图片失败，忽略即可：{}", e.getMessage());
        }
    }

    /** 取小写扩展名，不含点号 */
    private String extension(String filename) {
        int index = filename.lastIndexOf('.');
        if (index < 0 || index == filename.length() - 1) {
            return "";
        }
        return filename.substring(index + 1).toLowerCase(Locale.ROOT);
    }
}
