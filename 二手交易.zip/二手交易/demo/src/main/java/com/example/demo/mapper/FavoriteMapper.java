package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.Favorite;
import com.example.demo.entity.Item;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 收藏数据访问层：我的收藏列表关联物品、分类与卖家信息。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface FavoriteMapper extends BaseMapper<Favorite> {

    /** 我的收藏物品（三表关联，复用 Item 实体） */
    List<Item> selectFavoriteItems(@Param("userId") Long userId);
}
