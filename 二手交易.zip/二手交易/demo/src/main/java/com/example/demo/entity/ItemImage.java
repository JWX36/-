package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;

/**
 * 物品图集实体，对应 tb_item_image，实现一物多图上传。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_item_image")
public class ItemImage implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 所属物品 ID */
    private Long itemId;

    /** 图片访问路径 */
    private String imageUrl;

    /** 图片排序号 */
    private Integer sortNo;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取所属物品 ID */
    public Long getItemId() {
        return itemId;
    }

    /** 设置所属物品 ID */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取图片访问路径 */
    public String getImageUrl() {
        return imageUrl;
    }

    /** 设置图片访问路径 */
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    /** 获取图片排序号 */
    public Integer getSortNo() {
        return sortNo;
    }

    /** 设置图片排序号 */
    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

}
