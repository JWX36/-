package com.example.demo.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.validation.constraints.*;

/**
 * 物品发布 / 编辑表单。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class ItemForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 物品 ID（编辑时传入） */
    private Long itemId;

    /** 物品标题 */
    @NotBlank(message = "标题不能为空")
    @Size(max = 120, message = "标题最多 120 字")
    private String title;

    /** 分类 ID */
    @NotNull(message = "请选择分类")
    private Long categoryId;

    /** 售价 */
    @NotNull(message = "请填写售价")
    @DecimalMin(value = "0.01", message = "售价必须大于 0")
    private BigDecimal price;

    /** 原价（选填） */
    private BigDecimal originalPrice;

    /** 交易地点 / 校区 */
    private String campusZone;

    /** 物品描述 */
    @Size(max = 1000, message = "描述最多 1000 字")
    private String description;

    /** 库存数量 */
    @NotNull(message = "请填写库存")
    @Min(value = 1, message = "库存至少 1 件")
    private Integer stock = 1;

    /** 获取物品 ID（编辑时传入） */
    public Long getItemId() {
        return itemId;
    }

    /** 设置物品 ID（编辑时传入） */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取物品标题 */
    public String getTitle() {
        return title;
    }

    /** 设置物品标题 */
    public void setTitle(String title) {
        this.title = title;
    }

    /** 获取分类 ID */
    public Long getCategoryId() {
        return categoryId;
    }

    /** 设置分类 ID */
    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    /** 获取售价 */
    public BigDecimal getPrice() {
        return price;
    }

    /** 设置售价 */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /** 获取原价（选填） */
    public BigDecimal getOriginalPrice() {
        return originalPrice;
    }

    /** 设置原价（选填） */
    public void setOriginalPrice(BigDecimal originalPrice) {
        this.originalPrice = originalPrice;
    }

    /** 获取交易地点 / 校区 */
    public String getCampusZone() {
        return campusZone;
    }

    /** 设置交易地点 / 校区 */
    public void setCampusZone(String campusZone) {
        this.campusZone = campusZone;
    }

    /** 获取物品描述 */
    public String getDescription() {
        return description;
    }

    /** 设置物品描述 */
    public void setDescription(String description) {
        this.description = description;
    }

    /** 获取库存数量 */
    public Integer getStock() {
        return stock;
    }

    /** 设置库存数量 */
    public void setStock(Integer stock) {
        this.stock = stock;
    }

}
