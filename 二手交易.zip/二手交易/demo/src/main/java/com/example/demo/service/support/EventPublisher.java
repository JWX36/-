package com.example.demo.service.support;

import java.util.Map;

/**
 * 领域事件发布抽象（消息队列解耦考点）。
 * 默认演示环境走本地处理器；开启 app.feature.mq-enabled=true 后自动切换为 RabbitMQ 真实异步投递。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface EventPublisher {

    /**
     * 发布领域事件。
     *
     * @param eventType 事件类型：order.created / order.status / item.audit / message.created
     * @param payload   事件载荷（仅包含 ID 与文案，避免传递实体对象）
     */
    void publish(String eventType, Map<String, Object> payload);
}
