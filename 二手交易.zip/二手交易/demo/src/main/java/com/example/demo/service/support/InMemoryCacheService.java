package com.example.demo.service.support;

import com.example.demo.util.CacheJson;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 进程内缓存实现（演示/测试环境默认，零外部依赖）。
 * 具备 TTL 过期、空值占位防穿透、setIfAbsent 原子占位防击穿/重复下单能力。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
@ConditionalOnProperty(prefix = "app.feature", name = "redis-enabled", havingValue = "false", matchIfMissing = true)
public class InMemoryCacheService implements CacheService {

    /** 缓存容器：value 为 JSON 字符串，过期时间单独保存 */
    private final Map<String, CacheEntry> store = new ConcurrentHashMap<>();

    @Override
    public <T> T get(String key, Class<T> type) {
        return CacheJson.read(readRaw(key), type);
    }

    @Override
    public <T> T get(String key, TypeReference<T> type) {
        return CacheJson.read(readRaw(key), type);
    }

    @Override
    public void set(String key, Object value, long ttlSeconds) {
        store.put(key, new CacheEntry(CacheJson.write(value), expireAt(ttlSeconds)));
    }

    @Override
    public void delete(String key) {
        store.remove(key);
    }

    @Override
    public boolean exists(String key) {
        return readRaw(key) != null;
    }

    /** 原子占位：ConcurrentHashMap.putIfAbsent 保证并发安全 */
    @Override
    public boolean setIfAbsent(String key, Object value, long ttlSeconds) {
        CacheEntry entry = new CacheEntry(CacheJson.write(value), expireAt(ttlSeconds));
        return store.putIfAbsent(key, entry) == null;
    }

    /** 读取未过期的值，过期即删除，返回 null 表示缓存未命中 */
    private String readRaw(String key) {
        CacheEntry entry = store.get(key);
        if (entry == null) {
            return null;
        }
        if (entry.expireAt < System.currentTimeMillis()) {
            store.remove(key);
            return null;
        }
        return entry.value;
    }

    private long expireAt(long ttlSeconds) {
        return System.currentTimeMillis() + Math.max(1L, ttlSeconds) * 1000L;
    }

    /** 缓存条目：JSON 值 + 绝对过期时间戳 */
    private static class CacheEntry {
        private final String value;
        private final long expireAt;

        private CacheEntry(String value, long expireAt) {
            this.value = value;
            this.expireAt = expireAt;
        }
    }
}
