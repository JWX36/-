package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.config.AppProperties;
import com.example.demo.dto.ItemForm;
import com.example.demo.dto.ItemQuery;
import com.example.demo.entity.Item;
import com.example.demo.entity.ItemImage;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.ItemImageMapper;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ItemService;
import com.example.demo.service.support.CacheService;
import com.example.demo.service.support.EventPublisher;
import com.example.demo.service.support.FileStorageService;
import com.example.demo.util.UserContext;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 物品模块业务实现：动态 SQL 检索、多图上传、审核流、热点缓存、浏览记录缓存。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class ItemServiceImpl implements ItemService {

    /** 热点物品缓存 key */
    public static final String HOT_CACHE_KEY = "item:hot";

    /** 默认封面与状态常量 */
    private static final String DEFAULT_COVER = "/images/default-item.svg";
    private static final int STATUS_PENDING = 0;
    private static final int STATUS_ON_SALE = 1;
    private static final int STATUS_OFF_SHELF = 2;
    private static final int STATUS_SOLD = 3;
    private static final int STATUS_VIOLATION = 4;
    private static final int STATUS_ARCHIVED = 5;

    private final ItemMapper itemMapper;
    private final ItemImageMapper itemImageMapper;
    private final CategoryService categoryService;
    private final FileStorageService fileStorageService;
    private final CacheService cacheService;
    private final EventPublisher eventPublisher;
    private final UserContext userContext;
    private final AppProperties appProperties;

    public ItemServiceImpl(ItemMapper itemMapper, ItemImageMapper itemImageMapper,
                           CategoryService categoryService, FileStorageService fileStorageService,
                           CacheService cacheService, EventPublisher eventPublisher,
                           UserContext userContext, AppProperties appProperties) {
        this.itemMapper = itemMapper;
        this.itemImageMapper = itemImageMapper;
        this.categoryService = categoryService;
        this.fileStorageService = fileStorageService;
        this.cacheService = cacheService;
        this.eventPublisher = eventPublisher;
        this.userContext = userContext;
        this.appProperties = appProperties;
    }

    /** 前台只允许查看在售物品；后台可指定任意状态 */
    @Override
    public IPage<Item> search(ItemQuery query, Integer defaultStatus) {
        if (query.getStatus() == null) {
            query.setStatus(defaultStatus);
        }
        Page<Item> page = new Page<>(query.getPageNum(), query.getPageSize());
        return itemMapper.searchPage(page, query);
    }

    /** 详情：浏览量自增 + 图集装配 + 浏览记录写入缓存 */
    @Override
    public Item detail(Long itemId, Long viewerId) {
        Item item = itemMapper.selectDetail(itemId);
        if (item == null) {
            throw new BusinessException("物品不存在或已被删除");
        }
        itemMapper.incrementViewCount(itemId);
        item.setViewCount(item.getViewCount() == null ? 1 : item.getViewCount() + 1);
        List<ItemImage> images = itemImageMapper.selectList(new LambdaQueryWrapper<ItemImage>()
                .eq(ItemImage::getItemId, itemId)
                .orderByAsc(ItemImage::getSortNo, ItemImage::getId));
        List<String> urls = images.stream().map(ItemImage::getImageUrl).collect(Collectors.toList());
        if (urls.isEmpty() && item.getCoverImage() != null && !item.getCoverImage().isEmpty()) {
            urls.add(item.getCoverImage());
        }
        item.setImageList(urls);
        if (viewerId != null) {
            recordBrowse(viewerId, itemId);
        }
        cacheService.delete(HOT_CACHE_KEY);
        return item;
    }

    /** 缓存首页热点物品；缓存未命中时回源，空值也缓存 60 秒防穿透 */
    @Override
    public List<Item> hotItems(int limit) {
        List<Item> cached = cacheService.get(HOT_CACHE_KEY, new TypeReference<List<Item>>() {
        });
        if (cached != null) {
            return cached.size() > limit ? cached.subList(0, limit) : cached;
        }
        List<Item> list = itemMapper.selectList(new LambdaQueryWrapper<Item>()
                .eq(Item::getStatus, STATUS_ON_SALE)
                .orderByDesc(Item::getViewCount, Item::getId)
                .last("LIMIT " + Math.max(1, Math.min(limit, 50))));
        cacheService.set(HOT_CACHE_KEY, list, 300);
        return list;
    }

    /** 详情页推荐购买：结果缓存 120 秒，避免每次打开详情都跑一次排序查询 */
    @Override
    public List<Item> recommend(Long itemId, Long categoryId, BigDecimal price, int limit) {
        int size = Math.max(1, Math.min(limit, 12));
        String key = "item:recommend:" + itemId + ":" + size;
        List<Item> cached = cacheService.get(key, new TypeReference<List<Item>>() {
        });
        if (cached != null) {
            return cached;
        }
        BigDecimal base = price == null ? BigDecimal.ZERO : price;
        List<Item> list = itemMapper.selectRecommend(itemId, categoryId, base, size);
        cacheService.set(key, list, 120);
        return list;
    }

    /** 发布物品：分类校验 → 多图保存 → 落库待审核 → 图集落库 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long publish(Long sellerId, ItemForm form, MultipartFile[] images) {
        categoryService.getById(form.getCategoryId());
        List<String> urls = fileStorageService.storeImages(images);
        Item item = new Item();
        item.setSellerId(sellerId);
        item.setCategoryId(form.getCategoryId());
        item.setTitle(form.getTitle());
        item.setDescription(form.getDescription());
        item.setPrice(form.getPrice());
        item.setOriginalPrice(form.getOriginalPrice() == null ? BigDecimal.ZERO : form.getOriginalPrice());
        item.setCampusZone(form.getCampusZone());
        item.setStock(form.getStock() == null ? 1 : form.getStock());
        item.setStatus(STATUS_PENDING);
        item.setViewCount(0);
        item.setCoverImage(urls.isEmpty() ? DEFAULT_COVER : urls.get(0));
        item.setCreateTime(LocalDateTime.now());
        item.setUpdateTime(LocalDateTime.now());
        itemMapper.insert(item);
        saveImages(item.getId(), urls, 0);
        cacheService.delete(HOT_CACHE_KEY);
        return item.getId();
    }

    /** 编辑：校验数据归属（卖家本人或管理员），杜绝水平越权 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(Long itemId, Long sellerId, ItemForm form, MultipartFile[] images) {
        Item item = itemMapper.selectById(itemId);
        if (item == null) {
            throw new BusinessException("物品不存在");
        }
        if (!item.getSellerId().equals(sellerId) && !userContext.isAdmin()) {
            throw new BusinessException("只能编辑自己发布的物品");
        }
        if (item.getStatus() == STATUS_SOLD) {
            throw new BusinessException("已售出的物品不可编辑");
        }
        categoryService.getById(form.getCategoryId());
        item.setCategoryId(form.getCategoryId());
        item.setTitle(form.getTitle());
        item.setDescription(form.getDescription());
        item.setPrice(form.getPrice());
        item.setOriginalPrice(form.getOriginalPrice() == null ? BigDecimal.ZERO : form.getOriginalPrice());
        item.setCampusZone(form.getCampusZone());
        item.setStock(form.getStock() == null ? 1 : form.getStock());
        // 编辑后重新进入审核流程，防止绕过审核上架违规内容
        item.setStatus(STATUS_PENDING);
        item.setRejectReason(null);
        item.setUpdateTime(LocalDateTime.now());
        List<String> urls = fileStorageService.storeImages(images);
        if (!urls.isEmpty()) {
            int startSort = itemImageMapper.selectCount(new LambdaQueryWrapper<ItemImage>()
                    .eq(ItemImage::getItemId, itemId)).intValue();
            saveImages(itemId, urls, startSort);
            item.setCoverImage(urls.get(0));
        }
        itemMapper.updateById(item);
        cacheService.delete(HOT_CACHE_KEY);
    }

    /** 下架：记录下架时间，供每月 1 号的定时清理任务使用 */
    @Override
    public void offShelf(Long itemId, Long operatorId, boolean admin) {
        Item item = itemMapper.selectById(itemId);
        if (item == null) {
            throw new BusinessException("物品不存在");
        }
        if (!admin && !item.getSellerId().equals(operatorId)) {
            throw new BusinessException("只能下架自己发布的物品");
        }
        item.setStatus(admin ? STATUS_VIOLATION : STATUS_OFF_SHELF);
        item.setOffShelfTime(LocalDateTime.now());
        item.setUpdateTime(LocalDateTime.now());
        itemMapper.updateById(item);
        cacheService.delete(HOT_CACHE_KEY);
    }

    /** 审核：通过后上架，驳回则标记违规下架，并发布异步通知事件 */
    @Override
    public void audit(Long itemId, boolean pass, String reason) {
        Item item = itemMapper.selectById(itemId);
        if (item == null) {
            throw new BusinessException("物品不存在");
        }
        item.setStatus(pass ? STATUS_ON_SALE : STATUS_VIOLATION);
        item.setRejectReason(pass ? null : reason);
        item.setOffShelfTime(pass ? null : LocalDateTime.now());
        item.setUpdateTime(LocalDateTime.now());
        itemMapper.updateById(item);
        cacheService.delete(HOT_CACHE_KEY);
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("userId", item.getSellerId());
        payload.put("itemTitle", item.getTitle());
        payload.put("pass", String.valueOf(pass));
        payload.put("reason", reason == null ? "不符合平台规范" : reason);
        eventPublisher.publish("item.audit", payload);
    }

    /**
     * 清理长期下架物品。
     * 采用「归档标记」而非物理删除，避免破坏已成交订单的历史关联数据。
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int cleanExpiredItems(int days) {
        LocalDateTime deadline = LocalDateTime.now().minusDays(Math.max(1, days));
        List<Item> expired = itemMapper.selectList(new LambdaQueryWrapper<Item>()
                .in(Item::getStatus, Arrays.asList(STATUS_OFF_SHELF, STATUS_VIOLATION))
                .isNotNull(Item::getOffShelfTime)
                .lt(Item::getOffShelfTime, deadline));
        for (Item item : expired) {
            item.setStatus(STATUS_ARCHIVED);
            item.setUpdateTime(LocalDateTime.now());
            itemMapper.updateById(item);
        }
        if (!expired.isEmpty()) {
            cacheService.delete(HOT_CACHE_KEY);
        }
        return expired.size();
    }

    /* ==================== 卖家图片管理：查看 / 追加 / 删除 / 设封面 ==================== */

    /** 单件商品最多保留的图片数（默认 5 张，保证 3~5 张自动轮播） */
    @Override
    public int maxImagesPerItem() {
        int max = appProperties.getPhotos().getMaxPerItem();
        return max < 3 ? 3 : Math.min(max, 10);
    }

    /** 归属校验：只有商品发布者本人或管理员可以管理图片 */
    private Item requireOwnedItem(Long itemId, Long operatorId) {
        Item item = itemMapper.selectById(itemId);
        if (item == null) {
            throw new BusinessException("商品不存在或已被删除");
        }
        if (!item.getSellerId().equals(operatorId) && !userContext.isAdmin()) {
            throw new BusinessException("只能管理自己发布的商品图片");
        }
        return item;
    }

    /** 按 sort_no、id 顺序读取某件商品的图集 */
    private List<ItemImage> orderedImages(Long itemId) {
        return itemImageMapper.selectList(new LambdaQueryWrapper<ItemImage>()
                .eq(ItemImage::getItemId, itemId)
                .orderByAsc(ItemImage::getSortNo, ItemImage::getId));
    }

    /** 读取自己发布的商品（不触发浏览量自增） */
    @Override
    public Item ownedItem(Long itemId, Long operatorId) {
        return requireOwnedItem(itemId, operatorId);
    }

    /** 卖家查看自己商品的图集 */
    @Override
    public List<ItemImage> ownedImages(Long itemId, Long operatorId) {
        requireOwnedItem(itemId, operatorId);
        return orderedImages(itemId);
    }

    /** 批量统计「我的发布」里每件商品的图片张数 */
    @Override
    public Map<Long, Integer> imageCounts(Collection<Long> itemIds) {
        Map<Long, Integer> result = new HashMap<>();
        if (itemIds == null || itemIds.isEmpty()) {
            return result;
        }
        List<ItemImage> images = itemImageMapper.selectList(new LambdaQueryWrapper<ItemImage>()
                .in(ItemImage::getItemId, itemIds));
        for (ItemImage image : images) {
            result.merge(image.getItemId(), 1, Integer::sum);
        }
        return result;
    }

    /**
     * 卖家为「已经发布过的商品」继续追加实拍图。
     * 不改动商品标题 / 价格 / 状态，也不触发重新审核，追加后详情页轮播立即可见。
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int appendImages(Long itemId, Long operatorId, MultipartFile[] images) {
        Item item = requireOwnedItem(itemId, operatorId);
        int current = orderedImages(itemId).size();
        int max = maxImagesPerItem();
        if (current >= max) {
            throw new BusinessException("每件商品最多 " + max + " 张实拍图，请先删除一张再上传");
        }
        if (images == null || images.length == 0) {
            throw new BusinessException("请先选择要上传的图片");
        }
        int room = max - current;
        MultipartFile[] accepted = Arrays.copyOf(images, Math.min(images.length, room));
        List<String> urls = fileStorageService.storeImages(accepted);
        if (urls.isEmpty()) {
            throw new BusinessException("没有读取到有效的图片文件，请检查格式后重试");
        }
        saveImages(itemId, urls, current);
        // 商品原本没有图集（或封面仍是占位图）时，把第一张新图设为封面
        if (current == 0 || isBlankCover(item.getCoverImage())) {
            item.setCoverImage(urls.get(0));
            item.setUpdateTime(LocalDateTime.now());
            itemMapper.updateById(item);
        }
        cacheService.delete(HOT_CACHE_KEY);
        return urls.size();
    }

    /** 卖家删除一张图片；至少保留 1 张，封面自动顺延到剩余第一张 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void removeImage(Long itemId, Long imageId, Long operatorId) {
        Item item = requireOwnedItem(itemId, operatorId);
        List<ItemImage> images = orderedImages(itemId);
        if (images.size() <= 1) {
            throw new BusinessException("至少保留 1 张商品图片，不能直接删除最后一张");
        }
        ItemImage target = null;
        for (ItemImage image : images) {
            if (image.getId().equals(imageId)) {
                target = image;
                break;
            }
        }
        if (target == null) {
            throw new BusinessException("图片不存在或不属于该商品");
        }
        itemImageMapper.deleteById(imageId);
        images.remove(target);
        reorderImages(images);
        item.setCoverImage(images.get(0).getImageUrl());
        item.setUpdateTime(LocalDateTime.now());
        itemMapper.updateById(item);
        fileStorageService.deleteByUrl(target.getImageUrl());
        cacheService.delete(HOT_CACHE_KEY);
    }

    /** 卖家把选中的图片设为封面：同步 tb_item.cover_image 与图集排序 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void markCover(Long itemId, Long imageId, Long operatorId) {
        Item item = requireOwnedItem(itemId, operatorId);
        List<ItemImage> images = orderedImages(itemId);
        ItemImage target = null;
        for (ItemImage image : images) {
            if (image.getId().equals(imageId)) {
                target = image;
                break;
            }
        }
        if (target == null) {
            throw new BusinessException("图片不存在或不属于该商品");
        }
        images.remove(target);
        images.add(0, target);
        reorderImages(images);
        item.setCoverImage(target.getImageUrl());
        item.setUpdateTime(LocalDateTime.now());
        itemMapper.updateById(item);
        cacheService.delete(HOT_CACHE_KEY);
    }

    /** 重新编号 0..n-1，保证轮播顺序稳定 */
    private void reorderImages(List<ItemImage> images) {
        for (int i = 0; i < images.size(); i++) {
            ItemImage image = images.get(i);
            if (image.getSortNo() == null || image.getSortNo() != i) {
                image.setSortNo(i);
                itemImageMapper.updateById(image);
            }
        }
    }

    /** 空封面或默认 SVG 占位封面 */
    private boolean isBlankCover(String cover) {
        return cover == null || cover.isEmpty() || DEFAULT_COVER.equals(cover);
    }

    /** 保存图片记录到 tb_item_image */
    private void saveImages(Long itemId, List<String> urls, int startSort) {
        int sort = startSort;
        for (String url : urls) {
            ItemImage image = new ItemImage();
            image.setItemId(itemId);
            image.setImageUrl(url);
            image.setSortNo(sort++);
            itemImageMapper.insert(image);
        }
    }

    /** 用户浏览记录写入缓存（去重、最多 10 条、保留 7 天） */
    private void recordBrowse(Long userId, Long itemId) {
        String key = "user:browse:" + userId;
        List<Long> history = cacheService.get(key, new TypeReference<List<Long>>() {
        });
        List<Long> list = history == null ? new ArrayList<>() : new ArrayList<>(history);
        list.remove(itemId);
        list.add(0, itemId);
        if (list.size() > 10) {
            list = new ArrayList<>(list.subList(0, 10));
        }
        cacheService.set(key, list, 7 * 24 * 3600L);
    }
}
