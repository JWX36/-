package com.example.demo.controller.api;

import com.example.demo.common.Result;
import com.example.demo.config.AppProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 公开 REST 接口：健康检查与系统信息，便于答辩演示接口联调。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@RestController
@RequestMapping("/api/public")
public class PublicApiController {

    private final AppProperties appProperties;

    public PublicApiController(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    /** 健康检查：返回系统名称、当前激活环境与中间件开关状态 */
    @GetMapping("/health")
    public Result<Map<String, Object>> health() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("app", appProperties.getName());
        data.put("status", "UP");
        data.put("redisEnabled", appProperties.getFeature().isRedisEnabled());
        data.put("mqEnabled", appProperties.getFeature().isMqEnabled());
        data.put("mailEnabled", appProperties.getFeature().isMailEnabled());
        return Result.ok(data);
    }
}
