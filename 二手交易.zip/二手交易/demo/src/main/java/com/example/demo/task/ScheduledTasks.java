package com.example.demo.task;

import com.example.demo.config.AppProperties;
import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.service.DashboardService;
import com.example.demo.service.ItemService;
import com.example.demo.service.RefundService;
import com.example.demo.service.TradeOrderService;
import com.example.demo.service.support.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Spring Task 定时任务（进阶/高阶考点）：
 * ① 每分钟扫描超时未支付订单并自动取消、恢复库存（RabbitMQ 场景之一，演示环境直接调度）；
 * ② 每分钟扫描卖家超时未处理的退款申请并自动同意退款；
 * ③ 每日凌晨生成平台日交易数据统计；④ 每月 1 号清理超过 30 天的已下架物品。
 * 所有任务内部均做异常兜底，单个任务失败不会影响系统运行。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Component
public class ScheduledTasks {

    private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);

    private final TradeOrderService tradeOrderService;
    private final RefundService refundService;
    private final ItemService itemService;
    private final DashboardService dashboardService;
    private final NotificationService notificationService;
    private final UserMapper userMapper;
    private final AppProperties appProperties;

    public ScheduledTasks(TradeOrderService tradeOrderService, RefundService refundService,
                          ItemService itemService,
                          DashboardService dashboardService, NotificationService notificationService,
                          UserMapper userMapper, AppProperties appProperties) {
        this.tradeOrderService = tradeOrderService;
        this.refundService = refundService;
        this.itemService = itemService;
        this.dashboardService = dashboardService;
        this.notificationService = notificationService;
        this.userMapper = userMapper;
        this.appProperties = appProperties;
    }

    /** 每 60 秒执行一次：超过支付时限的订单自动取消 */
    @Scheduled(fixedDelay = 60000, initialDelay = 20000)
    public void cancelTimeoutOrders() {
        try {
            int count = tradeOrderService.cancelTimeoutOrders(appProperties.getOrder().getPayTimeoutMinutes());
            if (count > 0) {
                log.info("超时订单自动取消完成，本次处理 {} 笔", count);
            }
        } catch (Exception e) {
            log.error("超时订单任务执行失败", e);
        }
    }

    /**
     * 每 60 秒执行一次：卖家超过配置时限仍未处理的退款申请，按平台规则自动同意退款。
     * 与「30 分钟未支付自动取消」共同构成交易闭环的超时兜底机制。
     */
    @Scheduled(fixedDelay = 60000, initialDelay = 30000)
    public void autoApproveExpiredRefunds() {
        try {
            int hours = appProperties.getRefund().getSellerHandleHours();
            int count = refundService.autoApproveExpired(hours);
            if (count > 0) {
                log.info("超时退款申请自动同意完成，本次处理 {} 笔", count);
            }
        } catch (Exception e) {
            log.error("超时退款自动处理任务执行失败", e);
        }
    }

    /** 每天凌晨 3 点：生成日交易数据统计，并给管理员推送站内通知 */
    @Scheduled(cron = "0 0 3 * * ?")
    public void dailyTradeReport() {
        try {
            Map<String, Object> summary = dashboardService.summary();
            String content = "平台累计用户 " + summary.get("userCount") + " 人，在售物品 "
                    + summary.get("onSaleCount") + " 件，累计订单 " + summary.get("orderCount")
                    + " 笔，累计成交金额 ¥" + summary.get("tradeAmount")
                    + "，待审核物品 " + summary.get("pendingCount") + " 件。";
            log.info("每日交易数据统计：{}", content);
            List<User> admins = userMapper.selectList(new LambdaQueryWrapper<User>()
                    .eq(User::getRole, "ADMIN"));
            for (User admin : admins) {
                notificationService.notifyUser(admin.getId(), "平台日交易数据统计", content, "SYSTEM", false);
            }
        } catch (Exception e) {
            log.error("每日统计任务执行失败", e);
        }
    }

    /** 每月 1 号凌晨 4 点：清理超过配置天数的已下架物品 */
    @Scheduled(cron = "0 0 4 1 * ?")
    public void cleanupOffShelfItems() {
        try {
            int count = itemService.cleanExpiredItems(appProperties.getOrder().getCleanupDays());
            log.info("过期下架物品清理完成，本次归档 {} 件", count);
        } catch (Exception e) {
            log.error("过期物品清理任务执行失败", e);
        }
    }
}
