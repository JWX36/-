package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.OperationLog;

/**
 * 操作日志数据访问层，由 AOP 切面写入。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface OperationLogMapper extends BaseMapper<OperationLog> {
}
