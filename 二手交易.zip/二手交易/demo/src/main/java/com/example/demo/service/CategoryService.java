package com.example.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.dto.CategoryForm;
import com.example.demo.dto.PageQuery;
import com.example.demo.entity.Category;

import java.util.List;

/**
 * 分类模块业务接口：读多写少，查询走缓存，写操作主动失效缓存。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface CategoryService {

    /** 全部分类（启用状态），优先读缓存 */
    List<Category> listAll();

    /** 后台分页 */
    IPage<Category> pageCategories(PageQuery query);

    /** 按 ID 查询 */
    Category getById(Long id);

    /** 新增分类 */
    void save(CategoryForm form);

    /** 编辑分类 */
    void update(Long id, CategoryForm form);

    /** 删除分类（存在关联物品时拒绝删除） */
    void remove(Long id);
}
