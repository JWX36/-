package com.example.demo.service.support;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

/**
 * Spring Security 用户认证数据源：把数据库用户转换成 UserDetails。
 * 角色统一加 ROLE_ 前缀，与 SecurityConfig / @PreAuthorize 的 hasRole 保持一致。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserService userService;

    public CustomUserDetailsService(UserService userService) {
        this.userService = userService;
    }

    /** 按账号加载用户；禁用账号通过 enabled=false 拒绝登录 */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userService.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("账号或密码错误");
        }
        boolean enabled = user.getStatus() == null || user.getStatus() == 1;
        String role = user.getRole() == null ? "USER" : user.getRole();
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                enabled,
                true,
                true,
                true,
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role)));
    }
}
