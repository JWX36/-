package com.example.demo.controller.admin;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.dto.CategoryForm;
import com.example.demo.dto.ItemQuery;
import com.example.demo.dto.PageQuery;
import com.example.demo.entity.OperationLog;
import com.example.demo.mapper.MessageMapper;
import com.example.demo.mapper.OperationLogMapper;
import com.example.demo.util.PageUrl;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ChatService;
import com.example.demo.service.DashboardService;
import com.example.demo.service.ItemService;
import com.example.demo.service.RefundService;
import com.example.demo.service.TradeOrderService;
import com.example.demo.service.UserService;
import com.example.demo.util.UserContext;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.Map;

/**
 * 后台管理端控制器（菜单级 + 接口级双重权限校验）。
 * 类上 @PreAuthorize 保证即使 URL 规则被绕过，方法级权限仍然拦截。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserService userService;
    private final ItemService itemService;
    private final CategoryService categoryService;
    private final TradeOrderService tradeOrderService;
    private final DashboardService dashboardService;
    private final OperationLogMapper operationLogMapper;
    private final ChatService chatService;
    private final MessageMapper messageMapper;
    private final RefundService refundService;
    private final UserContext userContext;

    public AdminController(UserService userService, ItemService itemService,
                           CategoryService categoryService, TradeOrderService tradeOrderService,
                           DashboardService dashboardService, OperationLogMapper operationLogMapper,
                           ChatService chatService, MessageMapper messageMapper,
                           RefundService refundService, UserContext userContext) {
        this.userService = userService;
        this.itemService = itemService;
        this.categoryService = categoryService;
        this.tradeOrderService = tradeOrderService;
        this.dashboardService = dashboardService;
        this.operationLogMapper = operationLogMapper;
        this.chatService = chatService;
        this.messageMapper = messageMapper;
        this.refundService = refundService;
        this.userContext = userContext;
    }

    /** 后台首页：概览指标 + ECharts 容器（图表数据由 /api/admin/** 异步加载） */
    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Model model) {
        Map<String, Object> summary = dashboardService.summary();
        model.addAttribute("summary", summary);
        return "admin/dashboard";
    }

    /** 用户管理 */
    @GetMapping("/users")
    public String users(PageQuery query,
                        @RequestParam(value = "keyword", required = false) String keyword,
                        @RequestParam(value = "role", required = false) String role,
                        Model model) {
        model.addAttribute("users", userService.pageUsers(query, keyword, role));
        model.addAttribute("keyword", keyword);
        model.addAttribute("roleFilter", role);
        model.addAttribute("pageBase", PageUrl.build("/admin/users", "keyword", keyword, "role", role));
        return "admin/users";
    }

    /** 启用 / 禁用用户 */
    @PostMapping("/users/status/{id}")
    public String changeStatus(@PathVariable("id") Long id,
                               @RequestParam("status") Integer status) {
        userService.changeStatus(id, status);
        return "redirect:/admin/users";
    }

    /** 提升为认证卖家 / 调整角色 */
    @PostMapping("/users/role/{id}")
    public String changeRole(@PathVariable("id") Long id,
                             @RequestParam("role") String role,
                             RedirectAttributes redirectAttributes) {
        try {
            userService.changeRole(id, role);
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/users";
    }

    /** 物品管理：默认展示待审核物品 */
    @GetMapping("/items")
    public String items(ItemQuery query,
                        @RequestParam(value = "status", required = false) Integer status,
                        Model model) {
        query.setStatus(status == null ? 0 : status);
        model.addAttribute("items", itemService.search(query, null));
        model.addAttribute("query", query);
        model.addAttribute("statusFilter", status == null ? 0 : status);
        model.addAttribute("pageBase", PageUrl.build("/admin/items",
                "status", status == null ? 0 : status, "keyword", query.getKeyword(),
                "sortBy", query.getSortBy()));
        return "admin/items";
    }

    /** 审核通过 / 驳回 */
    @PostMapping("/items/audit/{id}")
    public String audit(@PathVariable("id") Long id,
                        @RequestParam("pass") boolean pass,
                        @RequestParam(value = "reason", required = false) String reason) {
        itemService.audit(id, pass, pass ? null : (reason == null || reason.isEmpty() ? "不符合平台规范" : reason));
        return "redirect:/admin/items";
    }

    /** 违规物品下架 */
    @PostMapping("/items/off-shelf/{id}")
    public String offShelf(@PathVariable("id") Long id) {
        // 管理员下架：operatorId 仅用于留痕，admin=true 会标记为违规下架
        itemService.offShelf(id, null, true);
        return "redirect:/admin/items?status=1";
    }

    /** 分类管理 */
    @GetMapping("/categories")
    public String categories(PageQuery query, Model model) {
        model.addAttribute("categories", categoryService.pageCategories(query));
        model.addAttribute("pageBase", PageUrl.build("/admin/categories"));
        if (!model.containsAttribute("categoryForm")) {
            model.addAttribute("categoryForm", new CategoryForm());
        }
        return "admin/categories";
    }

    /** 新增分类 */
    @PostMapping("/categories/save")
    public String saveCategory(@Valid @ModelAttribute("categoryForm") CategoryForm form,
                               BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    bindingResult.getFieldError() == null ? "请检查表单"
                            : bindingResult.getFieldError().getDefaultMessage());
            return "redirect:/admin/categories";
        }
        categoryService.save(form);
        return "redirect:/admin/categories?saved";
    }

    /** 编辑分类 */
    @PostMapping("/categories/edit/{id}")
    public String editCategory(@PathVariable("id") Long id,
                               @Valid @ModelAttribute("categoryForm") CategoryForm form,
                               BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "分类名称不能为空");
            return "redirect:/admin/categories";
        }
        try {
            categoryService.update(id, form);
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/categories";
    }

    /** 删除分类 */
    @PostMapping("/categories/delete/{id}")
    public String deleteCategory(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        try {
            categoryService.remove(id);
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/categories";
    }

    /** 订单管理 */
    @GetMapping("/orders")
    public String orders(PageQuery query,
                         @RequestParam(value = "status", required = false) Integer status,
                         Model model) {
        model.addAttribute("orders", tradeOrderService.pageOrders(query, null, null, status));
        model.addAttribute("query", query);
        model.addAttribute("statusFilter", status);
        model.addAttribute("pageBase", PageUrl.build("/admin/orders", "status", status));
        return "admin/orders";
    }

    /**
     * 消息监管：管理员统一查看全站客服会话、客服消息与商品评价（买家 / 卖家 / 管理员消息全员可见）。
     */
    @GetMapping("/chats")
    public String chats(Model model) {
        model.addAttribute("sessions", chatService.listAll());
        model.addAttribute("recentChats", chatService.recentMessages(30));
        model.addAttribute("recentComments", messageMapper.selectRecentComments(30));
        return "admin/chats";
    }

    /** 退款仲裁：管理员查看全站退款申请，对平台介入 / 待处理申请作出裁定 */
    @GetMapping("/refunds")
    public String refunds(Model model) {
        model.addAttribute("refunds", refundService.listAll());
        return "admin/refunds";
    }

    /** 裁定同意退款（订单转「已退款」并恢复库存）或驳回申请 */
    @PostMapping("/refunds/decide/{id}")
    public String decideRefund(@PathVariable("id") Long id,
                               @RequestParam(value = "approve", defaultValue = "false") boolean approve,
                               @RequestParam(value = "note", required = false) String note,
                               RedirectAttributes redirectAttributes) {
        try {
            refundService.decide(id, userContext.currentUserId(), approve, note);
            redirectAttributes.addFlashAttribute("successMessage",
                    approve ? "已裁定支持买家，退款完成，订单与库存已更新" : "已驳回该退款申请");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/admin/refunds";
    }

    /** 操作日志（AOP 切面写入） */
    @GetMapping("/logs")
    public String logs(PageQuery query, Model model) {
        Page<OperationLog> page = new Page<>(query.getPageNum(), query.getPageSize());
        model.addAttribute("logs", operationLogMapper.selectPage(page,
                new LambdaQueryWrapper<OperationLog>().orderByDesc(OperationLog::getId)));
        model.addAttribute("pageBase", PageUrl.build("/admin/logs"));
        return "admin/logs";
    }
}
