package com.example.demo.dto;

import java.io.Serializable;
import javax.validation.constraints.*;

/**
 * 下单表单。requestNo 为前端生成的幂等键，防止重复下单。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class OrderForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 物品 ID */
    @NotNull(message = "请选择物品")
    private Long itemId;

    /** 购买数量 */
    @NotNull(message = "请填写数量")
    @Min(value = 1, message = "数量至少 1 件")
    private Integer quantity;

    /** 幂等请求号（UUID） */
    @NotBlank(message = "请求号不能为空")
    private String requestNo;

    /** 获取物品 ID */
    public Long getItemId() {
        return itemId;
    }

    /** 设置物品 ID */
    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    /** 获取购买数量 */
    public Integer getQuantity() {
        return quantity;
    }

    /** 设置购买数量 */
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    /** 获取幂等请求号（UUID） */
    public String getRequestNo() {
        return requestNo;
    }

    /** 设置幂等请求号（UUID） */
    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

}
