package com.example.demo.dto;

import java.io.Serializable;
import javax.validation.constraints.*;

/**
 * 后台分类新增 / 编辑表单。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class CategoryForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 分类名称 */
    @NotBlank(message = "分类名称不能为空")
    @Size(max = 30, message = "分类名称最多 30 字")
    private String name;

    /** 排序号 */
    private Integer sortNo = 0;

    /** 状态 1 启用 0 停用 */
    private Integer status = 1;

    /** 获取分类名称 */
    public String getName() {
        return name;
    }

    /** 设置分类名称 */
    public void setName(String name) {
        this.name = name;
    }

    /** 获取排序号 */
    public Integer getSortNo() {
        return sortNo;
    }

    /** 设置排序号 */
    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    /** 获取状态 1 启用 0 停用 */
    public Integer getStatus() {
        return status;
    }

    /** 设置状态 1 启用 0 停用 */
    public void setStatus(Integer status) {
        this.status = status;
    }

}
