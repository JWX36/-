package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.dto.OrderForm;
import com.example.demo.dto.PageQuery;
import com.example.demo.entity.Item;
import com.example.demo.entity.TradeOrder;
import com.example.demo.exception.BusinessException;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.mapper.TradeOrderMapper;
import com.example.demo.service.TradeOrderService;
import com.example.demo.service.support.CacheService;
import com.example.demo.service.support.EventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 订单模块业务实现：完整状态流转 + 幂等下单 + 防超卖 + 超时自动取消 + 异步事件通知。
 * 状态：0 待支付 / 1 已支付待确认 / 2 已完成 / 3 已取消 / 4 超时自动取消。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@Service
public class TradeOrderServiceImpl implements TradeOrderService {

    private static final int WAIT_PAY = 0;
    private static final int PAID = 1;
    private static final int FINISHED = 2;
    private static final int CANCELED = 3;
    private static final int TIMEOUT = 4;

    private final TradeOrderMapper tradeOrderMapper;
    private final ItemMapper itemMapper;
    private final CacheService cacheService;
    private final EventPublisher eventPublisher;

    public TradeOrderServiceImpl(TradeOrderMapper tradeOrderMapper, ItemMapper itemMapper,
                                 CacheService cacheService, EventPublisher eventPublisher) {
        this.tradeOrderMapper = tradeOrderMapper;
        this.itemMapper = itemMapper;
        this.cacheService = cacheService;
        this.eventPublisher = eventPublisher;
    }

    /**
     * 创建订单：
     * ① 幂等键 setIfAbsent 防重复提交；② 校验物品与库存；③ 同一买家同物品未完成订单互斥；
     * ④ 带库存条件的原子扣减防超卖；⑤ 发布 order.created 异步通知。
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TradeOrder create(Long buyerId, OrderForm form) {
        String idemKey = "order:idem:" + buyerId + ":" + form.getRequestNo();
        if (!cacheService.setIfAbsent(idemKey, "1", 600)) {
            throw new BusinessException("订单正在处理中，请勿重复提交");
        }
        try {
            Item item = itemMapper.selectById(form.getItemId());
            if (item == null) {
                throw new BusinessException("物品不存在");
            }
            if (item.getStatus() == null || item.getStatus() != 1) {
                throw new BusinessException("该物品当前不可购买");
            }
            if (item.getSellerId().equals(buyerId)) {
                throw new BusinessException("不能购买自己发布的物品");
            }
            int quantity = form.getQuantity() == null ? 1 : form.getQuantity();
            if (item.getStock() == null || item.getStock() < quantity) {
                throw new BusinessException("库存不足");
            }
            Long pending = tradeOrderMapper.selectCount(new LambdaQueryWrapper<TradeOrder>()
                    .eq(TradeOrder::getBuyerId, buyerId)
                    .eq(TradeOrder::getItemId, item.getId())
                    .in(TradeOrder::getStatus, Arrays.asList(WAIT_PAY, PAID)));
            if (pending != null && pending > 0) {
                throw new BusinessException("您已有该物品的未完成订单，请先完成或取消");
            }
            if (itemMapper.deductStock(item.getId(), quantity) != 1) {
                throw new BusinessException("库存不足，下单失败");
            }
            TradeOrder order = new TradeOrder();
            order.setOrderNo(generateOrderNo());
            order.setRequestNo(form.getRequestNo());
            order.setBuyerId(buyerId);
            order.setSellerId(item.getSellerId());
            order.setItemId(item.getId());
            order.setPrice(item.getPrice());
            order.setQuantity(quantity);
            order.setAmount(item.getPrice().multiply(BigDecimal.valueOf(quantity)));
            order.setStatus(WAIT_PAY);
            order.setCreateTime(LocalDateTime.now());
            order.setUpdateTime(LocalDateTime.now());
            tradeOrderMapper.insert(order);
            Item latest = itemMapper.selectById(item.getId());
            if (latest != null && latest.getStock() != null && latest.getStock() <= 0) {
                latest.setStatus(3);
                latest.setUpdateTime(LocalDateTime.now());
                itemMapper.updateById(latest);
            }
            cacheService.delete("item:hot");
            publishOrderCreated(order, item.getTitle());
            return order;
        } catch (RuntimeException e) {
            // 业务失败时释放幂等键，允许用户修正后重新提交
            cacheService.delete(idemKey);
            throw e;
        }
    }

    /** 模拟支付：只有买家本人可以支付，状态必须为待支付 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void pay(Long orderId, Long buyerId) {
        TradeOrder order = tradeOrderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        if (!order.getBuyerId().equals(buyerId)) {
            throw new BusinessException("只能支付自己的订单");
        }
        if (order.getStatus() != WAIT_PAY) {
            throw new BusinessException("当前订单状态不允许支付");
        }
        order.setStatus(PAID);
        order.setPayTime(LocalDateTime.now());
        order.setUpdateTime(LocalDateTime.now());
        tradeOrderMapper.updateById(order);
        publishOrderStatus(order, "已支付，等待买家确认交易");
    }

    /** 买家确认交易：订单完成 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void confirm(Long orderId, Long userId) {
        TradeOrder order = tradeOrderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        if (!order.getBuyerId().equals(userId)) {
            throw new BusinessException("只有买家可以确认交易");
        }
        if (order.getStatus() != PAID) {
            throw new BusinessException("当前订单状态不允许确认交易");
        }
        order.setStatus(FINISHED);
        order.setFinishTime(LocalDateTime.now());
        order.setUpdateTime(LocalDateTime.now());
        tradeOrderMapper.updateById(order);
        publishOrderStatus(order, "交易已完成");
    }

    /** 取消订单：买家或卖家可取消，恢复库存并推送状态变更 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancel(Long orderId, Long userId, String reason) {
        TradeOrder order = tradeOrderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        if (!order.getBuyerId().equals(userId) && !order.getSellerId().equals(userId)) {
            throw new BusinessException("无权取消该订单");
        }
        if (order.getStatus() != WAIT_PAY && order.getStatus() != PAID) {
            throw new BusinessException("当前订单状态不允许取消");
        }
        doCancel(order, CANCELED, reason == null || reason.isEmpty() ? "用户主动取消" : reason);
    }

    @Override
    public IPage<TradeOrder> pageOrders(PageQuery query, Long buyerId, Long sellerId, Integer status) {
        Page<TradeOrder> page = new Page<>(query.getPageNum(), query.getPageSize());
        return tradeOrderMapper.selectOrderPage(page, buyerId, sellerId, status);
    }

    /**
     * 实时统计待办订单数：导航栏红点与订单中心状态分组共用。
     * 与站内通知的「已读」状态解耦——即使通知被标记为已读，只要订单仍待支付，角标就一直提醒。
     */
    @Override
    public long countByStatus(Long buyerId, Long sellerId, Integer status) {
        LambdaQueryWrapper<TradeOrder> wrapper = new LambdaQueryWrapper<>();
        if (buyerId != null) {
            wrapper.eq(TradeOrder::getBuyerId, buyerId);
        }
        if (sellerId != null) {
            wrapper.eq(TradeOrder::getSellerId, sellerId);
        }
        if (status != null) {
            wrapper.eq(TradeOrder::getStatus, status);
        }
        Long count = tradeOrderMapper.selectCount(wrapper);
        return count == null ? 0L : count;
    }

    /** 0 待支付 / 1 已支付待确认 / 2 已完成 / 3 已取消 / 4 超时取消 / 5 已退款 */
    @Override
    public Map<Integer, Long> countGroupByStatus(Long buyerId, Long sellerId) {
        Map<Integer, Long> counts = new LinkedHashMap<>();
        for (int status = WAIT_PAY; status <= 5; status++) {
            counts.put(status, countByStatus(buyerId, sellerId, status));
        }
        return counts;
    }

    /** 订单详情：非管理员只能查看自己作为买家或卖家的订单（防水平越权） */
    @Override
    public TradeOrder detail(Long id, Long userId, boolean admin) {
        TradeOrder order = tradeOrderMapper.selectDetail(id);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }
        if (!admin && !order.getBuyerId().equals(userId) && !order.getSellerId().equals(userId)) {
            throw new BusinessException("无权查看该订单");
        }
        return order;
    }

    /** 定时任务：扫描创建时间超过 N 分钟仍未支付的订单，自动取消并恢复库存 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int cancelTimeoutOrders(int minutes) {
        LocalDateTime deadline = LocalDateTime.now().minusMinutes(Math.max(1, minutes));
        List<TradeOrder> timeoutOrders = tradeOrderMapper.selectTimeoutOrders(deadline);
        for (TradeOrder order : timeoutOrders) {
            doCancel(order, TIMEOUT, "超过 " + minutes + " 分钟未支付，系统自动取消");
        }
        return timeoutOrders.size();
    }

    /** 统一的取消逻辑：改状态 → 恢复库存 → 物品重新在售 → 发布状态变更事件 */
    private void doCancel(TradeOrder order, int targetStatus, String reason) {
        order.setStatus(targetStatus);
        order.setCancelReason(reason);
        order.setUpdateTime(LocalDateTime.now());
        tradeOrderMapper.updateById(order);
        itemMapper.restoreStock(order.getItemId(), order.getQuantity());
        Item item = itemMapper.selectById(order.getItemId());
        if (item != null && item.getStatus() != null && item.getStatus() == 3) {
            item.setStatus(1);
            item.setUpdateTime(LocalDateTime.now());
            itemMapper.updateById(item);
        }
        cacheService.delete("item:hot");
        publishOrderStatus(order, targetStatus == TIMEOUT ? "超时未支付，系统自动取消并恢复库存" : "订单已取消");
    }

    /** 下单成功事件：通知买家下单成功、通知卖家有新订单 */
    private void publishOrderCreated(TradeOrder order, String itemTitle) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("orderNo", order.getOrderNo());
        payload.put("itemTitle", itemTitle);
        payload.put("buyerId", order.getBuyerId());
        payload.put("sellerId", order.getSellerId());
        payload.put("amount", order.getAmount());
        eventPublisher.publish("order.created", payload);
    }

    /** 订单状态变更事件：异步推送买卖双方 */
    private void publishOrderStatus(TradeOrder order, String statusText) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("orderNo", order.getOrderNo());
        payload.put("itemTitle", itemTitle(order.getItemId()));
        payload.put("buyerId", order.getBuyerId());
        payload.put("sellerId", order.getSellerId());
        payload.put("statusText", statusText);
        eventPublisher.publish("order.status", payload);
    }

    /** 取物品标题作为通知内容，物品被清理时回退为订单号 */
    private String itemTitle(Long itemId) {
        Item item = itemMapper.selectById(itemId);
        return item == null ? "订单 " + itemId : item.getTitle();
    }

    /** 订单号：CM + 时间戳 + 4 位随机数，业务唯一 */
    private String generateOrderNo() {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        return "CM" + time + String.format("%04d", ThreadLocalRandom.current().nextInt(10000));
    }
}
