package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.Category;

/**
 * 分类数据访问层。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface CategoryMapper extends BaseMapper<Category> {
}
