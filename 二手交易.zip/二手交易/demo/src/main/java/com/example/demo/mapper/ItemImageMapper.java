package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.ItemImage;

/**
 * 物品图片数据访问层（一物多图）。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public interface ItemImageMapper extends BaseMapper<ItemImage> {
}
