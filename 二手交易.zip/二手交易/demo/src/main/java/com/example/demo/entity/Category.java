package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 物品分类实体，对应 tb_category。分类数据属于典型读多写少数据，接入缓存。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@TableName("tb_category")
public class Category implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键 */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 分类名称 */
    private String name;

    /** 排序号，越小越靠前 */
    private Integer sortNo;

    /** 状态：1 启用，0 停用 */
    private Integer status;

    /** 创建时间 */
    private LocalDateTime createTime;

    /** 非数据库字段：该分类下在售物品数量（多表统计结果） */
    @TableField(exist = false)
    private Long itemCount;

    /** 获取主键 */
    public Long getId() {
        return id;
    }

    /** 设置主键 */
    public void setId(Long id) {
        this.id = id;
    }

    /** 获取分类名称 */
    public String getName() {
        return name;
    }

    /** 设置分类名称 */
    public void setName(String name) {
        this.name = name;
    }

    /** 获取排序号，越小越靠前 */
    public Integer getSortNo() {
        return sortNo;
    }

    /** 设置排序号，越小越靠前 */
    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    /** 获取状态：1 启用，0 停用 */
    public Integer getStatus() {
        return status;
    }

    /** 设置状态：1 启用，0 停用 */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /** 获取创建时间 */
    public LocalDateTime getCreateTime() {
        return createTime;
    }

    /** 设置创建时间 */
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    /** 获取非数据库字段：该分类下在售物品数量（多表统计结果） */
    public Long getItemCount() {
        return itemCount;
    }

    /** 设置非数据库字段：该分类下在售物品数量（多表统计结果） */
    public void setItemCount(Long itemCount) {
        this.itemCount = itemCount;
    }

}
