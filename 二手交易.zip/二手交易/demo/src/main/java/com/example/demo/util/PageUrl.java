package com.example.demo.util;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * 分页 URL 构造工具：把当前检索条件编码后拼进分页链接，翻页不丢失筛选条件。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public final class PageUrl {

    private PageUrl() {
        // 工具类禁止实例化
    }

    /**
     * @param path 列表页地址
     * @param kv   成对出现的参数名与参数值，值为 null 或空串时忽略
     * @return 形如 /items/list?_=1&amp;keyword=xxx 的分页基础 URL
     */
    public static String build(String path, Object... kv) {
        StringBuilder url = new StringBuilder(path).append("?_=1");
        for (int i = 0; i + 1 < kv.length; i += 2) {
            Object value = kv[i + 1];
            if (value == null || String.valueOf(value).isEmpty()) {
                continue;
            }
            url.append('&').append(kv[i]).append('=')
                    .append(URLEncoder.encode(String.valueOf(value), StandardCharsets.UTF_8));
        }
        return url.toString();
    }
}
