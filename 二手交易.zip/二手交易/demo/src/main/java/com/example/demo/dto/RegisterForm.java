package com.example.demo.dto;

import java.io.Serializable;
import javax.validation.constraints.*;

/**
 * 注册表单，使用 JSR-303 注解完成后端参数校验。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public class RegisterForm implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登录账号 */
    @NotBlank(message = "账号不能为空")
    @Size(min = 3, max = 20, message = "账号长度需在 3~20 位之间")
    private String username;

    /** 密码 */
    @NotBlank(message = "密码不能为空")
    @Size(min = 6, max = 20, message = "密码长度需在 6~20 位之间")
    private String password;

    /** 确认密码 */
    @NotBlank(message = "请再次输入密码")
    private String confirmPassword;

    /** 昵称 */
    @NotBlank(message = "昵称不能为空")
    private String realName;

    /** 邮箱 */
    @NotBlank(message = "邮箱不能为空")
    @Email(message = "邮箱格式不正确")
    private String email;

    /** 手机号（选填） */
    private String phone;

    /** 获取登录账号 */
    public String getUsername() {
        return username;
    }

    /** 设置登录账号 */
    public void setUsername(String username) {
        this.username = username;
    }

    /** 获取密码 */
    public String getPassword() {
        return password;
    }

    /** 设置密码 */
    public void setPassword(String password) {
        this.password = password;
    }

    /** 获取确认密码 */
    public String getConfirmPassword() {
        return confirmPassword;
    }

    /** 设置确认密码 */
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    /** 获取昵称 */
    public String getRealName() {
        return realName;
    }

    /** 设置昵称 */
    public void setRealName(String realName) {
        this.realName = realName;
    }

    /** 获取邮箱 */
    public String getEmail() {
        return email;
    }

    /** 设置邮箱 */
    public void setEmail(String email) {
        this.email = email;
    }

    /** 获取手机号（选填） */
    public String getPhone() {
        return phone;
    }

    /** 设置手机号（选填） */
    public void setPhone(String phone) {
        this.phone = phone;
    }

}
