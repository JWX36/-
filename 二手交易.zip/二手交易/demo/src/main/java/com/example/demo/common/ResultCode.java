package com.example.demo.common;

/**
 * 全局业务状态码常量。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
public final class ResultCode {

    /** 成功 */
    public static final int SUCCESS = 0;

    /** 通用业务异常 */
    public static final int BUSINESS_ERROR = 4000;

    /** 参数校验失败 */
    public static final int PARAM_ERROR = 4001;

    /** 未登录或会话失效 */
    public static final int UNAUTHORIZED = 4003;

    /** 无权限访问 */
    public static final int FORBIDDEN = 4004;

    /** 系统内部错误 */
    public static final int SYSTEM_ERROR = 5000;

    private ResultCode() {
        // 工具类禁止实例化
    }
}
