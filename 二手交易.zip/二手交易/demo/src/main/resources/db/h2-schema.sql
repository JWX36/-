-- ============================================================
-- 校园二手闲置交易平台 · H2 演示库建表脚本（MODE=MySQL）
-- 与 sql/init.sql（MySQL 8.0 正式脚本）字段完全一致
-- 由 application-demo.yml 的 spring.sql.init 自动执行
-- ============================================================

DROP TABLE IF EXISTS tb_refund_apply;
DROP TABLE IF EXISTS tb_chat_message;
DROP TABLE IF EXISTS tb_chat_session;
DROP TABLE IF EXISTS tb_favorite;
DROP TABLE IF EXISTS tb_operation_log;
DROP TABLE IF EXISTS tb_notice;
DROP TABLE IF EXISTS tb_order;
DROP TABLE IF EXISTS tb_message;
DROP TABLE IF EXISTS tb_item_image;
DROP TABLE IF EXISTS tb_item;
DROP TABLE IF EXISTS tb_category;
DROP TABLE IF EXISTS tb_user;

CREATE TABLE tb_user (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    real_name VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20),
    avatar VARCHAR(255),
    role VARCHAR(20) DEFAULT 'USER',
    status INT DEFAULT 1,
    create_time DATETIME,
    update_time DATETIME
);
CREATE UNIQUE INDEX uk_user_username ON tb_user(username);
CREATE INDEX idx_user_role ON tb_user(role);

CREATE TABLE tb_category (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    sort_no INT DEFAULT 0,
    status INT DEFAULT 1,
    create_time DATETIME
);
CREATE INDEX idx_category_sort ON tb_category(sort_no);

CREATE TABLE tb_item (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    seller_id BIGINT NOT NULL,
    category_id BIGINT NOT NULL,
    title VARCHAR(120) NOT NULL,
    description VARCHAR(2000),
    price DECIMAL(10, 2) NOT NULL,
    original_price DECIMAL(10, 2),
    cover_image VARCHAR(255),
    campus_zone VARCHAR(50),
    stock INT DEFAULT 1,
    status INT DEFAULT 0,
    view_count INT DEFAULT 0,
    reject_reason VARCHAR(255),
    off_shelf_time DATETIME,
    create_time DATETIME,
    update_time DATETIME
);
CREATE INDEX idx_item_status ON tb_item(status);
CREATE INDEX idx_item_category ON tb_item(category_id);
CREATE INDEX idx_item_seller ON tb_item(seller_id);
CREATE INDEX idx_item_create_time ON tb_item(create_time);

CREATE TABLE tb_item_image (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    item_id BIGINT NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    sort_no INT DEFAULT 0
);
CREATE INDEX idx_image_item ON tb_item_image(item_id);

CREATE TABLE tb_message (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    item_id BIGINT NOT NULL,
    sender_id BIGINT NOT NULL,
    receiver_id BIGINT NOT NULL,
    parent_id BIGINT DEFAULT 0,
    content VARCHAR(500) NOT NULL,
    is_read INT DEFAULT 0,
    rating INT DEFAULT 5,
    create_time DATETIME
);
CREATE INDEX idx_message_item ON tb_message(item_id);
CREATE INDEX idx_message_receiver ON tb_message(receiver_id);

CREATE TABLE tb_order (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_no VARCHAR(40) NOT NULL,
    request_no VARCHAR(64) NOT NULL,
    buyer_id BIGINT NOT NULL,
    seller_id BIGINT NOT NULL,
    item_id BIGINT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT DEFAULT 1,
    amount DECIMAL(10, 2) NOT NULL,
    status INT DEFAULT 0,
    cancel_reason VARCHAR(255),
    pay_time DATETIME,
    finish_time DATETIME,
    create_time DATETIME,
    update_time DATETIME
);
CREATE UNIQUE INDEX uk_order_no ON tb_order(order_no);
CREATE UNIQUE INDEX uk_order_request_no ON tb_order(request_no);
CREATE INDEX idx_order_buyer ON tb_order(buyer_id);
CREATE INDEX idx_order_seller ON tb_order(seller_id);
CREATE INDEX idx_order_status ON tb_order(status);

CREATE TABLE tb_notice (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    title VARCHAR(120),
    content VARCHAR(500),
    type VARCHAR(30),
    is_read INT DEFAULT 0,
    create_time DATETIME
);
CREATE INDEX idx_notice_user ON tb_notice(user_id);

CREATE TABLE tb_operation_log (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    operation VARCHAR(120),
    request_method VARCHAR(10),
    request_uri VARCHAR(200),
    ip VARCHAR(50),
    cost_ms BIGINT,
    create_time DATETIME
);
CREATE INDEX idx_log_create_time ON tb_operation_log(create_time);

-- ---------- 商品收藏 / 想要（淘宝「收藏商品」） ----------
CREATE TABLE tb_favorite (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    item_id BIGINT NOT NULL,
    create_time DATETIME
);
CREATE UNIQUE INDEX uk_favorite_user_item ON tb_favorite(user_id, item_id);
CREATE INDEX idx_favorite_item ON tb_favorite(item_id);

-- ---------- 买卖家客服会话（一个买家 + 一个卖家 + 一件物品唯一） ----------
CREATE TABLE tb_chat_session (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    item_id BIGINT NOT NULL,
    buyer_id BIGINT NOT NULL,
    seller_id BIGINT NOT NULL,
    last_content VARCHAR(500),
    last_time DATETIME,
    buyer_unread INT DEFAULT 0,
    seller_unread INT DEFAULT 0,
    create_time DATETIME,
    update_time DATETIME
);
CREATE UNIQUE INDEX uk_chat_item_buyer ON tb_chat_session(item_id, buyer_id);
CREATE INDEX idx_chat_buyer ON tb_chat_session(buyer_id);
CREATE INDEX idx_chat_seller ON tb_chat_session(seller_id);

-- ---------- 客服私信（id 作为前端轮询增量游标） ----------
CREATE TABLE tb_chat_message (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    session_id BIGINT NOT NULL,
    sender_id BIGINT NOT NULL,
    receiver_id BIGINT NOT NULL,
    content VARCHAR(500) NOT NULL,
    msg_type VARCHAR(20) DEFAULT 'TEXT',
    order_id BIGINT DEFAULT NULL,
    is_read INT DEFAULT 0,
    create_time DATETIME
);
CREATE INDEX idx_chat_msg_session ON tb_chat_message(session_id, id);
CREATE INDEX idx_chat_msg_order ON tb_chat_message(order_id);

-- ---------- 退款 / 售后申请（二手闲置场景：仅支持有理由退款，不支持无理由） ----------
CREATE TABLE tb_refund_apply (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT NOT NULL,
    order_no VARCHAR(40) NOT NULL,
    buyer_id BIGINT NOT NULL,
    seller_id BIGINT NOT NULL,
    item_id BIGINT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    reason_type VARCHAR(30) NOT NULL,
    reason VARCHAR(500) NOT NULL,
    status INT DEFAULT 0,
    handler_type VARCHAR(20),
    handle_note VARCHAR(500),
    handler_id BIGINT,
    apply_time DATETIME,
    deadline_time DATETIME,
    handle_time DATETIME,
    create_time DATETIME,
    update_time DATETIME
);
CREATE INDEX idx_refund_order ON tb_refund_apply(order_id);
CREATE INDEX idx_refund_buyer ON tb_refund_apply(buyer_id);
CREATE INDEX idx_refund_seller ON tb_refund_apply(seller_id);
CREATE INDEX idx_refund_status ON tb_refund_apply(status, deadline_time);
