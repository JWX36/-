/* ============================================================
   校园二手闲置交易平台 · 前端交互脚本（原生 JS，无外部依赖）
   ============================================================ */
(function () {
    'use strict';

    /** 危险操作二次确认：所有带 data-confirm 的表单/链接 */
    document.addEventListener('submit', function (event) {
        var form = event.target;
        var message = form.getAttribute('data-confirm');
        if (message && !window.confirm(message)) {
            event.preventDefault();
        }
    });

    /** 同一表单内不同按钮的差异化二次确认（例如「同意退款 / 驳回申请」各自提示） */
    document.addEventListener('click', function (event) {
        var btn = event.target && event.target.closest
            ? event.target.closest('button[data-confirm]') : null;
        if (btn && !window.confirm(btn.getAttribute('data-confirm'))) {
            event.preventDefault();
        }
    });

    /** 图片上传前本地预览（多图） */
    var imageInput = document.querySelector('#imageInput');
    if (imageInput) {
        imageInput.addEventListener('change', function () {
            var box = document.querySelector('#imagePreview');
            if (!box) {
                return;
            }
            box.innerHTML = '';
            Array.prototype.slice.call(imageInput.files || []).slice(0, 8).forEach(function (file) {
                if (!file.type.startsWith('image/')) {
                    return;
                }
                var reader = new FileReader();
                reader.onload = function (e) {
                    var img = document.createElement('img');
                    img.src = e.target.result;
                    img.alt = '待上传图片预览';
                    img.style.cssText = 'width:96px;height:72px;object-fit:cover;border-radius:8px;border:1px solid #e5e7eb';
                    box.appendChild(img);
                };
                reader.readAsDataURL(file);
            });
        });
    }

    /** 详情页缩略图点击切换主图 */
    document.querySelectorAll('[data-main-image]').forEach(function (img) {
        img.addEventListener('click', function () {
            var main = document.querySelector('#mainCover');
            if (main) {
                main.src = img.getAttribute('src');
            }
        });
    });

    /** 根据当前路径高亮导航项 */
    var path = window.location.pathname;
    document.querySelectorAll('.nav-links a, .admin-side a').forEach(function (link) {
        var href = link.getAttribute('href') || '';
        if (href !== '/' && path.indexOf(href) === 0) {
            link.classList.add('active');
        }
    });

    /** 暴露给后台看板使用：统一解析 Result 包装 */
    window.parseResult = function (json) {
        if (json && json.code === 0) {
            return json.data;
        }
        throw new Error(json && json.message ? json.message : '接口返回异常');
    };
})();
