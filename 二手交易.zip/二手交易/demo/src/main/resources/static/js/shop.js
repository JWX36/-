/* ============================================================
   校园二手闲置交易平台 · 淘宝化交互脚本（原生 JS，零外部依赖）
   ① 首页 Banner 轮播 ② 商品多图轮播 ③ 数量步进 ④ 收藏/想要
   ⑤ 详情页 Tab ⑥ 客服聊天无刷新发送 + 增量轮询
   ============================================================ */
(function () {
    'use strict';

    /* ---------- 轻量提示 ---------- */
    var toastTimer = null;
    function toast(message) {
        var box = document.querySelector('[data-toast]');
        if (!box) {
            box = document.createElement('div');
            box.className = 'toast';
            box.setAttribute('data-toast', '');
            document.body.appendChild(box);
        }
        box.textContent = message;
        box.classList.add('show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { box.classList.remove('show'); }, 2000);
    }

    /* ---------- 读取后端 app.photos.carousel-interval-ms 配置的轮播间隔 ---------- */
    function intervalOf(el, fallback) {
        var value = parseInt(el.getAttribute('data-interval'), 10);
        return isNaN(value) || value < 800 ? fallback : value;
    }

    /* ---------- ⑦ 商品图片点击放大（原生灯箱，零第三方依赖） ----------
       支持：点击任意 data-zoom 图片放大、左右箭头 / 键盘 ← → 切换同组图片、
       缩略图条、ESC / 点击遮罩 / 关闭按钮退出、打开时暂停自动轮播。
       卡片封面被链接包裹时，用右上角放大镜按钮（data-zoom-src）触发，
       不会破坏「点击图片进详情页」的淘宝式交互。                            */
    (function initLightbox() {
        var overlay = null, bigImg = null, counterEl = null, thumbsEl = null;
        var group = [], current = 0, open = false;

        function build() {
            overlay = document.createElement('div');
            overlay.className = 'lightbox';
            overlay.setAttribute('data-lightbox', '');
            overlay.innerHTML =
                '<button type="button" class="lightbox-close" data-lightbox-close aria-label="关闭放大">×</button>' +
                '<button type="button" class="lightbox-nav prev" data-lightbox-prev aria-label="上一张">‹</button>' +
                '<img class="lightbox-img" alt="商品高清大图"/>' +
                '<button type="button" class="lightbox-nav next" data-lightbox-next aria-label="下一张">›</button>' +
                '<div class="lightbox-bar"><span data-lightbox-counter>1 / 1</span>' +
                '<span class="lightbox-tip">← → 切换 · ESC 关闭 · 点击空白处退出</span></div>' +
                '<div class="lightbox-thumbs" data-lightbox-thumbs></div>';
            document.body.appendChild(overlay);
            bigImg = overlay.querySelector('.lightbox-img');
            counterEl = overlay.querySelector('[data-lightbox-counter]');
            thumbsEl = overlay.querySelector('[data-lightbox-thumbs]');

            overlay.querySelector('[data-lightbox-close]').addEventListener('click', close);
            overlay.querySelector('[data-lightbox-prev]').addEventListener('click', function (e) {
                e.stopPropagation(); show(current - 1);
            });
            overlay.querySelector('[data-lightbox-next]').addEventListener('click', function (e) {
                e.stopPropagation(); show(current + 1);
            });
            overlay.addEventListener('click', function (e) {
                // 只有点击遮罩空白处才关闭，点大图 / 缩略图 / 按钮不关闭
                if (e.target === overlay) { close(); }
            });
        }

        function collect(trigger) {
            var key = trigger.getAttribute('data-zoom-group');
            if (!key) { return [trigger]; }
            var all = document.querySelectorAll('[data-zoom][data-zoom-group="' + key + '"], [data-zoom-src][data-zoom-group="' + key + '"]');
            return Array.prototype.slice.call(all);
        }

        function srcOf(el) {
            return el.getAttribute('data-zoom-src') || el.getAttribute('src') || '';
        }

        function show(n) {
            if (!group.length) { return; }
            current = (n + group.length) % group.length;
            bigImg.src = srcOf(group[current]);
            bigImg.alt = group[current].getAttribute('alt') || '商品高清大图';
            if (counterEl) { counterEl.textContent = (current + 1) + ' / ' + group.length; }
            if (thumbsEl) {
                thumbsEl.innerHTML = '';
                if (group.length > 1) {
                    group.forEach(function (el, i) {
                        var t = document.createElement('img');
                        t.src = srcOf(el);
                        t.alt = '第 ' + (i + 1) + ' 张';
                        t.className = i === current ? 'active' : '';
                        t.addEventListener('click', function (e) { e.stopPropagation(); show(i); });
                        thumbsEl.appendChild(t);
                    });
                }
            }
        }

        function doOpen(trigger) {
            if (!overlay) { build(); }
            group = collect(trigger);
            var index = group.indexOf(trigger);
            show(index < 0 ? 0 : index);
            overlay.classList.add('open');
            document.body.classList.add('lightbox-open');
            open = true;
            document.dispatchEvent(new CustomEvent('lightbox:open'));
        }

        function close() {
            if (!open || !overlay) { return; }
            overlay.classList.remove('open');
            document.body.classList.remove('lightbox-open');
            open = false;
            document.dispatchEvent(new CustomEvent('lightbox:close'));
        }

        // 事件委托：图片本身 / 放大镜按钮都能触发，且不会误触链接跳转
        document.addEventListener('click', function (event) {
            var target = event.target;
            var trigger = target && target.closest ? target.closest('[data-zoom], [data-zoom-src]') : null;
            if (!trigger || overlay && overlay.contains(trigger)) { return; }
            if (!srcOf(trigger)) { return; }
            event.preventDefault();
            event.stopPropagation();
            doOpen(trigger);
        });

        document.addEventListener('keydown', function (event) {
            if (open) {
                if (event.key === 'Escape') { close(); }
                else if (event.key === 'ArrowLeft') { show(current - 1); }
                else if (event.key === 'ArrowRight') { show(current + 1); }
                return;
            }
            // 放大镜按钮支持键盘 Enter / 空格触发（无障碍）
            if ((event.key === 'Enter' || event.key === ' ')
                    && event.target && event.target.matches
                    && event.target.matches('[data-zoom-src]')) {
                event.preventDefault();
                doOpen(event.target);
            }
        });
    })();

    /* ---------- ① 首页 Banner：3~5 张中国大陆校园 / 商品实拍照片自动轮播 ---------- */
    var banner = document.querySelector('[data-banner]');
    if (banner) {
        var slides = banner.querySelectorAll('.banner-slide');
        var dots = banner.querySelectorAll('.banner-dot');
        var bi = 0, btimer = null;
        var bannerPeriod = intervalOf(banner, 3600);
        function showBanner(n) {
            bi = (n + slides.length) % slides.length;
            for (var i = 0; i < slides.length; i++) {
                slides[i].classList.toggle('active', i === bi);
                if (dots[i]) { dots[i].classList.toggle('active', i === bi); }
            }
        }
        function startBanner() {
            stopBanner();
            if (slides.length > 1) {
                btimer = setInterval(function () { showBanner(bi + 1); }, bannerPeriod);
            }
        }
        function stopBanner() { if (btimer) { clearInterval(btimer); btimer = null; } }
        var bp = banner.querySelector('[data-banner-prev]');
        var bn = banner.querySelector('[data-banner-next]');
        if (bp) { bp.addEventListener('click', function () { showBanner(bi - 1); startBanner(); }); }
        if (bn) { bn.addEventListener('click', function () { showBanner(bi + 1); startBanner(); }); }
        Array.prototype.forEach.call(dots, function (dot, i) {
            dot.addEventListener('click', function () { showBanner(i); startBanner(); });
        });
        banner.addEventListener('mouseenter', stopBanner);
        banner.addEventListener('mouseleave', startBanner);
        showBanner(0);
        startBanner();
    }

    /* ---------- ② 商品详情 / 卖家图片管理页：3~5 张实拍图自动轮播 ---------- */
    document.querySelectorAll('[data-gallery]').forEach(function (gallery) {
        var pics = gallery.querySelectorAll('.gallery-stage img');
        var thumbs = gallery.querySelectorAll('[data-gallery-thumb]');
        var counter = gallery.querySelector('[data-gallery-counter]');
        var autoLabel = gallery.querySelector('[data-gallery-auto]');
        var period = intervalOf(gallery, 3200);
        var gi = 0, gtimer = null, paused = false;

        function showPic(n) {
            gi = (n + pics.length) % pics.length;
            for (var i = 0; i < pics.length; i++) {
                pics[i].classList.toggle('active', i === gi);
                if (thumbs[i]) { thumbs[i].classList.toggle('active', i === gi); }
            }
            if (counter) { counter.textContent = (gi + 1) + ' / ' + pics.length; }
        }
        function setLabel(text, isPaused) {
            if (autoLabel) {
                autoLabel.textContent = text;
                autoLabel.classList.toggle('paused', !!isPaused);
            }
        }
        function stopPic() { if (gtimer) { clearInterval(gtimer); gtimer = null; } }
        function startPic() {
            stopPic();
            if (paused || pics.length <= 1) { return; }
            gtimer = setInterval(function () { showPic(gi + 1); }, period);
            setLabel('▶ 实拍图自动轮播中', false);
        }
        function restart() { if (!paused) { startPic(); } }

        var prev = gallery.querySelector('[data-gallery-prev]');
        var next = gallery.querySelector('[data-gallery-next]');
        if (prev) { prev.addEventListener('click', function () { showPic(gi - 1); restart(); }); }
        if (next) { next.addEventListener('click', function () { showPic(gi + 1); restart(); }); }
        Array.prototype.forEach.call(thumbs, function (thumb, i) {
            thumb.addEventListener('click', function () { showPic(i); restart(); });
        });
        gallery.addEventListener('mouseenter', function () {
            stopPic();
            setLabel('⏸ 悬停暂停', true);
        });
        gallery.addEventListener('mouseleave', function () {
            if (!paused) { startPic(); } else { setLabel('⏸ 已暂停', true); }
        });
        if (autoLabel) {
            autoLabel.style.cursor = 'pointer';
            autoLabel.title = '点击暂停 / 继续自动轮播';
            autoLabel.addEventListener('click', function () {
                paused = !paused;
                if (paused) { stopPic(); setLabel('⏸ 已暂停 · 点击继续', true); }
                else { startPic(); }
            });
        }
        // 灯箱放大预览时暂停自动轮播，关闭后恢复（不覆盖用户手动暂停状态）
        document.addEventListener('lightbox:open', function () {
            stopPic();
            setLabel('⏸ 放大预览中', true);
        });
        document.addEventListener('lightbox:close', function () {
            if (!paused) { startPic(); } else { setLabel('⏸ 已暂停 · 点击继续', true); }
        });
        showPic(0);
        startPic();
    });

    /* ---------- ③ 购买数量步进 ---------- */
    var qty = document.querySelector('[data-qty]');
    if (qty) {
        var minus = document.querySelector('[data-qty-minus]');
        var plus = document.querySelector('[data-qty-plus]');
        function clamp() {
            var v = parseInt(qty.value, 10);
            if (isNaN(v) || v < 1) { v = 1; }
            var max = parseInt(qty.getAttribute('max'), 10);
            if (!isNaN(max) && v > max) { v = max; }
            qty.value = v;
        }
        if (minus) { minus.addEventListener('click', function () { qty.value = (parseInt(qty.value, 10) || 1) - 1; clamp(); }); }
        if (plus) { plus.addEventListener('click', function () { qty.value = (parseInt(qty.value, 10) || 1) + 1; clamp(); }); }
        qty.addEventListener('change', clamp);
    }

    /* ---------- ④ 收藏 / 想要（无刷新切换 + 实时人数） ---------- */
    var favBtn = document.querySelector('[data-fav]');
    if (favBtn) {
        favBtn.addEventListener('click', function () {
            var itemId = favBtn.getAttribute('data-fav');
            fetch('/api/favorites/toggle/' + itemId, { method: 'POST' })
                .then(function (r) {
                    if (r.redirected) { window.location.href = '/login'; return null; }
                    return r.json();
                })
                .then(function (json) {
                    if (!json) { return; }
                    if (json.code === 0) {
                        var on = !!json.data.favorited;
                        favBtn.classList.toggle('active', on);
                        favBtn.textContent = on ? '♥ 已收藏' : '♡ 收藏';
                        var countEl = document.querySelector('[data-fav-count]');
                        if (countEl) { countEl.textContent = json.data.count; }
                        toast(on ? '已加入我的收藏' : '已取消收藏');
                    } else {
                        toast(json.message || '操作失败');
                    }
                })
                .catch(function () { toast('操作失败，请稍后再试'); });
        });
    }

    /* ---------- ⑤ 详情页 Tab（商品详情 / 商品评价 / 咨询客服） ---------- */
    var tabButtons = document.querySelectorAll('[data-tab]');
    if (tabButtons.length) {
        function activateTab(name) {
            Array.prototype.forEach.call(tabButtons, function (btn) {
                btn.classList.toggle('active', btn.getAttribute('data-tab') === name);
            });
            document.querySelectorAll('[data-tab-panel]').forEach(function (panel) {
                panel.classList.toggle('active', panel.getAttribute('data-tab-panel') === name);
            });
        }
        Array.prototype.forEach.call(tabButtons, function (btn) {
            btn.addEventListener('click', function () { activateTab(btn.getAttribute('data-tab')); });
        });
        if (window.location.hash === '#comments' || window.location.hash === '#messages') {
            activateTab('comments');
        }
    }

    /* ---------- ⑥ 客服聊天：无刷新发送 + 3 秒增量轮询 ---------- */
    var chat = document.querySelector('[data-chat]');
    if (chat) {
        var bodyEl = chat.querySelector('[data-chat-body]');
        var form = chat.querySelector('[data-chat-form]');
        var input = chat.querySelector('[data-chat-input]');
        var submitBtn = chat.querySelector('[data-chat-submit]');
        var statusEl = chat.querySelector('[data-chat-status]');
        var emptyEl = chat.querySelector('[data-chat-empty]');
        var defaultAvatar = '/images/default-avatar.svg';
        // 会话 ID 优先取 data-chat；缺失时从表单 action（/chat/8/send）兜底解析，
        // 这样即使模板渲染异常，点击「发送消息」仍会走原生表单提交，不会出现「点了没反应」。
        var sid = chat.getAttribute('data-chat');
        if (!sid || sid === '0' || sid === 'null') {
            var m = (form.getAttribute('action') || '').match(/\/chat\/(\d+)\/send/);
            sid = m ? m[1] : '';
        }
        var after = parseInt(chat.getAttribute('data-max-id'), 10) || 0;
        var csrfNode = form.querySelector('input[name="_csrf"]');
        var csrfToken = csrfNode ? csrfNode.value : '';
        var sending = false;

        function pad(n) { return (n < 10 ? '0' : '') + n; }
        function timeText(v) {
            if (typeof v === 'string') { return v.length >= 16 ? v.substring(11, 16) : v; }
            if (Array.isArray(v) && v.length >= 5) { return pad(v[3]) + ':' + pad(v[4]); }
            return '';
        }
        function setStatus(text, isError) {
            if (statusEl) {
                statusEl.textContent = text;
                statusEl.classList.toggle('send-error', !!isError);
            }
        }
        function scrollBottom() { if (bodyEl) { bodyEl.scrollTop = bodyEl.scrollHeight; } }

        function appendMessage(msg) {
            if (!msg || !bodyEl) { return; }
            var row = document.createElement('div');
            row.className = 'bubble-row' + (msg.mine ? ' mine' : '');
            row.setAttribute('data-msg-id', msg.id || '');
            var avatar = document.createElement('img');
            avatar.src = msg.senderAvatar || defaultAvatar;
            avatar.alt = '';
            var bubble = document.createElement('div');
            var isOrder = msg.msgType === 'ORDER';
            bubble.className = 'bubble' + (isOrder ? ' order-bubble' : '');
            if (isOrder) {
                // 订单卡片：结构化展示订单摘要 + 跳转链接，正文仍用 textContent 防 XSS
                var card = document.createElement('div');
                card.className = 'bubble-order';
                var head = document.createElement('div');
                head.className = 'bo-head';
                head.textContent = '📦 订单卡片 · 已购买的宝贝';
                var cardBody = document.createElement('div');
                cardBody.className = 'bo-body';
                cardBody.textContent = msg.content;
                var foot = document.createElement('div');
                foot.className = 'bo-foot';
                var link = document.createElement('a');
                link.href = '/orders/detail/' + (msg.orderId || '');
                link.textContent = '查看订单详情 →';
                foot.appendChild(link);
                card.appendChild(head);
                card.appendChild(cardBody);
                card.appendChild(foot);
                bubble.appendChild(card);
            } else {
                var text = document.createElement('div');
                text.textContent = msg.content;          // textContent 防 XSS
                bubble.appendChild(text);
            }
            var meta = document.createElement('div');
            meta.className = 'bubble-meta';
            meta.textContent = (msg.senderName || '同学')
                + (msg.senderRole ? '（' + msg.senderRole + '）' : '')
                + ' · ' + timeText(msg.createTime);
            bubble.appendChild(meta);
            row.appendChild(avatar);
            row.appendChild(bubble);
            bodyEl.appendChild(row);
            if (emptyEl && emptyEl.parentNode) { emptyEl.parentNode.removeChild(emptyEl); }
            scrollBottom();
        }

        function doSend(content) {
            if (sending) { return; }
            sending = true;
            if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = '发送中…'; }
            setStatus('正在发送消息…');
            var headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
            if (csrfToken) { headers['X-CSRF-TOKEN'] = csrfToken; }
            fetch('/api/chat/' + sid + '/send', {
                method: 'POST',
                headers: headers,
                body: 'content=' + encodeURIComponent(content)
            })
                .then(function (r) {
                    if (r.redirected || r.status === 401 || r.status === 403) {
                        throw new Error('登录状态已失效，请重新登录后再发送');
                    }
                    return r.json();
                })
                .then(function (json) {
                    if (json && json.code === 0 && json.data) {
                        input.value = '';
                        appendMessage(json.data);
                        if (json.data.id > after) { after = json.data.id; }
                        setStatus('✓ 已发送 · 买家 / 卖家 / 管理员均可见');
                    } else {
                        setStatus((json && json.message) || '发送失败，请稍后重试', true);
                        toast((json && json.message) || '发送失败');
                    }
                })
                .catch(function (err) {
                    setStatus(err && err.message ? err.message : '发送失败，请检查网络后重试', true);
                    toast('发送失败，请检查网络或重新登录');
                })
                .then(function () {
                    sending = false;
                    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = '发送消息'; }
                    input.focus();
                });
        }

        if (form && sid) {
            form.addEventListener('submit', function (event) {
                event.preventDefault();                 // 会话 ID 有效才接管；否则走原生表单兜底
                var content = (input.value || '').trim();
                if (!content) { toast('请输入消息内容'); setStatus('消息内容不能为空', true); return; }
                doSend(content);
            });
            // Enter 发送，Shift + Enter 换行
            input.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
                    event.preventDefault();
                    var content = (input.value || '').trim();
                    if (!content) { toast('请输入消息内容'); return; }
                    doSend(content);
                }
            });
        }

        // 快捷咨询语：点击填入输入框（再按 Enter / 点击发送即可）
        document.querySelectorAll('[data-phrase]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                input.value = btn.getAttribute('data-phrase');
                input.focus();
                setStatus('已填入快捷提问，点击「发送消息」或按 Enter 发送');
            });
        });

        // 「再次附上订单」：把本会话关联订单作为卡片重发，方便围绕订单继续咨询 / 售后
        var orderBtn = document.querySelector('[data-send-order]');
        if (orderBtn && sid) {
            orderBtn.addEventListener('click', function () {
                if (orderBtn.disabled) { return; }
                var oid = orderBtn.getAttribute('data-order-id');
                orderBtn.disabled = true;
                orderBtn.textContent = '发送中…';
                fetch('/api/chat/' + sid + '/send-order/' + oid, { method: 'POST' })
                    .then(function (r) { return r.json(); })
                    .then(function (json) {
                        if (json && json.code === 0 && json.data) {
                            appendMessage(json.data);
                            if (json.data.id > after) { after = json.data.id; }
                            setStatus('✓ 订单卡片已发送，对方可点击查看订单详情');
                            toast('订单卡片已发送');
                        } else {
                            toast((json && json.message) || '订单卡片发送失败');
                        }
                    })
                    .catch(function () { toast('发送失败，请稍后重试'); })
                    .then(function () {
                        orderBtn.disabled = false;
                        orderBtn.textContent = '再次附上订单';
                    });
            });
        }

        // 增量轮询：只拉 id > after 的新消息，买卖双方与管理员都能实时看到对方回复
        if (sid) {
            setInterval(function () {
                fetch('/api/chat/' + sid + '/messages?afterId=' + after)
                    .then(function (r) { return r.json(); })
                    .then(function (json) {
                        if (json && json.code === 0 && json.data) {
                            json.data.forEach(function (msg) {
                                appendMessage(msg);
                                if (msg.id > after) { after = msg.id; }
                            });
                        }
                    })
                    .catch(function () { /* 网络抖动时静默，下一轮继续 */ });
            }, 3000);
        }
        scrollBottom();
    }
})();
