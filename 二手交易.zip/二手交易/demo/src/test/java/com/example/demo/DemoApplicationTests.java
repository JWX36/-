package com.example.demo;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.demo.dto.ItemQuery;
import com.example.demo.entity.Category;
import com.example.demo.entity.Item;
import com.example.demo.entity.User;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ItemService;
import com.example.demo.service.UserService;
import com.example.demo.service.impl.CategoryServiceImpl;
import com.example.demo.service.support.CacheService;
import com.fasterxml.jackson.core.type.TypeReference;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 集成测试：验证 Spring 容器、MyBatis-Plus 分页检索、缓存与安全规范。
 * 使用默认 demo 环境（H2 内存库），无需任何外部中间件。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
class DemoApplicationTests {

    @Autowired
    private ItemService itemService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private UserService userService;

    @Autowired
    private CacheService cacheService;

    /** 容器能正常启动，所有分层 Bean 装配成功 */
    @Test
    void contextLoads() {
        assertNotNull(itemService);
        assertNotNull(categoryService);
        assertNotNull(userService);
    }

    /** 分页 + 动态 SQL：只能查出在售物品且总数大于 0 */
    @Test
    void searchOnSaleItems() {
        ItemQuery query = new ItemQuery();
        query.setPageSize(5);
        IPage<Item> page = itemService.search(query, 1);
        assertTrue(page.getTotal() > 0, "测试数据应已初始化");
        assertFalse(page.getRecords().isEmpty());
        assertTrue(page.getRecords().stream().allMatch(item -> item.getStatus() == 1));
    }

    /** 分类列表走缓存：第一次查询后缓存中应有数据 */
    @Test
    void categoryCacheWorks() {
        List<Category> list = categoryService.listAll();
        assertFalse(list.isEmpty());
        List<Category> cached = cacheService.get(CategoryServiceImpl.CACHE_KEY,
                new TypeReference<List<Category>>() {
                });
        assertNotNull(cached);
        assertEquals(list.size(), cached.size());
    }

    /** 安全规范：数据库中的密码必须是 BCrypt 密文 */
    @Test
    void passwordIsBcrypt() {
        User admin = userService.findByUsername("admin");
        assertNotNull(admin);
        assertTrue(admin.getPassword().startsWith("$2a$"), "密码必须使用 BCrypt 加密");
        assertEquals("ADMIN", admin.getRole());
    }
}
