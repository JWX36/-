package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 客服消息与全员可见集成测试（v4）。
 * 重点回归：模板变量名不能与 Thymeleaf 内置 session 冲突，否则 data-chat / 表单 action 为空，消息发不出去。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
@AutoConfigureMockMvc
class ChatMessageTests {

    @Autowired
    private MockMvc mockMvc;

    /** 聊天页必须渲染真实会话 ID、真实商品标题与有效的兜底表单 action */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void chatRoomRendersRealSessionId() throws Exception {
        mockMvc.perform(get("/chat/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("data-chat=\"1\"")))
                .andExpect(content().string(containsString("action=\"/chat/1/send\"")))
                .andExpect(content().string(containsString("全员可见")))
                .andExpect(content().string(not(containsString("action=\"/chat//send\""))))
                .andExpect(content().string(not(containsString("关于商品：闲置物品"))));
    }

    /** REST 发送 + 增量轮询：消息能被自己与对方拉到 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void sendAndPollMessages() throws Exception {
        mockMvc.perform(post("/api/chat/1/send").param("content", "v4 全员可见测试消息"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"code\":0")))
                .andExpect(content().string(containsString("v4 全员可见测试消息")));
        mockMvc.perform(get("/api/chat/1/messages").param("afterId", "0"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("v4 全员可见测试消息")));
    }

    /** JavaScript 被禁用时的原生表单兜底发送（带 CSRF 令牌）也必须能写入消息 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void formFallbackCanSend() throws Exception {
        mockMvc.perform(post("/chat/1/send").with(csrf()).param("content", "表单兜底消息"))
                .andExpect(status().is3xxRedirection());
        mockMvc.perform(get("/api/chat/1/messages").param("afterId", "0"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("表单兜底消息")));
    }

    /** 卖家（商品发布者）可以看到评价内容与公开咨询消息 */
    @Test
    @WithMockUser(username = "seller01", roles = {"SELLER"})
    void sellerSeesCommentsAndPublicQuestions() throws Exception {
        mockMvc.perform(get("/items/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("大家都在问")))
                .andExpect(content().string(containsString("书很新，笔记清晰")))
                .andExpect(content().string(containsString("请问书里附带课堂笔记吗")));
    }

    /** 管理员：客服消息页看全站会话、可进入任意会话、后台消息监管页可渲染 */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void adminSeesEverySessionAndMessage() throws Exception {
        mockMvc.perform(get("/chat"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("全站消息监管")))
                .andExpect(content().string(containsString("全站会话")));
        mockMvc.perform(get("/chat/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("data-chat=\"2\"")))
                .andExpect(content().string(containsString("平台监管视角")))
                .andExpect(content().string(containsString("请问书里附带课堂笔记吗")));
        mockMvc.perform(get("/admin/chats"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("平台消息监管")))
                .andExpect(content().string(containsString("全站商品评价")))
                .andExpect(content().string(containsString("请问书里附带课堂笔记吗")));
        mockMvc.perform(get("/items/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("大家都在问")));
    }

    /** 管理员以平台客服身份回复任意会话，角色标记正确且买卖双方都能拉到 */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void adminCanReplyAnySession() throws Exception {
        mockMvc.perform(post("/api/chat/2/send").param("content", "平台客服介入协调"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"code\":0")))
                .andExpect(content().string(containsString("平台客服介入协调")))
                .andExpect(content().string(containsString("平台客服")));
        mockMvc.perform(get("/api/chat/2/messages").param("afterId", "0"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("平台客服介入协调")));
    }

    /** 普通用户仍不能查看他人会话，也不能进入管理员消息监管页（越权防护不被放宽破坏） */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void ownershipAndAdminGuardStillWork() throws Exception {
        mockMvc.perform(get("/api/chat/2/messages").param("afterId", "0"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("无权查看该会话")));
        mockMvc.perform(get("/admin/chats"))
                .andExpect(result -> assertTrue(result.getResponse().getStatus() != 200,
                        "普通用户不能进入后台消息监管页"));
    }

    /** 顶部导航：顶栏用户区 / 主导航链接条 / 分类条三段分区，不再使用会重叠的旧类名 */
    @Test
    void navbarIsSplitIntoSections() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("tb-topbar-inner")))
                .andExpect(content().string(containsString("nav-links")))
                .andExpect(content().string(containsString("cat-bar")))
                .andExpect(content().string(not(containsString("class=\"nav-user\""))));
    }
}
