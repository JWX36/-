package com.example.demo;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.entity.Notice;
import com.example.demo.entity.TradeOrder;
import com.example.demo.mapper.NoticeMapper;
import com.example.demo.mapper.TradeOrderMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 订单待办通知集成测试（v7）：淘宝式「待支付」红点、订单中心状态分组、站内通知。
 *
 * <p>回归重点：待支付角标必须实时统计订单状态，而不能只看站内信是否已读；
 * 用户把通知一键标记已读后，只要订单仍未支付，顶栏与订单中心就应继续提醒。</p>
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class OrderNoticeTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    @Autowired
    private NoticeMapper noticeMapper;

    /** 让 buyer01（张同学，id=4）拥有一笔待支付订单；事务结束后自动回滚 */
    @BeforeEach
    void makePendingOrder() {
        TradeOrder order = tradeOrderMapper.selectById(1L);
        order.setStatus(0);
        tradeOrderMapper.updateById(order);
    }

    /** 顶栏「我的订单」出现与客服消息同款的待支付数字红点 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void navbarShowsPendingPayBadge() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("待支付订单提醒")))
                .andExpect(content().string(containsString("class=\"badge-dot badge-dot-order\">1")))
                .andExpect(content().string(containsString("客服消息")));
    }

    /** 订单中心显示待支付提醒条与带实时数量的状态分组 Tab */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void orderCenterShowsAlertAndStatusTabs() throws Exception {
        mockMvc.perform(get("/orders"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("笔订单待支付")))
                .andExpect(content().string(containsString("去支付")))
                .andExpect(content().string(containsString("order-tabs")))
                .andExpect(content().string(containsString("待确认")))
                .andExpect(content().string(containsString("已退款")));
    }

    /** 通知中心保留待支付常驻提醒，即使站内信已被标记已读 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void noticesPageKeepsPendingAlert() throws Exception {
        mockMvc.perform(post("/notices/read").with(csrf()))
                .andExpect(status().is3xxRedirection());
        mockMvc.perform(get("/notices"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("笔订单待支付")))
                .andExpect(content().string(containsString("即使通知标记已读")))
                .andExpect(content().string(containsString("订单")));
    }

    /** 完成支付后待支付红点立刻消失，说明角标读的是订单状态而非通知已读标记 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void badgeDisappearsAfterPay() throws Exception {
        mockMvc.perform(post("/orders/pay/1").with(csrf()))
                .andExpect(status().is3xxRedirection());
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(not(containsString("badge-dot-order"))));
    }

    /** 真实下单会生成一条明确的「订单待支付」站内通知（其他通知链路仍保留） */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void createOrderWritesPendingPayNotice() throws Exception {
        mockMvc.perform(post("/orders/create").with(csrf())
                        .param("itemId", "1")
                        .param("quantity", "1")
                        .param("requestNo", "test-" + UUID.randomUUID()))
                .andExpect(status().is3xxRedirection());
        long count = noticeMapper.selectCount(new LambdaQueryWrapper<Notice>()
                .eq(Notice::getUserId, 4L)
                .eq(Notice::getTitle, "订单待支付")
                .eq(Notice::getType, "ORDER"));
        assertTrue(count > 0, "下单后应生成「订单待支付」站内通知");
    }
}
