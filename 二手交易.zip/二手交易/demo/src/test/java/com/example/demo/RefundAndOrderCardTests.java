package com.example.demo;

import com.example.demo.entity.TradeOrder;
import com.example.demo.mapper.TradeOrderMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrlPattern;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * v5 集成测试：商品图片放大灯箱、订单卡片咨询、二手闲置退款全流程与越权防护。
 * 类上加 @Transactional，测试写入的数据在方法结束后回滚，不污染其他测试与演示数据。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class RefundAndOrderCardTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TradeOrderMapper tradeOrderMapper;

    /** 灯箱脚本确实打包进静态资源，且商品 / 订单页面都给图片打了放大标记 */
    @Test
    void lightboxIsAvailableOnItemAndOrderPages() throws Exception {
        try (InputStream in = new ClassPathResource("static/js/shop.js").getInputStream()) {
            String js = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            assertTrue(js.contains("initLightbox"), "shop.js 必须包含原生灯箱实现");
            assertTrue(js.contains("data-lightbox"), "灯箱必须提供遮罩层");
            assertTrue(js.contains("lightbox:open"), "放大时应暂停自动轮播");
        }
        mockMvc.perform(get("/items/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("data-zoom-group=\"item-detail\"")))
                .andExpect(content().string(containsString("点击大图放大")));
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("zoom-badge")));
    }

    /** 订单详情页提供「带订单咨询卖家」「申请退款」与图片放大入口 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void orderDetailOffersConsultAndRefundEntries() throws Exception {
        mockMvc.perform(get("/orders/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("带订单咨询卖家")))
                .andExpect(content().string(containsString("退款 / 售后中心")))
                .andExpect(content().string(containsString("data-zoom-group=\"order-cover\"")))
                .andExpect(content().string(containsString("退款进度")));
    }

    /** 点击「带订单咨询卖家」会复用 / 创建会话并跳到聊天页，聊天里能看到订单卡片 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void consultOrderSendsOrderCardIntoChat() throws Exception {
        String redirect = mockMvc.perform(get("/orders/consult/1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/chat/*"))
                .andReturn().getResponse().getRedirectedUrl();
        assertTrue(redirect != null && redirect.matches("/chat/\\d+"), "应跳转到真实会话 ID");
        mockMvc.perform(get(redirect))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("订单卡片")))
                .andExpect(content().string(containsString("再次附上订单")))
                .andExpect(content().string(containsString("CM2026110300010001")))
                .andExpect(content().string(containsString("/orders/detail/1")));
    }

    /** REST 一键重发订单卡片：msg_type = ORDER 且带 orderId，普通文本消息仍为 TEXT */
    @Test
    @WithMockUser(username = "buyer02", roles = {"USER"})
    void resendOrderCardViaApi() throws Exception {
        mockMvc.perform(post("/api/chat/2/send-order/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"code\":0")))
                .andExpect(content().string(containsString("\"msgType\":\"ORDER\"")))
                .andExpect(content().string(containsString("\"orderId\":2")))
                .andExpect(content().string(containsString("CM2026110400010002")));
        mockMvc.perform(get("/api/chat/2/messages").param("afterId", "0"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"msgType\":\"TEXT\"")))
                .andExpect(content().string(containsString("\"msgType\":\"ORDER\"")));
    }

    /** 不相关的订单不允许发进别人的会话 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void cannotSendUnrelatedOrderIntoSession() throws Exception {
        mockMvc.perform(post("/api/chat/1/send-order/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("该订单与当前会话无关")));
    }

    /** 退款中心与申请表单：规则文案、四类理由、订单信息齐全 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void refundCenterAndApplyFormRenderRules() throws Exception {
        mockMvc.perform(get("/refunds"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("退款 / 售后中心")))
                .andExpect(content().string(containsString("不支持")))
                .andExpect(content().string(containsString("平台介入")));
        mockMvc.perform(get("/refunds/apply/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("选择退款理由")))
                .andExpect(content().string(containsString("DESC_MISMATCH")))
                .andExpect(content().string(containsString("QUALITY")))
                .andExpect(content().string(containsString("NOT_RECEIVED")))
                .andExpect(content().string(containsString("AGREED")));
    }

    /** 完整退款流程：买家申请 → 卖家同意 → 订单状态变为 5 已退款 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void fullRefundFlowMarksOrderRefunded() throws Exception {
        String redirect = mockMvc.perform(post("/refunds/apply/1").with(csrf())
                        .param("reasonType", "QUALITY")
                        .param("reason", "台灯通电后不亮，已在客服里和卖家确认过情况"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/refunds/detail/*"))
                .andReturn().getResponse().getRedirectedUrl();
        assertTrue(redirect != null, "申请成功后应跳转到退款详情");
        mockMvc.perform(get(redirect))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("等待卖家处理")))
                .andExpect(content().string(containsString("待卖家处理")));

        String applyId = redirect.substring(redirect.lastIndexOf('/') + 1);
        mockMvc.perform(post("/refunds/handle/" + applyId)
                        .with(csrf())
                        .with(user("seller02").roles("SELLER"))
                        .param("approve", "true")
                        .param("note", "确认台灯故障，同意全额退款"))
                .andExpect(status().is3xxRedirection());

        TradeOrder order = tradeOrderMapper.selectById(1L);
        assertEquals(5, order.getStatus(), "退款成功后订单状态应为 5 已退款");
        mockMvc.perform(get("/refunds/detail/" + applyId).with(user("seller02").roles("SELLER")))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("退款成功")))
                .andExpect(content().string(containsString("确认台灯故障")));
    }

    /** 卖家拒绝后买家可申请平台介入，管理员后台可裁定 */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void adminCanDecidePlatformReview() throws Exception {
        mockMvc.perform(get("/admin/refunds"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("退款仲裁")))
                .andExpect(content().string(containsString("平台介入中")));
        // 种子申请 #2 处于平台介入中，管理员裁定同意退款
        mockMvc.perform(post("/admin/refunds/decide/2").with(csrf())
                        .param("approve", "true")
                        .param("note", "平台核实确属质量问题，支持买家"))
                .andExpect(status().is3xxRedirection());
        TradeOrder order = tradeOrderMapper.selectById(3L);
        assertEquals(5, order.getStatus(), "平台裁定退款后订单状态应为 5 已退款");
    }

    /** 越权防护：非申请参与人不能查看退款详情，非订单买家不能申请退款 */
    @Test
    @WithMockUser(username = "buyer02", roles = {"USER"})
    void ownershipGuardStillWorksForRefunds() throws Exception {
        mockMvc.perform(get("/refunds/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("无权查看该退款申请")));
        mockMvc.perform(get("/refunds/apply/1"))
                .andExpect(status().is3xxRedirection());
        mockMvc.perform(get("/admin/refunds"))
                .andExpect(result -> assertTrue(result.getResponse().getStatus() != 200,
                        "普通用户不能进入后台退款仲裁页"));
    }
}
