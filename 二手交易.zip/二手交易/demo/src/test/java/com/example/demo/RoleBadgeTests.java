package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 账号字幕（顶栏角色徽章）集成测试。
 *
 * <p>回归重点：早期顶栏用 {@code ${isAdmin} ? '管理员' : (isSeller ? '卖家' : '买家')} 这种
 * 「表达式外部嵌套三元」写法，嵌套的 isSeller 被当作字面量恒为真，导致数据库里 role=USER 的
 * 普通用户「张同学」被错标成「卖家」。现改为直接按 currentUser.role 用 th:switch 渲染：
 * USER → 普通用户，SELLER → 认证卖家，ADMIN → 保持原有显示（昵称已含管理员时不重复加徽章）。</p>
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
@AutoConfigureMockMvc
class RoleBadgeTests {

    @Autowired
    private MockMvc mockMvc;

    /** 普通用户：张同学必须显示「普通用户」，绝不能出现「卖家」字幕 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void normalUserShowsNormalBadge() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("张同学")))
                .andExpect(content().string(containsString("class=\"tb-role tb-role-normal\">普通用户")))
                .andExpect(content().string(not(containsString("tb-role-seller"))))
                .andExpect(content().string(not(containsString(">卖家</span>"))));
    }

    /** 认证卖家：必须显示完整的「认证卖家」账号字幕 */
    @Test
    @WithMockUser(username = "seller02", roles = {"SELLER"})
    void sellerShowsCertifiedBadge() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("class=\"tb-role tb-role-seller\">认证卖家")))
                .andExpect(content().string(not(containsString("tb-role-normal"))));
    }

    /** 超级管理员：保持原有显示，昵称已含角色时不重复叠加徽章 */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void adminKeepsOriginalDisplay() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("超级管理员")))
                .andExpect(content().string(not(containsString("tb-role-admin"))))
                .andExpect(content().string(not(containsString("tb-role-normal"))))
                .andExpect(content().string(not(containsString("tb-role-seller"))));
    }

    /** 后台用户列表的 roleBadge 片段同样保持三种角色文案一致 */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void adminUserListShowsThreeRoleLabels() throws Exception {
        mockMvc.perform(get("/admin/users"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("普通用户")))
                .andExpect(content().string(containsString("认证卖家")))
                .andExpect(content().string(containsString("超级管理员")));
    }
}
