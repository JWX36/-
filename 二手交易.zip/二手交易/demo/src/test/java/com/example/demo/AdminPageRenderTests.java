package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 页面渲染集成测试：用模拟管理员账号逐个渲染后台 Thymeleaf 页面与 REST 接口，
 * 确保模板表达式、片段复用、统计 SQL、统一返回封装在真实容器中均无异常。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
@AutoConfigureMockMvc
class AdminPageRenderTests {

    @Autowired
    private MockMvc mockMvc;

    /** 后台 6 个页面全部能成功渲染（200），验证 Thymeleaf 表达式与片段 */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void adminPagesRender() throws Exception {
        String[] urls = {"/admin/dashboard", "/admin/users", "/admin/items",
                "/admin/categories", "/admin/orders", "/admin/logs"};
        for (String url : urls) {
            mockMvc.perform(get(url)).andExpect(status().isOk());
        }
    }

    /** 前台登录用户页面渲染 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void userPagesRender() throws Exception {
        String[] urls = {"/user/profile", "/notices", "/orders", "/orders/detail/1",
                "/cart", "/messages/mine", "/items/mine", "/items/publish", "/items/edit/1"};
        for (String url : urls) {
            mockMvc.perform(get(url)).andExpect(status().isOk());
        }
    }

    /** 统计接口：验证多表关联聚合 SQL 在 H2/MySQL 双库可用 */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void dashboardApisWork() throws Exception {
        mockMvc.perform(get("/api/admin/dashboard/summary"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("\"code\":0")));
        mockMvc.perform(get("/api/admin/dashboard/charts").param("days", "7"))
                .andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("categoryNames")));
    }

    /** 未登录访问后台应被重定向到登录页（权限拦截生效） */
    @Test
    void adminRequiresLogin() throws Exception {
        mockMvc.perform(get("/admin/dashboard")).andExpect(status().is3xxRedirection());
    }
}
