package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 淘宝化增强功能集成测试：登录门禁、轮播与推荐渲染、收藏、客服私信、越权拦截、后台回归。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
@AutoConfigureMockMvc
class ShopFeatureTests {

    @Autowired
    private MockMvc mockMvc;

    /** 未登录：首页焦点图轮播可见，但评价内容被门禁挡住 */
    @Test
    void anonymousCanBrowseButCannotReadComments() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("banner-slide")));
        mockMvc.perform(get("/items/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("登录后查看商品评价")))
                .andExpect(content().string(containsString("看了又看")))
                .andExpect(content().string(not(containsString("书很新，笔记清晰"))));
        mockMvc.perform(get("/items/comments/1"))
                .andExpect(status().is3xxRedirection());
        mockMvc.perform(get("/chat"))
                .andExpect(status().is3xxRedirection());
    }

    /** 登录后：评价内容、星级、推荐购买、收藏按钮全部可见 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void loginUnlocksCommentsAndRecommendations() throws Exception {
        mockMvc.perform(get("/items/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("书很新，笔记清晰")))
                .andExpect(content().string(containsString("rating-stars")))
                .andExpect(content().string(containsString("rec-card")))
                .andExpect(content().string(containsString("data-fav")))
                .andExpect(content().string(not(containsString("登录后查看商品评价"))));
    }

    /** 新增页面全部可渲染：客服会话列表、聊天窗口、我的收藏 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void shopPagesRender() throws Exception {
        String[] urls = {"/chat", "/chat/1", "/user/favorites", "/items/detail/2", "/items/comments/1"};
        for (String url : urls) {
            int expected = url.equals("/items/comments/1") ? 302 : 200;
            mockMvc.perform(get(url)).andExpect(status().is(expected));
        }
        mockMvc.perform(get("/chat/1"))
                .andExpect(content().string(containsString("bubble-row")));
    }

    /** 收藏切换与客服私信 REST 接口返回统一 Result，并能增量拉到新消息 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void favoriteAndChatApisWork() throws Exception {
        mockMvc.perform(post("/api/favorites/toggle/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"code\":0")))
                .andExpect(content().string(containsString("favorited")));
        mockMvc.perform(post("/api/favorites/toggle/2"))
                .andExpect(status().isOk());   // 再点一次恢复，保持数据可重复测试

        mockMvc.perform(post("/api/chat/1/send").param("content", "集成测试消息"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("集成测试消息")))
                .andExpect(content().string(containsString("\"mine\":true")));
        mockMvc.perform(get("/api/chat/1/messages").param("afterId", "0"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("集成测试消息")));
    }

    /** 越权访问他人会话：由全局异常处理器转成 Result.fail，而不是 500 */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void chatOwnershipIsProtected() throws Exception {
        mockMvc.perform(get("/api/chat/2/messages").param("afterId", "0"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("无权查看该会话")));
    }

    /** 回归：后台分类管理页的分页对象不能与导航分类变量冲突（全部后台页仍 200） */
    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void adminPagesStillRender() throws Exception {
        String[] urls = {"/admin/dashboard", "/admin/users", "/admin/items",
                "/admin/categories", "/admin/orders", "/admin/logs"};
        for (String url : urls) {
            mockMvc.perform(get(url)).andExpect(status().isOk());
        }
    }
}
