package com.example.demo;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.demo.entity.ItemImage;
import com.example.demo.mapper.ItemImageMapper;
import com.example.demo.service.ItemService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * 实拍照片与卖家图片管理集成测试：
 * 独立照片目录可访问、首页/详情页 3~5 张自动轮播、卖家查看自己商品、
 * 为已发布商品追加图片、删除图片、越权拦截。
 *
 * @author 课程大作业 · 校园二手闲置交易平台
 */
@SpringBootTest
@AutoConfigureMockMvc
class ItemPhotoTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ItemService itemService;

    @Autowired
    private ItemImageMapper itemImageMapper;

    /** /photos/** 指向工程独立素材目录（或 jar 内兜底副本），返回真实 JPG */
    @Test
    void standalonePhotosAreServable() throws Exception {
        mockMvc.perform(get("/photos/item-01-1.jpg"))
                .andExpect(status().isOk())
                .andExpect(header().string("Content-Type", containsString("image/jpeg")));
        mockMvc.perform(get("/photos/campus-1.jpg"))
                .andExpect(status().isOk());
    }

    /** 首页 5 张实拍图焦点轮播 + 详情页自动轮播渲染 */
    @Test
    void photoCarouselsRender() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("background-image:url(/photos/campus-1.jpg)")))
                .andExpect(content().string(containsString("photo-slide")));
        mockMvc.perform(get("/items/detail/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("实拍图自动轮播中")))
                .andExpect(content().string(containsString("/photos/item-01-2.jpg")));
    }

    /** 卖家能看到自己发布的商品，并打开图片管理页 */
    @Test
    @WithMockUser(username = "seller01", roles = {"SELLER"})
    void sellerCanSeeOwnItemsAndManageImages() throws Exception {
        mockMvc.perform(get("/items/mine"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("卖家中心")))
                .andExpect(content().string(containsString("管理图片")));
        mockMvc.perform(get("/items/images/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("商品图片管理")))
                .andExpect(content().string(containsString("/photos/item-01-1.jpg")))
                .andExpect(content().string(containsString("继续添加商品图片")));
        assertEquals(4, itemService.ownedImages(1L, 2L).size());
    }

    /** 普通买家不能管理他人商品的图片（水平越权拦截） */
    @Test
    @WithMockUser(username = "buyer01", roles = {"USER"})
    void cannotManageOthersImages() throws Exception {
        mockMvc.perform(get("/items/images/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("只能管理自己发布的商品图片")));
    }

    /** 为已存在的商品追加一张实拍图，再删除，轮播张数恢复 */
    @Test
    @WithMockUser(username = "seller01", roles = {"SELLER"})
    void sellerCanAppendAndDeleteImage() throws Exception {
        long before = itemService.ownedImages(1L, 2L).size();
        MockMultipartFile file = new MockMultipartFile("images", "extra.png", "image/png",
                new byte[]{(byte) 0x89, 'P', 'N', 'G', 1, 2, 3});
        mockMvc.perform(multipart("/items/images/1/add").file(file).with(csrf()))
                .andExpect(status().is3xxRedirection());

        List<ItemImage> afterAdd = itemService.ownedImages(1L, 2L);
        assertEquals(before + 1, afterAdd.size(), "追加后图片数应 +1");
        ItemImage added = afterAdd.stream()
                .filter(i -> i.getImageUrl() != null && i.getImageUrl().startsWith("/uploads/items/"))
                .findFirst().orElseThrow(() -> new AssertionError("未找到新上传的图片记录"));

        mockMvc.perform(post("/items/images/1/delete/" + added.getId()).with(csrf()))
                .andExpect(status().is3xxRedirection());
        assertEquals(before, itemService.ownedImages(1L, 2L).size(), "删除后图片数应恢复");
        assertEquals(0, itemImageMapper.selectCount(new LambdaQueryWrapper<ItemImage>()
                .eq(ItemImage::getItemId, 1L)
                .like(ItemImage::getImageUrl, "/uploads/items/")).intValue());
    }
}
