-- ============================================================
-- 校园二手闲置交易平台 · MySQL 8.0 完整初始化脚本
-- 交付物：sql/init.sql（建库 + 建表 + 索引 + 字段注释 + 测试数据 + 管理员账号）
-- 使用：mysql -uroot -p < init.sql   或在 IDEA / Navicat 中执行本文件
-- 所有初始账号密码统一为 admin123，password 列为 BCrypt 密文，禁止明文密码
-- ============================================================

CREATE DATABASE IF NOT EXISTS campus_market
    DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE campus_market;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS tb_refund_apply;
DROP TABLE IF EXISTS tb_chat_message;
DROP TABLE IF EXISTS tb_chat_session;
DROP TABLE IF EXISTS tb_favorite;
DROP TABLE IF EXISTS tb_operation_log;
DROP TABLE IF EXISTS tb_notice;
DROP TABLE IF EXISTS tb_order;
DROP TABLE IF EXISTS tb_message;
DROP TABLE IF EXISTS tb_item_image;
DROP TABLE IF EXISTS tb_item;
DROP TABLE IF EXISTS tb_category;
DROP TABLE IF EXISTS tb_user;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- 用户表：三级角色 + BCrypt 密码 ----------
CREATE TABLE tb_user (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    username VARCHAR(50) NOT NULL COMMENT '登录账号，唯一',
    password VARCHAR(100) NOT NULL COMMENT 'BCrypt 加密后的密码',
    real_name VARCHAR(50) DEFAULT NULL COMMENT '昵称 / 真实姓名',
    email VARCHAR(100) DEFAULT NULL COMMENT '邮箱，接收订单与审核通知',
    phone VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    avatar VARCHAR(255) DEFAULT NULL COMMENT '头像访问路径',
    role VARCHAR(20) DEFAULT 'USER' COMMENT '角色：USER/SELLER/ADMIN',
    status INT DEFAULT 1 COMMENT '状态：1 正常，0 禁用',
    create_time DATETIME DEFAULT NULL COMMENT '注册时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_user_username (username),
    KEY idx_user_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户信息表';

-- ---------- 分类表 ----------
CREATE TABLE tb_category (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    name VARCHAR(50) NOT NULL COMMENT '分类名称',
    sort_no INT DEFAULT 0 COMMENT '排序号，越小越靠前',
    status INT DEFAULT 1 COMMENT '状态：1 启用，0 停用',
    create_time DATETIME DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY idx_category_sort (sort_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='物品分类表';

-- ---------- 物品表 ----------
CREATE TABLE tb_item (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    seller_id BIGINT NOT NULL COMMENT '卖家用户 ID',
    category_id BIGINT NOT NULL COMMENT '分类 ID',
    title VARCHAR(120) NOT NULL COMMENT '物品标题',
    description VARCHAR(2000) DEFAULT NULL COMMENT '物品描述',
    price DECIMAL(10, 2) NOT NULL COMMENT '售价',
    original_price DECIMAL(10, 2) DEFAULT NULL COMMENT '原价',
    cover_image VARCHAR(255) DEFAULT NULL COMMENT '封面图路径',
    campus_zone VARCHAR(50) DEFAULT NULL COMMENT '交易校区 / 自提地点',
    stock INT DEFAULT 1 COMMENT '库存数量',
    status INT DEFAULT 0 COMMENT '状态：0 待审核 1 在售 2 已下架 3 已售出 4 违规下架 5 已归档',
    view_count INT DEFAULT 0 COMMENT '浏览量',
    reject_reason VARCHAR(255) DEFAULT NULL COMMENT '审核驳回原因',
    off_shelf_time DATETIME DEFAULT NULL COMMENT '下架时间，供定时清理任务使用',
    create_time DATETIME DEFAULT NULL COMMENT '发布时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    PRIMARY KEY (id),
    KEY idx_item_status (status),
    KEY idx_item_category (category_id),
    KEY idx_item_seller (seller_id),
    KEY idx_item_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='闲置物品表';

-- ---------- 物品图集表（一物多图） ----------
CREATE TABLE tb_item_image (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    item_id BIGINT NOT NULL COMMENT '物品 ID',
    image_url VARCHAR(255) NOT NULL COMMENT '图片访问路径',
    sort_no INT DEFAULT 0 COMMENT '图片排序号',
    PRIMARY KEY (id),
    KEY idx_image_item (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='物品图片表';

-- ---------- 留言表 ----------
CREATE TABLE tb_message (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    item_id BIGINT NOT NULL COMMENT '物品 ID',
    sender_id BIGINT NOT NULL COMMENT '留言人 ID',
    receiver_id BIGINT NOT NULL COMMENT '接收人 ID',
    parent_id BIGINT DEFAULT 0 COMMENT '父留言 ID，0 表示主留言',
    content VARCHAR(500) NOT NULL COMMENT '留言内容',
    is_read INT DEFAULT 0 COMMENT '是否已读：1 是，0 否',
    rating INT DEFAULT 5 COMMENT '评价星级 1~5，留言咨询默认 5',
    create_time DATETIME DEFAULT NULL COMMENT '留言时间',
    PRIMARY KEY (id),
    KEY idx_message_item (item_id),
    KEY idx_message_receiver (receiver_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='留言咨询表';

-- ---------- 订单表（含幂等请求号唯一索引） ----------
CREATE TABLE tb_order (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    order_no VARCHAR(40) NOT NULL COMMENT '订单编号',
    request_no VARCHAR(64) NOT NULL COMMENT '幂等请求号，防重复下单',
    buyer_id BIGINT NOT NULL COMMENT '买家 ID',
    seller_id BIGINT NOT NULL COMMENT '卖家 ID',
    item_id BIGINT NOT NULL COMMENT '物品 ID',
    price DECIMAL(10, 2) NOT NULL COMMENT '成交单价快照',
    quantity INT DEFAULT 1 COMMENT '购买数量',
    amount DECIMAL(10, 2) NOT NULL COMMENT '订单总金额',
    status INT DEFAULT 0 COMMENT '0 待支付 1 已支付待确认 2 已完成 3 已取消 4 超时取消',
    cancel_reason VARCHAR(255) DEFAULT NULL COMMENT '取消原因',
    pay_time DATETIME DEFAULT NULL COMMENT '支付时间',
    finish_time DATETIME DEFAULT NULL COMMENT '完成时间',
    create_time DATETIME DEFAULT NULL COMMENT '下单时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_order_no (order_no),
    UNIQUE KEY uk_order_request_no (request_no),
    KEY idx_order_buyer (buyer_id),
    KEY idx_order_seller (seller_id),
    KEY idx_order_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='交易订单表';

-- ---------- 站内通知表 ----------
CREATE TABLE tb_notice (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    user_id BIGINT NOT NULL COMMENT '接收用户 ID',
    title VARCHAR(120) DEFAULT NULL COMMENT '通知标题',
    content VARCHAR(500) DEFAULT NULL COMMENT '通知内容',
    type VARCHAR(30) DEFAULT NULL COMMENT 'ORDER/AUDIT/MESSAGE/SYSTEM',
    is_read INT DEFAULT 0 COMMENT '是否已读',
    create_time DATETIME DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY idx_notice_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='站内通知表';

-- ---------- 操作日志表（AOP 写入） ----------
CREATE TABLE tb_operation_log (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    username VARCHAR(50) DEFAULT NULL COMMENT '操作人账号',
    operation VARCHAR(120) DEFAULT NULL COMMENT '操作描述',
    request_method VARCHAR(10) DEFAULT NULL COMMENT 'HTTP 方法',
    request_uri VARCHAR(200) DEFAULT NULL COMMENT '请求地址',
    ip VARCHAR(50) DEFAULT NULL COMMENT '客户端 IP',
    cost_ms BIGINT DEFAULT NULL COMMENT '耗时（毫秒）',
    create_time DATETIME DEFAULT NULL COMMENT '操作时间',
    PRIMARY KEY (id),
    KEY idx_log_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';


-- ---------- 商品收藏 / 想要（淘宝「收藏商品」） ----------
CREATE TABLE tb_favorite (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    user_id BIGINT NOT NULL COMMENT '收藏人 ID',
    item_id BIGINT NOT NULL COMMENT '物品 ID',
    create_time DATETIME DEFAULT NULL COMMENT '收藏时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_favorite_user_item (user_id, item_id),
    KEY idx_favorite_item (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品收藏表';

-- ---------- 买卖家客服会话（一个买家 + 一个卖家 + 一件物品唯一） ----------
CREATE TABLE tb_chat_session (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    item_id BIGINT NOT NULL COMMENT '咨询的物品 ID',
    buyer_id BIGINT NOT NULL COMMENT '买家（咨询发起方）ID',
    seller_id BIGINT NOT NULL COMMENT '卖家（客服）ID',
    last_content VARCHAR(500) DEFAULT NULL COMMENT '最后一条消息，用于列表预览',
    last_time DATETIME DEFAULT NULL COMMENT '最后一条消息时间，用于排序',
    buyer_unread INT DEFAULT 0 COMMENT '买家未读消息数',
    seller_unread INT DEFAULT 0 COMMENT '卖家未读消息数',
    create_time DATETIME DEFAULT NULL COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_chat_item_buyer (item_id, buyer_id),
    KEY idx_chat_buyer (buyer_id),
    KEY idx_chat_seller (seller_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='买卖家客服会话表';

-- ---------- 客服私信（id 作为前端轮询增量游标） ----------
CREATE TABLE tb_chat_message (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键，兼作增量拉取游标',
    session_id BIGINT NOT NULL COMMENT '所属会话 ID',
    sender_id BIGINT NOT NULL COMMENT '发送人 ID',
    receiver_id BIGINT NOT NULL COMMENT '接收人 ID',
    content VARCHAR(500) NOT NULL COMMENT '消息正文（订单卡片为格式化摘要）',
    msg_type VARCHAR(20) DEFAULT 'TEXT' COMMENT '消息类型：TEXT 文本 / ORDER 订单卡片',
    order_id BIGINT DEFAULT NULL COMMENT '订单卡片关联的订单 ID（仅 ORDER 消息）',
    is_read INT DEFAULT 0 COMMENT '是否已读：1 是，0 否',
    create_time DATETIME DEFAULT NULL COMMENT '发送时间',
    PRIMARY KEY (id),
    KEY idx_chat_msg_session (session_id, id),
    KEY idx_chat_msg_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服私信表';

-- ---------- 退款 / 售后申请（二手闲置：仅支持有理由退款，不支持七天无理由） ----------
CREATE TABLE tb_refund_apply (
    id BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    order_id BIGINT NOT NULL COMMENT '订单 ID',
    order_no VARCHAR(40) NOT NULL COMMENT '订单编号快照',
    buyer_id BIGINT NOT NULL COMMENT '买家 ID',
    seller_id BIGINT NOT NULL COMMENT '卖家 ID',
    item_id BIGINT NOT NULL COMMENT '物品 ID',
    amount DECIMAL(10, 2) NOT NULL COMMENT '申请退款金额（演示环境为全额）',
    reason_type VARCHAR(30) NOT NULL COMMENT '退款理由类型：DESC_MISMATCH / QUALITY / NOT_RECEIVED / AGREED',
    reason VARCHAR(500) NOT NULL COMMENT '退款说明',
    status INT DEFAULT 0 COMMENT '0 待卖家处理 1 退款成功 2 卖家拒绝 3 平台介入中 4 平台驳回 5 买家撤销',
    handler_type VARCHAR(20) DEFAULT NULL COMMENT '处理来源：SELLER / SYSTEM / ADMIN',
    handle_note VARCHAR(500) DEFAULT NULL COMMENT '处理说明 / 裁定意见',
    handler_id BIGINT DEFAULT NULL COMMENT '处理人 ID',
    apply_time DATETIME DEFAULT NULL COMMENT '申请时间',
    deadline_time DATETIME DEFAULT NULL COMMENT '卖家处理截止时间（超时系统自动同意）',
    handle_time DATETIME DEFAULT NULL COMMENT '处理时间',
    create_time DATETIME DEFAULT NULL COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    PRIMARY KEY (id),
    KEY idx_refund_order (order_id),
    KEY idx_refund_buyer (buyer_id),
    KEY idx_refund_seller (seller_id),
    KEY idx_refund_status (status, deadline_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款售后申请表';

-- ============================================================
-- 初始化测试数据：每张表不少于 5 条
-- ============================================================

-- ============================================================
-- 校园二手闲置交易平台 · H2 演示库测试数据（每张表 >= 5 条）
-- 所有初始账号密码统一为 admin123，密码列均为 BCrypt 密文（禁止明文）
-- 角色：1 ADMIN 超级管理员 / 2、3 SELLER 认证卖家 / 4~7 USER 普通用户
-- ============================================================

INSERT INTO tb_user (id, username, password, real_name, email, phone, avatar, role, status, create_time, update_time) VALUES
(1, 'admin',    '$2a$10$8.tfRgEbHFqHDHrXiqamEekmmTRlGQ/X59yPcikhWwY8mf6t9EiGa', '超级管理员', 'admin@campus.edu.cn',   '13800000001', '/images/default-avatar.svg', 'ADMIN',  1, '2026-09-01 08:00:00', '2026-11-09 08:00:00'),
(2, 'seller01', '$2a$10$8.tfRgEbHFqHDHrXiqamEekmmTRlGQ/X59yPcikhWwY8mf6t9EiGa', '学长小李',   'seller1@campus.edu.cn', '13800000002', '/images/default-avatar.svg', 'SELLER', 1, '2026-09-03 09:20:00', '2026-11-09 09:20:00'),
(3, 'seller02', '$2a$10$8.tfRgEbHFqHDHrXiqamEekmmTRlGQ/X59yPcikhWwY8mf6t9EiGa', '学姐小王',   'seller2@campus.edu.cn', '13800000003', '/images/default-avatar.svg', 'SELLER', 1, '2026-09-05 14:10:00', '2026-11-09 14:10:00'),
(4, 'buyer01',  '$2a$10$8.tfRgEbHFqHDHrXiqamEekmmTRlGQ/X59yPcikhWwY8mf6t9EiGa', '张同学',     'buyer1@campus.edu.cn',  '13800000004', '/images/default-avatar.svg', 'USER',   1, '2026-10-01 10:00:00', '2026-11-09 10:00:00'),
(5, 'buyer02',  '$2a$10$8.tfRgEbHFqHDHrXiqamEekmmTRlGQ/X59yPcikhWwY8mf6t9EiGa', '李同学',     'buyer2@campus.edu.cn',  '13800000005', '/images/default-avatar.svg', 'USER',   1, '2026-10-08 11:30:00', '2026-11-09 11:30:00'),
(6, 'buyer03',  '$2a$10$8.tfRgEbHFqHDHrXiqamEekmmTRlGQ/X59yPcikhWwY8mf6t9EiGa', '王同学',     'buyer3@campus.edu.cn',  '13800000006', '/images/default-avatar.svg', 'USER',   1, '2026-10-20 16:45:00', '2026-11-09 16:45:00'),
(7, 'buyer04',  '$2a$10$8.tfRgEbHFqHDHrXiqamEekmmTRlGQ/X59yPcikhWwY8mf6t9EiGa', '赵同学',     'buyer4@campus.edu.cn',  '13800000007', '/images/default-avatar.svg', 'USER',   1, '2026-11-02 19:00:00', '2026-11-09 19:00:00');

INSERT INTO tb_category (id, name, sort_no, status, create_time) VALUES
(1, '教材书籍', 1, 1, '2026-09-01 08:00:00'),
(2, '数码电子', 2, 1, '2026-09-01 08:00:00'),
(3, '宿舍生活', 3, 1, '2026-09-01 08:00:00'),
(4, '服饰鞋包', 4, 1, '2026-09-01 08:00:00'),
(5, '运动健身', 5, 1, '2026-09-01 08:00:00'),
(6, '其他闲置', 6, 1, '2026-09-01 08:00:00');

INSERT INTO tb_item (id, seller_id, category_id, title, description, price, original_price, cover_image, campus_zone, stock, status, view_count, reject_reason, off_shelf_time, create_time, update_time) VALUES
(1, 2, 1, '高等数学（第七版）上册 九成新', '考研复习用完，扉页有少量笔记，其余页面干净，适合大一新生。可当面验货。', 25.00, 59.00, '/photos/item-01-1.jpg', '东校区图书馆', 1, 1, 128, NULL, NULL, '2026-10-12 09:00:00', '2026-11-09 09:00:00'),
(2, 2, 2, 'iPad Air 4 64G 深空灰 带保护壳', '自用两年，电池循环不到 100 次，无磕碰无维修，附原装充电线与保护壳。', 1650.00, 3899.00, '/photos/item-02-1.jpg', '东校区宿舍区', 1, 1, 342, NULL, NULL, '2026-10-15 10:20:00', '2026-11-09 10:20:00'),
(3, 3, 3, '宿舍小台灯 护眼 USB 充电', '三档色温，充一次能用一周，毕业转让，宿舍断电神器。', 29.00, 79.00, '/photos/item-03-1.jpg', '西校区 3 栋', 2, 1, 86, NULL, NULL, '2026-10-22 15:30:00', '2026-11-09 15:30:00'),
(4, 3, 4, '优衣库羽绒服 M 码 仅穿两次', '浅灰色，M 码，去年冬天买大了一号，几乎全新，已清洗。', 199.00, 599.00, '/photos/item-04-1.jpg', '西校区食堂', 1, 1, 71, NULL, NULL, '2026-10-25 12:00:00', '2026-11-09 12:00:00'),
(5, 2, 5, '瑜伽垫 + 弹力带套装', 'TPE 材质无异味，附三条不同阻力弹力带，宿舍健身够用。', 45.00, 129.00, '/photos/item-05-1.jpg', '体育馆门口', 3, 1, 64, NULL, NULL, '2026-10-28 17:40:00', '2026-11-09 17:40:00'),
(6, 3, 2, '罗技 MX Master 2S 无线鼠标', '支持多设备切换，手感很好，因换笔记本出掉，功能全部正常。', 168.00, 499.00, '/photos/item-06-1.jpg', '图书馆一楼', 1, 1, 205, NULL, NULL, '2026-11-01 08:30:00', '2026-11-09 08:30:00'),
(7, 2, 1, '考研英语真题全套 2025 版', '近二十年真题 + 解析，附赠错题本，仅做过三套。', 38.00, 108.00, '/photos/item-07-1.jpg', '东校区自习室', 2, 1, 153, NULL, NULL, '2026-11-02 13:15:00', '2026-11-09 13:15:00'),
(8, 3, 3, '迷你电煮锅 1.5L 宿舍可用', '功率 600W，煮面煮粥都行，带蒸格，附收纳袋。', 55.00, 139.00, '/photos/item-08-1.jpg', '西校区 5 栋', 2, 1, 97, NULL, NULL, '2026-11-03 19:20:00', '2026-11-09 19:20:00'),
(9, 2, 6, '毕业清宿 桌面收纳盒套装', '三个收纳盒 + 一个笔筒，颜色随机，适合宿舍桌面整理。', 15.00, 49.00, '/photos/item-09-1.jpg', '东校区 8 栋', 4, 0, 0, NULL, NULL, '2026-11-06 10:00:00', '2026-11-09 10:00:00'),
(10, 3, 4, 'Nike 跑鞋 42 码 八成新', '跑过两次校园马拉松，鞋底磨损轻微，已清洗晾干。', 120.00, 699.00, '/photos/item-10-1.jpg', '操场看台', 1, 0, 0, NULL, NULL, '2026-11-07 09:40:00', '2026-11-09 09:40:00'),
(11, 2, 5, '哑铃一对 5kg 可调节', '可拆片调节重量，搬家不便转让，仅支持自提。', 88.00, 259.00, '/photos/item-11-1.jpg', '体育馆', 1, 2, 33, NULL, '2026-01-15 10:00:00', '2026-09-20 10:00:00', '2026-11-09 10:00:00'),
(12, 3, 6, '自制手绘帆布包', '手绘图案，容量大，可装电脑，因图片含联系方式被下架。', 22.00, 68.00, '/photos/item-12-1.jpg', '文创小店', 1, 4, 12, '图片包含联系方式，违反平台规范', '2026-02-01 09:00:00', '2026-09-25 09:00:00', '2026-11-09 09:00:00');

-- 每件商品 4 张中国大陆校园实拍照片（3~5 张自动轮播）
-- 照片是工程 assets/photos/ 下的独立 JPG 文件，不是框架内嵌资源 / 外链图床
INSERT INTO tb_item_image (id, item_id, image_url, sort_no) VALUES
(1, 1, '/photos/item-01-1.jpg', 0),
(2, 1, '/photos/item-01-2.jpg', 1),
(3, 1, '/photos/item-01-3.jpg', 2),
(4, 1, '/photos/item-01-4.jpg', 3),
(5, 2, '/photos/item-02-1.jpg', 0),
(6, 2, '/photos/item-02-2.jpg', 1),
(7, 2, '/photos/item-02-3.jpg', 2),
(8, 2, '/photos/item-02-4.jpg', 3),
(9, 3, '/photos/item-03-1.jpg', 0),
(10, 3, '/photos/item-03-2.jpg', 1),
(11, 3, '/photos/item-03-3.jpg', 2),
(12, 3, '/photos/item-03-4.jpg', 3),
(13, 4, '/photos/item-04-1.jpg', 0),
(14, 4, '/photos/item-04-2.jpg', 1),
(15, 4, '/photos/item-04-3.jpg', 2),
(16, 4, '/photos/item-04-4.jpg', 3),
(17, 5, '/photos/item-05-1.jpg', 0),
(18, 5, '/photos/item-05-2.jpg', 1),
(19, 5, '/photos/item-05-3.jpg', 2),
(20, 5, '/photos/item-05-4.jpg', 3),
(21, 6, '/photos/item-06-1.jpg', 0),
(22, 6, '/photos/item-06-2.jpg', 1),
(23, 6, '/photos/item-06-3.jpg', 2),
(24, 6, '/photos/item-06-4.jpg', 3),
(25, 7, '/photos/item-07-1.jpg', 0),
(26, 7, '/photos/item-07-2.jpg', 1),
(27, 7, '/photos/item-07-3.jpg', 2),
(28, 7, '/photos/item-07-4.jpg', 3),
(29, 8, '/photos/item-08-1.jpg', 0),
(30, 8, '/photos/item-08-2.jpg', 1),
(31, 8, '/photos/item-08-3.jpg', 2),
(32, 8, '/photos/item-08-4.jpg', 3),
(33, 9, '/photos/item-09-1.jpg', 0),
(34, 9, '/photos/item-09-2.jpg', 1),
(35, 9, '/photos/item-09-3.jpg', 2),
(36, 9, '/photos/item-09-4.jpg', 3),
(37, 10, '/photos/item-10-1.jpg', 0),
(38, 10, '/photos/item-10-2.jpg', 1),
(39, 10, '/photos/item-10-3.jpg', 2),
(40, 10, '/photos/item-10-4.jpg', 3),
(41, 11, '/photos/item-11-1.jpg', 0),
(42, 11, '/photos/item-11-2.jpg', 1),
(43, 11, '/photos/item-11-3.jpg', 2),
(44, 11, '/photos/item-11-4.jpg', 3),
(45, 12, '/photos/item-12-1.jpg', 0),
(46, 12, '/photos/item-12-2.jpg', 1),
(47, 12, '/photos/item-12-3.jpg', 2),
(48, 12, '/photos/item-12-4.jpg', 3);

-- 商品评价 / 留言咨询：rating 为 1~5 星评价，主留言与回复用 parent_id 关联
INSERT INTO tb_message (id, item_id, sender_id, receiver_id, parent_id, content, is_read, rating, create_time) VALUES
(1, 1, 4, 2, 0, '书很新，笔记清晰，卖家还送了书签，面交很顺利！', 1, 5, '2026-11-03 10:05:00'),
(2, 1, 2, 4, 1, '谢谢好评，祝考研顺利～', 1, 5, '2026-11-03 10:20:00'),
(3, 2, 5, 2, 0, 'iPad 成色和描述一致，电池健康度 96%，很满意', 1, 5, '2026-11-04 14:12:00'),
(4, 2, 2, 5, 3, '感谢信任，有问题随时找我～', 1, 5, '2026-11-04 14:35:00'),
(5, 3, 6, 3, 0, '台灯三档色温都好用，就是 USB 线略短一点', 1, 4, '2026-11-05 20:10:00'),
(6, 6, 4, 3, 0, '鼠标手感很好，接收器也在，当面交易很方便', 0, 5, '2026-11-06 08:50:00'),
(7, 4, 7, 3, 0, '羽绒服很干净，尺码标准，性价比高', 0, 5, '2026-11-07 16:30:00'),
(8, 1, 5, 2, 0, '请问书里附带课堂笔记吗？', 0, 5, '2026-11-08 11:00:00'),
(9, 2, 6, 2, 0, '电池健康度怎么样？能发一下实拍图吗？', 1, 4, '2026-11-08 15:20:00'),
(10, 5, 7, 2, 0, '瑜伽垫没有异味，弹力带三条都齐，好评', 1, 5, '2026-11-08 18:40:00'),
(11, 8, 4, 3, 0, '电煮锅功率宿舍能用，煮面很快', 1, 4, '2026-11-09 09:10:00'),
(12, 3, 5, 3, 0, '支持今晚自提吗？', 0, 5, '2026-11-09 10:30:00');

INSERT INTO tb_order (id, order_no, request_no, buyer_id, seller_id, item_id, price, quantity, amount, status, cancel_reason, pay_time, finish_time, create_time, update_time) VALUES
(1, 'CM2026110300010001', 'seed-req-0001', 4, 3, 3, 29.00, 1, 29.00, 2, NULL, '2026-11-03 11:00:00', '2026-11-03 18:00:00', '2026-11-03 10:50:00', '2026-11-03 18:00:00'),
(2, 'CM2026110400010002', 'seed-req-0002', 5, 2, 1, 25.00, 1, 25.00, 2, NULL, '2026-11-04 09:30:00', '2026-11-04 20:10:00', '2026-11-04 09:20:00', '2026-11-04 20:10:00'),
(3, 'CM2026110500010003', 'seed-req-0003', 6, 3, 4, 199.00, 1, 199.00, 2, NULL, '2026-11-05 13:00:00', '2026-11-05 21:00:00', '2026-11-05 12:40:00', '2026-11-05 21:00:00'),
(4, 'CM2026110600010004', 'seed-req-0004', 7, 2, 5, 45.00, 1, 45.00, 2, NULL, '2026-11-06 18:20:00', '2026-11-07 09:00:00', '2026-11-06 18:10:00', '2026-11-07 09:00:00'),
(5, 'CM2026110700010005', 'seed-req-0005', 4, 3, 6, 168.00, 1, 168.00, 1, NULL, '2026-11-07 10:00:00', NULL, '2026-11-07 09:50:00', '2026-11-07 10:00:00'),
(6, 'CM2026110800010006', 'seed-req-0006', 5, 3, 8, 55.00, 1, 55.00, 0, NULL, NULL, NULL, '2026-11-08 21:15:00', '2026-11-08 21:15:00'),
(7, 'CM2026110900010007', 'seed-req-0007', 6, 2, 7, 38.00, 1, 38.00, 3, '用户主动取消', NULL, NULL, '2026-11-09 08:30:00', '2026-11-09 09:00:00'),
(8, 'CM2026110900020008', 'seed-req-0008', 7, 2, 2, 1650.00, 1, 1650.00, 4, '超过 30 分钟未支付，系统自动取消', NULL, NULL, '2026-11-09 07:00:00', '2026-11-09 07:40:00');

INSERT INTO tb_notice (id, user_id, title, content, type, is_read, create_time) VALUES
(1, 2, '有新订单待处理', '您的物品《高等数学（第七版）上册 九成新》已被下单。', 'ORDER', 1, '2026-11-04 09:20:00'),
(2, 4, '下单成功', '订单 CM2026110300010001 已创建，请在 30 分钟内完成模拟支付。', 'ORDER', 1, '2026-11-03 10:50:00'),
(3, 3, '物品审核结果', '您发布的《宿舍小台灯 护眼 USB 充电》审核通过，已上架展示。', 'AUDIT', 1, '2026-10-22 15:40:00'),
(4, 3, '物品审核结果', '您发布的《自制手绘帆布包》审核未通过：图片包含联系方式。', 'AUDIT', 0, '2026-09-25 09:10:00'),
(5, 2, '收到新留言', '李同学 在《iPad Air 4 64G 深空灰 带保护壳》下留言：电池健康度怎么样？', 'MESSAGE', 0, '2026-11-04 14:12:00'),
(6, 1, '平台日交易数据统计', '系统每日凌晨自动生成交易数据统计，请前往数据看板查看。', 'SYSTEM', 0, '2026-11-09 03:00:00');

INSERT INTO tb_operation_log (id, username, operation, request_method, request_uri, ip, cost_ms, create_time) VALUES
(1, 'admin',  'AdminController.dashboard', 'POST', '/admin/items/audit/9', '127.0.0.1', 26, '2026-11-06 10:10:00'),
(2, 'admin',  'AdminController.changeRole', 'POST', '/admin/users/role/4', '127.0.0.1', 18, '2026-11-06 10:15:00'),
(3, 'seller01', 'ItemController.save', 'POST', '/items/save', '127.0.0.1', 54, '2026-11-06 10:20:00'),
(4, 'buyer01', 'TradeOrderController.create', 'POST', '/orders/create', '127.0.0.1', 41, '2026-11-07 09:50:00'),
(5, 'buyer02', 'MessageController.save', 'POST', '/messages/save', '127.0.0.1', 22, '2026-11-08 11:00:00'),
(6, 'admin',  'AdminController.deleteCategory', 'POST', '/admin/categories/delete/6', '127.0.0.1', 15, '2026-11-09 08:05:00');

-- ---------- 商品收藏 / 想要（详情页心形按钮实时切换） ----------
INSERT INTO tb_favorite (id, user_id, item_id, create_time) VALUES
(1, 4, 2, '2026-11-05 09:10:00'),
(2, 4, 1, '2026-11-05 09:12:00'),
(3, 5, 2, '2026-11-06 14:20:00'),
(4, 5, 6, '2026-11-06 14:25:00'),
(5, 6, 3, '2026-11-07 10:05:00'),
(6, 7, 1, '2026-11-07 18:30:00'),
(7, 4, 7, '2026-11-08 20:15:00');

-- ---------- 客服会话（买家 + 卖家 + 物品唯一，登录后可在「客服消息」查看） ----------
INSERT INTO tb_chat_session (id, item_id, buyer_id, seller_id, last_content, last_time, buyer_unread, seller_unread, create_time, update_time) VALUES
(1, 2, 4, 2, '可以的，今晚七点东校区宿舍区门口见～', '2026-11-09 15:42:00', 1, 0, '2026-11-08 10:00:00', '2026-11-09 15:42:00'),
(2, 1, 5, 2, '笔记拍照发你啦，书还在的', '2026-11-09 11:18:00', 0, 0, '2026-11-08 11:05:00', '2026-11-09 11:18:00'),
(3, 3, 6, 3, '支持今晚自提，西校区 3 栋楼下', '2026-11-09 20:30:00', 1, 0, '2026-11-09 20:10:00', '2026-11-09 20:30:00'),
(4, 6, 4, 3, '原装接收器在包装盒里，一起给你', '2026-11-09 09:05:00', 0, 1, '2026-11-08 21:40:00', '2026-11-09 09:05:00'),
(5, 4, 7, 3, '180 可以，拍下我给你留着', '2026-11-09 17:02:00', 1, 0, '2026-11-07 16:30:00', '2026-11-09 17:02:00'),
(6, 8, 5, 3, '同学你好，想问一下电煮锅还能用吗？', '2026-11-09 21:15:00', 0, 1, '2026-11-09 21:15:00', '2026-11-09 21:15:00');

-- ---------- 客服私信（id 递增，前端以 id 为游标轮询新消息） ----------
INSERT INTO tb_chat_message (id, session_id, sender_id, receiver_id, content, is_read, create_time) VALUES
(1, 1, 4, 2, '你好，iPad 还在吗？可以面交吗？', 1, '2026-11-08 10:00:00'),
(2, 1, 2, 4, '在的，电池健康度 96%，附原装充电线', 1, '2026-11-08 10:12:00'),
(3, 1, 2, 4, '可以的，今晚七点东校区宿舍区门口见～', 0, '2026-11-09 15:42:00'),
(4, 2, 5, 2, '请问书里附带课堂笔记吗？', 1, '2026-11-08 11:05:00'),
(5, 2, 2, 5, '笔记拍照发你啦，书还在的', 1, '2026-11-09 11:18:00'),
(6, 3, 6, 3, '台灯支持今晚自提吗？', 1, '2026-11-09 20:10:00'),
(7, 3, 3, 6, '支持今晚自提，西校区 3 栋楼下', 0, '2026-11-09 20:30:00'),
(8, 4, 4, 3, '鼠标有原装接收器吗？', 1, '2026-11-08 21:40:00'),
(9, 4, 3, 4, '原装接收器在包装盒里，一起给你', 0, '2026-11-09 09:05:00'),
(10, 5, 7, 3, '可以小刀吗？180 可以的话我现在下单。', 1, '2026-11-07 16:30:00'),
(11, 5, 3, 7, '180 可以，拍下我给你留着', 0, '2026-11-09 17:02:00'),
(12, 6, 5, 3, '同学你好，想问一下电煮锅还能用吗？', 0, '2026-11-09 21:15:00');

-- ---------- 退款 / 售后申请演示数据（覆盖 5 种状态，便于课堂演示全流程） ----------
-- 说明：演示数据把待处理申请的截止时间统一放宽，避免应用启动后定时任务立即自动同意；
--       真实申请由 RefundService 按 app.refund.seller-handle-hours 计算 48 小时处理时限。
INSERT INTO tb_refund_apply (id, order_id, order_no, buyer_id, seller_id, item_id, amount, reason_type, reason, status, handler_type, handle_note, handler_id, apply_time, deadline_time, handle_time, create_time, update_time) VALUES
(1, 4, 'CM2026110600010004', 7, 2, 5, 45.00, 'DESC_MISMATCH', '收到的弹力带只有两条，商品页写的是三条，已在客服会话里和卖家沟通过。', 0, NULL, NULL, NULL, '2026-11-10 20:10:00', '2026-12-31 20:10:00', NULL, '2026-11-10 20:10:00', '2026-11-10 20:10:00'),
(2, 3, 'CM2026110500010003', 6, 3, 4, 199.00, 'QUALITY', '羽绒服拉链第二次试穿就卡住，卖家认为是我使用不当，申请平台介入核实。', 3, NULL, NULL, NULL, '2026-11-10 18:30:00', '2026-12-31 18:30:00', NULL, '2026-11-10 18:30:00', '2026-11-10 20:00:00'),
(3, 2, 'CM2026110400010002', 5, 2, 1, 25.00, 'AGREED', '教材缺了几页，本已协商退款，后来卖家补了复印页，双方重新协商未达成一致。', 2, 'SELLER', '已补发缺页复印件，不接受全额退款', 2, '2026-11-10 16:00:00', '2026-12-31 16:00:00', '2026-11-10 19:00:00', '2026-11-10 16:00:00', '2026-11-10 19:00:00'),
(4, 1, 'CM2026110300010001', 4, 3, 3, 29.00, 'NOT_RECEIVED', '台灯约定周六面交但双方时间没对上，之后已重新约好当面取货，主动撤销申请。', 5, 'SELLER', '买家主动撤销退款申请', NULL, '2026-11-10 15:00:00', '2026-12-31 15:00:00', '2026-11-10 17:00:00', '2026-11-10 15:00:00', '2026-11-10 17:00:00'),
(5, 5, 'CM2026110700010005', 4, 3, 6, 168.00, 'DESC_MISMATCH', '鼠标外观与图片一致且功能正常，平台核实后认为不构成描述不符。', 4, 'ADMIN', '平台核实：商品描述与实物一致，驳回退款申请', 1, '2026-11-10 14:00:00', '2026-12-31 14:00:00', '2026-11-10 20:00:00', '2026-11-10 14:00:00', '2026-11-10 20:00:00');

-- 脚本结束：共 12 张表，测试数据覆盖用户/分类/物品/图片/评价/订单/通知/日志/收藏/客服会话/客服私信/退款申请。
