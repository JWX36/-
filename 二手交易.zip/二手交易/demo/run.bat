@echo off
cd /d "%~dp0"
set "JDK=C:\Users\Administrator\.jdks\jdk-21"
if not exist "%JDK%\bin\java.exe" set "JDK=C:\Users\Administrator\.jdks\jdk-17"
if not exist "%JDK%\bin\java.exe" set "JDK=D:\ruanjian\Idea\IntelliJ IDEA 2026.1.4\jbr"
if not exist "target\demo-0.0.1-SNAPSHOT.jar" (
  echo [ERROR] target\demo-0.0.1-SNAPSHOT.jar not found.
  echo Please run Maven package in IDEA first, or run: mvn clean package
  pause
  exit /b 1
)
echo ==========================================================
echo   Campus Second-hand Market  --  Spring Boot 2.7.18
echo   JDK: %JDK%
echo   URL: http://localhost:8080/
echo   Demo accounts: admin / seller01 / buyer01  (password: admin123)
echo   Press Ctrl+C in this window to stop the server.
echo ==========================================================
start "" http://localhost:8080/
"%JDK%\bin\java.exe" -Dfile.encoding=UTF-8 -jar target\demo-0.0.1-SNAPSHOT.jar
pause
