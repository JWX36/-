# 校园二手闲置交易平台（SpringBoot 企业级项目开发 · 期末综合大作业）

> 选题：**选题一：校园二手闲置交易平台**；目标难度：**高阶级（100 分档）**，基础 / 进阶 / 高阶三层要求全部落地。
> 对应任务书：3~4 人组、Spring Boot 2.7+、Yml 多环境、Spring MVC、Thymeleaf（禁止 Vue/React）、MyBatis-Plus、MySQL 8、Redis、Spring Security、RabbitMQ、Spring Task + JavaMailSender、Linux + Nginx、ECharts 数据看板。

---

## 一、先看这里：如何零报错跑起来

| 项目 | 要求 |
| --- | --- |
| IDE | IntelliJ IDEA 2026.1.4（截图二版本） |
| JDK | **推荐 JDK 17（LTS）**。Spring Boot 2.7.18 官方支持 8/11/17；本机实测 JDK 25 亦可运行，但不要用 JDK 27 直接编译运行 2.7 项目 |
| 构建 | Maven 3.8+（IDEA 内置即可）；`pom.xml` 已写好全部依赖 |
| 数据库 | **默认不需要安装数据库**。`demo` 环境使用 H2 内存库，启动自动建表 + 灌入测试数据 |
| 中间件 | **默认不需要 Redis / RabbitMQ / 邮箱**，三个开关默认关闭，代码仍在，改一行配置即可启用 |

### 一键启动（3 步）

1. IDEA → `File > Open` 选择本 `demo` 文件夹（或把本目录内容复制进截图三里创建的 `~\IdeaProjects\demo`）。
2. 右侧 Maven 面板点 **Reload All Maven Projects**，等待依赖下载完（第一次 1~3 分钟；下载慢可用 `docs/maven-settings.xml` 配置阿里云镜像）。
3. 打开 `src/main/java/com/example/demo/DemoApplication.java` → 右键 **Run 'DemoApplication'**。
   浏览器访问 **http://localhost:8080/**。

命令行等价方式：

```bash
cd demo
mvn -DskipTests package
java -jar target/demo-0.0.1-SNAPSHOT.jar
```

> 默认 `spring.profiles.active=demo`。数据库是内存库，重启后数据回到初始状态，适合反复答辩演示。
> 若端口被占用：`java -jar target/demo-0.0.1-SNAPSHOT.jar --server.port=8081`。

### 测试账号（密码统一 `admin123`，数据库中全部是 BCrypt 密文）

| 账号 | 角色 | 能做什么 |
| --- | --- | --- |
| `admin` | ADMIN 超级管理员 | 后台管理端 `/admin/**`、数据看板、审核、用户/分类/订单/日志管理 |
| `seller01` / `seller02` | SELLER 认证卖家 | 发布编辑物品、卖家订单、卖家专属模块 |
| `buyer01` ~ `buyer04` | USER 普通用户 | 浏览检索、留言、下单支付、购物车、个人中心 |

---

## 二、与「新建项目」截图三的对应关系

| 截图里的选项 | 本工程 |
| --- | --- |
| 生成器 Spring Boot / 服务器 URL start.spring.io | Spring Boot `2.7.18`（parent） |
| 名称 `demo`、组 `com.example`、工件 `demo`、软件包名 `com.example.demo` | `pom.xml` 的 groupId / artifactId / 主类包完全一致 |
| Java / Maven / Jar / YML | Java 17、Maven、Jar 打包、`application*.yml` |
| JDK openjdk-27 / Java 17 | 语言级别 17；**建议把 Project SDK 换成 JDK 17**，2.7.x 在 27 上可能出现反射兼容问题 |

> 如果你已经用截图三的向导生成了空工程：**直接用本工程的 `pom.xml` 覆盖空工程的 `pom.xml`，再把 `src/`、`sql/`、`deploy/`、`docs/` 复制过去即可**，无需手动逐个加依赖。

---

## 三、依赖清单（pom.xml，已全部写好，不需要额外手工添加）

版本由 `spring-boot-starter-parent:2.7.18` 统一管理，只有 MyBatis-Plus 与 MySQL 驱动显式指定版本。

| # | 依赖（groupId:artifactId） | 版本 | 作用 / 对应考点 |
| --- | --- | --- | --- |
| 1 | `org.springframework.boot:spring-boot-starter-web` | 2.7.18 | Spring MVC、内嵌 Tomcat、Jackson；参数绑定、文件上传、REST 接口（第 3 章） |
| 2 | `org.springframework.boot:spring-boot-starter-thymeleaf` | 2.7.18 | Thymeleaf 服务端渲染（**作业强制要求**，禁止 Vue/React）（第 4 章） |
| 3 | `org.thymeleaf.extras:thymeleaf-extras-springsecurity5` | 由 parent 管理 | 模板里按角色显示菜单 / 按钮 |
| 4 | `org.springframework.boot:spring-boot-starter-validation` | 2.7.18 | JSR-303 参数校验（`@NotBlank`/`@Email`/`@DecimalMin`） |
| 5 | `org.springframework.boot:spring-boot-starter-security` | 2.7.18 | 三级角色、自定义登录页、URL + 方法级双重鉴权、BCrypt（第 7 章） |
| 6 | `com.baomidou:mybatis-plus-boot-starter` | **3.5.5** | 单表 CRUD、分页插件、防全表更新、动态 SQL（第 5 章） |
| 7 | `com.mysql:mysql-connector-j` | **8.0.33** | MySQL 8 驱动（dev/test/prod 环境） |
| 8 | `com.h2database:h2` | 由 parent 管理 | 演示环境内存库，零安装运行（保证「不报错」） |
| 9 | `spring-boot-starter-data-redis` + `spring-boot-starter-cache` | 2.7.18 | 热点物品 / 分类 / 购物车 / 幂等键缓存（第 6 章） |
| 10 | `org.springframework.boot:spring-boot-starter-amqp` | 2.7.18 | RabbitMQ 异步解耦：下单、状态变更、审核、留言（第 8 章） |
| 11 | `org.springframework.boot:spring-boot-starter-mail` | 2.7.18 | JavaMailSender 邮件提醒（第 9 章） |
| 12 | `org.springframework.boot:spring-boot-starter-aop` | 2.7.18 | 操作日志切面（工程化规范） |
| 13 | `spring-boot-configuration-processor`（optional） | 2.7.18 | 自定义配置 `app.*` 的 IDE 提示 |
| 14 | `spring-boot-starter-test`（test） | 2.7.18 | JUnit 5 / MockMvc 集成测试 |
| 15 | `org.springframework.security:spring-security-test`（test） | 由 parent 管理 | `@WithMockUser` 模拟管理员渲染后台页面 |

**如果老师要求「自己添加依赖」**：在 IDEA 里打开 `pom.xml`，把上表对应 `<dependency>` 粘贴进 `<dependencies>`，然后点右上角出现的 **Load Maven Changes** 图标（或 Maven 面板 Reload）。本工程已经全部包含，**不需要你再添加任何依赖**。

---

## 四、软件包结构（严格三层架构 + config / utils / exception / aspect / task）

```
com.example.demo
├── DemoApplication.java              启动类（@SpringBootApplication @EnableScheduling @MapperScan）
├── common/                           通用返回封装
│   ├── Result.java                   REST 统一返回 {code, message, data}
│   └── ResultCode.java               业务状态码常量
├── config/                           配置层
│   ├── AppProperties.java            自定义配置绑定 app.*
│   ├── SecurityConfig.java           Spring Security 过滤链、三级角色、登录页、CSRF
│   ├── PasswordConfig.java           BCrypt PasswordEncoder
│   ├── MybatisPlusConfig.java        分页插件 + 防全表更新插件
│   ├── WebMvcConfig.java             独立素材目录 /photos/** + 上传目录 /uploads/** 多路径映射
│   ├── AsyncConfig.java              @EnableAsync（异步邮件）
│   └── RabbitConfig.java             Topic 交换机 + 4 个队列 + 绑定（MQ 开启时生效）
├── entity/                           实体层（对应 12 张表，字段均有中文注释）
│   ├── User.java / Category.java / Item.java / ItemImage.java
│   ├── Message.java / TradeOrder.java / Notice.java / OperationLog.java
├── dto/                              表单与检索对象（JSR-303 校验注解）
│   ├── PageQuery.java / ItemQuery.java / ItemForm.java / OrderForm.java
│   ├── RegisterForm.java / ProfileForm.java / PasswordForm.java
│   └── CategoryForm.java / MessageForm.java
├── mapper/                           数据访问层（MyBatis-Plus + 自定义 SQL）
│   ├── UserMapper.java / CategoryMapper.java / ItemMapper.java / ItemImageMapper.java
│   ├── MessageMapper.java / TradeOrderMapper.java / NoticeMapper.java
│   ├── OperationLogMapper.java / StatisticsMapper.java
│   └── resources/mapper/*.xml        动态 SQL、多表关联、统计聚合
│       ├── ItemMapper.xml            关键词/分类/价格区间动态条件 + 白名单排序
│       ├── MessageMapper.xml         留言人 / 物品多表关联
│       ├── TradeOrderMapper.xml      订单关联详情 + 后台动态条件分页 + 超时扫描
│       └── StatisticsMapper.xml      看板聚合（表关联 + 子查询）
├── service/                          业务接口层
│   ├── UserService.java / CategoryService.java / ItemService.java
│   ├── MessageService.java / TradeOrderService.java / DashboardService.java
│   └── impl/                         业务实现层（6 个 Impl）
│       ├── UserServiceImpl.java      注册/资料/改密/头像/后台用户管理
│       ├── CategoryServiceImpl.java Cache-Aside 缓存 + 删除保护
│       ├── ItemServiceImpl.java     检索/详情/发布/编辑/审核/热点/定时清理
│       ├── MessageServiceImpl.java  留言与回复 + 事件通知
│       ├── TradeOrderServiceImpl.java 幂等下单、防超卖、状态机、超时取消
│       └── DashboardServiceImpl.java  概览指标 + ECharts 图表数据
├── service/support/                  可插拔基础设施
│   ├── CacheService.java             缓存接口
│   ├── InMemoryCacheService.java    演示环境实现（TTL / 空值防穿透 / setIfAbsent）
│   ├── RedisCacheService.java        Redis 实现（开关开启后自动切换）
│   ├── EventPublisher.java           领域事件接口
│   ├── InMemoryEventPublisher.java  演示环境事件处理
│   ├── RabbitEventPublisher.java    RabbitMQ 真实投递（失败自动降级）
│   ├── OrderEventConsumer.java      4 个 @RabbitListener 消费者
│   ├── EventProcessor.java          事件统一业务处理
│   ├── NotificationService.java     站内信（必达）
│   ├── MailService.java             @Async 邮件（尽力而为，失败不影响业务）
│   ├── FileStorageService.java      白名单 + UUID 重命名文件上传
│   └── CustomUserDetailsService.java Spring Security 认证数据源
├── controller/                       控制层（前台 / 后台 / REST）
│   ├── GlobalModelAdvice.java        全站公共模型（分类、登录人、未读数）
│   ├── HomeController.java           首页、403
│   ├── AuthController.java           登录页 / 注册
│   ├── ItemController.java           列表 / 详情 / 发布 / 编辑 / 下架 / 我的发布
│   ├── UserController.java           个人中心 / 头像 / 站内通知
│   ├── MessageController.java        留言 / 回复 / 我的留言
│   ├── TradeOrderController.java     下单 / 支付 / 确认 / 取消 / 列表 / 详情
│   ├── CartController.java           购物车 + 浏览记录（缓存）
│   ├── admin/AdminController.java    后台 7 个模块（类级 @PreAuthorize）
│   └── api/                          REST 接口
│       ├── AdminApiController.java   /api/admin/dashboard/** → ECharts JSON
│       └── PublicApiController.java /api/public/health
├── exception/
│   ├── BusinessException.java        业务异常
│   └── GlobalExceptionHandler.java  全局异常处理（页面→错误页，REST→Result JSON）
├── aspect/OperationLogAspect.java    AOP 记录所有 POST 写操作
├── task/ScheduledTasks.java          Spring Task 三个定时任务
└── util/
    ├── UserContext.java              登录上下文 + 数据归属校验（防水平越权）
    ├── CacheJson.java                缓存/消息 JSON 序列化（JavaTimeModule）
    └── PageUrl.java                  分页链接保留筛选条件
```

> 物品 / 订单 / 角色状态的中文文案通过 `templates/fragments/layout.html` 中的 `th:switch` 片段统一复用，无需额外工具类。

前端资源：

```
resources/
├── application.yml / application-{demo,dev,test,prod}.yml   四环境 Yml 配置
├── db/h2-schema.sql / h2-data.sql                           演示库建表 + 测试数据（每表 ≥5 条）
├── mapper/*.xml                                             MyBatis SQL
├── static/css/app.css · static/js/app.js · static/images/*.svg
└── templates/                                              Thymeleaf 页面（全部服务端渲染）
    ├── fragments/layout.html    head / navbar / footer / itemCard / 状态徽章 / 分页 / 后台侧栏
    ├── index.html · items/{list,detail,form,mine}.html
    ├── auth/{login,register}.html · user/{profile,notices}.html
    ├── messages/mine.html · orders/{list,detail}.html · cart.html
    ├── admin/{dashboard,users,items,categories,orders,logs}.html
    └── error/{403,404,500}.html
```

---

## 五、关键代码在哪里（答辩讲解索引）

| 考点 | 文件 | 关键实现 |
| --- | --- | --- |
| 三层架构 | `controller → service → service/impl → mapper` | 每层职责单一，接口与实现分离 |
| 统一返回 + 全局异常 | `common/Result.java`、`exception/GlobalExceptionHandler.java` | 页面请求渲染 `error/500.html`，`/api/**` 返回 `Result` JSON |
| 参数校验 | `dto/*Form.java` + Controller 的 `@Valid BindingResult` | 注册、发布、留言、下单全部校验 |
| 动态 SQL / 多表关联 | `resources/mapper/ItemMapper.xml` | `<where><if>` 拼条件，排序字段固定白名单，全部 `#{}` 预编译防注入 |
| 分页 | `config/MybatisPlusConfig.java` + `IPage` | 物理分页插件，最大 200 条防滥用 |
| Spring Security | `config/SecurityConfig.java` | 自定义登录页、三级角色、菜单级 URL 规则 + `@PreAuthorize` 接口级校验 |
| 防越权 | `util/UserContext.java` + 各 Service | 编辑物品、查看订单前比对数据归属 |
| BCrypt | `PasswordConfig.java` + `UserServiceImpl.java` + `sql/init.sql` | 无明文密码 |
| 缓存 | `service/support/*CacheService.java`、`CategoryServiceImpl`、`ItemServiceImpl` | Cache-Aside、空值防穿透、TTL 抖动防雪崩、`setIfAbsent` 防击穿 |
| 消息队列 | `config/RabbitConfig.java`、`RabbitEventPublisher`、`OrderEventConsumer` | 4 类事件异步解耦，中间件不可用自动降级本地处理 |
| 邮件 | `MailService.java` | `@Async` + 开关 + 异常兜底，站内信始终落库 |
| 定时任务 | `task/ScheduledTasks.java` | 超时订单取消 / 每日交易统计 / 每月清理下架物品 |
| AOP 日志 | `aspect/OperationLogAspect.java` | 环绕所有 `@PostMapping`，写 `tb_operation_log` |
| 幂等下单 | `TradeOrderServiceImpl.create()` | 幂等键 `setIfAbsent` + 未完成订单互斥 + 带库存条件原子扣减 |
| 文件上传 | `FileStorageService.java` + `WebMvcConfig.java` | 扩展名白名单、UUID 重命名、目录隔离 |
| ECharts 看板 | `admin/dashboard.html` + `api/AdminApiController` | 交易金额 / 用户增长 / 分类占比 / 分类物品数 |

---

## 六、多环境配置与「中间件开关」

| Profile | 数据库 | Redis / MQ / Mail | 用途 |
| --- | --- | --- | --- |
| `demo`（默认） | H2 内存库，自动建表灌数据 | 本地实现（关闭） | 导入 IDEA 直接运行，答辩演示 |
| `dev` | MySQL 8（`MYSQL_*` 环境变量） | Redis 开、MQ 开、Mail 默认关 | 本机开发完整技术栈 |
| `test` | H2 文件库 | 本地实现 | 集成测试 |
| `prod` | MySQL 8 | Redis 开、MQ 开、Mail 按 `MAIL_ENABLED` | Linux + Nginx 生产部署 |

切换方式：`application.yml` 改 `spring.profiles.active`，或启动时 `--spring.profiles.active=dev`。

`app.feature.*` 三个开关（在 `application-*.yml` 里）：

```yaml
app:
  feature:
    redis-enabled: true   # false → 进程内缓存；true → RedisCacheService 自动生效
    mq-enabled: true      # false → 本地事件处理；true → RabbitMQ 真实异步投递
    mail-enabled: true    # 需要同时配置 MAIL_USER / MAIL_PWD（邮箱授权码）
```

> 这是本工程「既覆盖全部高阶考点、又保证零报错启动」的关键：上层业务只依赖 `CacheService` / `EventPublisher` 接口，中间件是否安装都不影响启动。

---

## 七、功能与任务书对照

**基础级（第 1~5 章）**：注册 / 登录 / 资料修改 / 改密 / 头像上传；物品发布（分类、标题、描述、价格、多图）/ 编辑 / 下架；首页分类展示、关键词搜索、价格区间、分页、详情；留言与发布者回复；后台用户 / 审核 / 分类 / 违规下架；全部页面 Thymeleaf 渲染 + 片段复用。

**进阶级（第 6、7、9 章）**：Spring Security 角色权限与自定义登录页；Redis 缓存热点物品与分类、更新同步失效；物品审核结果 / 留言 / 下单邮件通知；每月 1 号清理过期下架物品、每日凌晨交易统计；全局异常、统一返回、JSR-303。

**高阶级（第 8、10 章）**：订单全流程（下单 → 模拟支付 → 确认 → 完成 / 取消 / 超时取消）+ 幂等防重复下单；USER / SELLER / ADMIN 三级角色 + URL 与接口双重校验 + 数据归属防越权；RabbitMQ 四大场景；多级缓存（购物车、浏览记录、热点、分类、幂等键）；Linux + Nginx 部署脚本与日志按天切割；ECharts 数据看板（交易金额、用户增长、分类占比）。

---

## 八、数据库脚本

| 文件 | 用途 |
| --- | --- |
| `sql/init.sql` | **交付物**：MySQL 8 完整脚本，建库 + 12 张表（主键、索引、字段 COMMENT）+ 每表 ≥5 条测试数据 + 管理员账号（BCrypt） |
| `src/main/resources/db/h2-schema.sql` | demo / test 环境自动执行的建表脚本 |
| `src/main/resources/db/h2-data.sql` | demo / test 环境自动执行的测试数据 |

MySQL 用法：`mysql -uroot -p < sql/init.sql`，然后 `--spring.profiles.active=dev` 启动。

---

## 九、交付物清单（作业 3.2 节）

| 交付物 | 位置 |
| --- | --- |
| 完整 Maven 项目源码 | 本 `demo/` 目录（可直接导入 IDEA，已编译、已启动验证） |
| 集成测试 | `src/test/java/.../DemoApplicationTests.java`、`AdminPageRenderTests.java`、`ShopFeatureTests.java`、`ItemPhotoTests.java`、`ChatMessageTests.java`、`RefundAndOrderCardTests.java`、`RoleBadgeTests.java`、`OrderNoticeTests.java`（45 个用例全通过） |
| 数据库脚本 | `sql/init.sql` |
| 项目开发文档 | `docs/开发文档.md`（需求分析、系统设计、数据库设计 E-R、部署说明、组员分工） |
| Linux 部署说明（高阶必交） | `docs/部署文档.md` + `deploy/nginx.conf` + `deploy/start.sh` + `deploy/docker-compose.yml` |
| 答辩 PPT 大纲 | `docs/答辩PPT大纲.md`（5~8 页结构，按要求含背景、技术栈、架构、分工、演示、总结） |
| Maven 镜像配置（可选） | `docs/maven-settings.xml` |

---

## 十、常见问题（都不会导致「跑不起来」）

1. **依赖下载慢**：把 `docs/maven-settings.xml` 复制为 `C:\Users\你的用户名\.m2\settings.xml`，或构建时加 `-s docs/maven-settings.xml`。
2. **JDK 版本**：截图里选到了 JDK 27；建议在 `File > Project Structure > SDKs` 添加 JDK 17，并把 Project SDK / Language Level 都设为 17。
3. **端口被占用**：`--server.port=8081`；若本机存在 `SERVER_PORT` 之类的环境变量，命令行参数优先级更高。
4. **没装 Redis / RabbitMQ**：默认开关关闭，完全不影响启动；要演示真实中间件，先起 `deploy/docker-compose.yml`，再打开对应开关。
5. **中文乱码**：所有源码、SQL、页面均 UTF-8，`pom.xml` 已设置 `project.build.sourceEncoding=UTF-8`。
6. **图片上传 404**：`uploads/` 目录由 `WebMvcConfig` 自动创建并映射为 `/uploads/**`。
7. **ECharts 空白**：图表库走 CDN，离线时页面会给出提示；服务端概览指标仍由 Thymeleaf 正常渲染，联网刷新即可显示图表。

---

## 十一、本机验证记录（交付前实测 · 2026-11-10 更新）

- `mvn clean test` → **Tests run: 45, Failures: 0, Errors: 0, BUILD SUCCESS**（原有 14 + 实拍照片 5 + 客服消息与全员可见 8 + v5 图片放大 / 订单卡片 / 退款 9 + 账号字幕 4 + 订单待办通知 5）。
- `mvn clean package` → **BUILD SUCCESS**，97 个主源码文件（Java 17 字节码，JDK 21 运行），49 MB 可执行 jar（内嵌 52 张实拍照片兜底副本）。
- H2 演示库自动建 **12 张表** 并灌入每表 ≥5 条测试数据；`tb_item_image` 共 48 条（12 件商品 × 4 张实拍图）。
- HTTP 抽查：首页 / 列表 / 详情 / 登录 / 注册 / 静态资源 / `api/public/health` / 6 个后台页 / 2 个统计接口 / 客服列表 / 我的收藏 → 全部 **200**；未登录访问评价门禁、客服、收藏与相关 API → **302**。
- 业务链路：登录后自动跳回原商品评价区；收藏双向切换；客服发送 + 增量轮询；越权返回 `{"code":4000,...}`。

---

## 十二、淘宝化增强（v2，本次优化）

> 完整说明见 **`docs/淘宝化功能说明.md`**（需求对照、新增软件包与逐文件代码索引、接口清单、实测数据、答辩讲解点）。

| 能力 | 入口 |
|---|---|
| 首页 Banner 轮播 + 商品详情多图轮播 | `/`、`/items/detail/{id}` |
| 详情页「看了又看 · 推荐购买」（同分类 + 价格相近 + 热度，缓存 120 秒） | 详情页底部 |
| 商品评价**必须登录**（服务端不下发评价正文，登录后自动跳回原页） | 详情页「商品评价」Tab |
| 买卖家客服私信（会话列表 / 气泡 / 未读红点 / 3 秒轮询 / 越权拦截） | 导航栏「客服消息」、详情页「联系卖家」 |
| 一键发送商品咨询（3 条快捷咨询语作为首条消息） | 详情页「咨询客服」Tab |
| 收藏 / 想要人数、我的收藏、五星评分、商品参数表 | 详情页心形按钮、`/user/favorites` |
| 淘宝橙主题、顶栏 + 搜索 + 分类条、数量步进器、服务保障 | 全站 |

- **依赖零新增**：`pom.xml` 的依赖清单未改动（仍是 15 项），v3 仅新增 `<resources>` 构建期复制照片的配置；前端纯原生 CSS/JS，无 npm、无新增 CDN。
- **新增 14 个 Java 类 + 3 个 Mapper XML + 4 个页面 + 1 个 JS + 6 个集成测试**；数据库新增 3 张表（`tb_favorite` / `tb_chat_session` / `tb_chat_message`）与 `tb_message.rating` 字段，两份 SQL 脚本已同步。
- **关键修复**：公共导航分类变量改名 `navCategories`，避免与 `/admin/categories` 的分页对象 `categories` 冲突（已加回归测试）。
- 体验路线：启动 → 首页看轮播 → 点商品看多图轮播与推荐 → 不登录点「商品评价」验证门禁 → 用 `buyer01 / admin123` 登录自动跳回 → 点「联系卖家」发消息 → 换个浏览器用 `seller01 / admin123` 登录查看未读并回复。


---

## 十三、实拍照片与卖家图片管理（v3，本次优化）

> 完整说明见 `docs/淘宝化功能说明.md` 第十节。

| 能力 | 说明 |
|---|---|
| 中国大陆实拍照片 | `assets/photos/` 下 52 张独立 JPG（12 件商品各 4 张 + 4 张校园场景），中国高校宿舍、自习室、操场、二手书摊等场景，**不写进框架源码、不内嵌 base64、不引用任何外链图床** |
| 换电脑 / 换目录也不会丢图 | `WebMvcConfig` 把 `/photos/**` 映射到多个候选目录；`pom.xml` 构建时把同一批照片复制进 `classpath:/static/photos/`，**只带 jar 运行也能显示照片** |
| 3~5 张自动轮播 | 首页 5 张焦点图 + 每件商品 4 张实拍图，间隔由 `app.photos.carousel-interval-ms`（默认 3200ms）统一配置，悬停暂停、点击暂停、缩略图 / 箭头手动切换 |
| 卖家查看自己的商品 | 导航「我的发布 · 卖家中心」→ `/items/mine`，展示全部状态商品、每件实拍图张数与「管理图片」入口 |
| 卖家自主为已存在商品追加图片 | `/items/images/{id}` 图片管理页，多选上传 → `/items/images/{id}/add`，不重新发布、不重新审核、即刻进入轮播；上限 5 张，可删除、可设为封面 |
| 权限与一致性 | 所有操作校验 `seller_id == 当前用户`（管理员除外），至少保留 1 张图，删除 / 设封面用 `@Transactional` 同步 `tb_item.cover_image` 与 `tb_item_image.sort_no` |

- 新增测试类 `ItemPhotoTests.java`（5 个用例）；v4 又新增 `ChatMessageTests.java`（8 个用例），全项目 **45 个集成测试全通过**。
- 实测：从**另一个工作目录**直接 `java -jar` 启动，`/photos/item-01-1.jpg` 返回 `200 image/jpeg`；卖家登录后追加图片 → 轮播变 5 张 → 删除 → 恢复 4 张 → 设封面 / 还原 → 越权访问被拦截，全部通过。
- 照片文件与卖家上传文件都属于工程目录，**拷贝 / 压缩整个项目文件夹即可完整带走**；不要只拷 `src/` 或 `target/`。


---

## 十四、客服消息发送修复与全员可见（v4，本次优化）

> 完整说明见 `docs/淘宝化功能说明.md` 第十一节。

### 14.1 修复「咨询客服发不了消息」（重要 Bug）

| 现象 | 根因 | 修复 |
|---|---|---|
| 点「发送消息」没反应；页面显示「同学 / 关于商品：闲置物品」；表单地址是 `/chat//send` | 模板用 `${session.id}`，但 `session` 是 **Thymeleaf 内置隐式对象**（HttpSession 属性 Map），遮蔽了 Controller 传入的 `ChatSession`，导致 `data-chat`、表单 action、对方昵称、商品标题全部取到空值，JS 把消息 POST 到 `/api/chat/null/send` | Controller 模型属性改名 `chatSession`，模板全部改为 `${chatSession.*}`；`data-chat` 与 `data-max-id` 由 `th:attr` 渲染真实会话 ID；表单 action 恢复为 `/chat/{id}/send` |

同时加固了 `static/js/shop.js` 的聊天逻辑：

- 会话 ID 优先取 `data-chat`，缺失时从表单 action 兜底解析；ID 无效时**不拦截表单提交**，走原生 POST 兜底，绝不会出现「点了没反应」。
- 支持 **Enter 发送 / Shift+Enter 换行**、发送中按钮禁用、成功 / 失败状态提示、登录失效提示、快捷提问一键填入。
- 消息用 `textContent` 渲染防 XSS；轮询以消息 id 为增量游标并自动滚到底部；空会话显示引导空态。

### 14.2 评论 / 咨询消息全员可见（买家 · 卖家 · 管理员）

| 角色 | 可见范围 | 入口 |
|---|---|---|
| 买家 | 自己参与的客服会话、商品评价与该商品「大家都在问」公开咨询 | `/chat`、`/items/detail/{id}` |
| 卖家 | 买家发来的会话与消息、自己商品的评价与全部咨询 | `/chat`、`/items/detail/{id}` |
| 管理员 | **全站会话、全部客服消息、全部商品评价**，并可直接进入任意会话以「平台客服」身份回复 | `/chat`（全站会话）、`/admin/chats`（消息监管） |

- 新增商品详情页 Tab **「大家都在问」**：汇总该商品所有客服会话消息，标注发送人身份（买家 / 卖家 / 平台客服），买家 / 卖家 / 管理员登录后均可见；评价区标注「全部成员可见」。
- 新增后台页 `/admin/chats`「💬 消息监管」：全站会话（含买卖双方、消息条数、最后消息）、最近 30 条客服消息、最近 30 条商品评价。
- `ChatService` 新增 `listAll / publicMessagesByItem / recentMessages`；`ChatSessionMapper.selectAll`、`ChatMessageMapper.selectPublicByItem / selectRecent`、`MessageMapper.selectRecentComments` 均为多表关联 SQL。
- 权限边界不放松：普通用户改 ID 访问他人会话仍返回「无权查看该会话」，也不能进入 `/admin/chats`。

### 14.3 顶部导航重排（解决拥挤、重叠、点不了）

- 旧版 `.navbar-inner` 固定 `height:68px` + 链接 `flex-wrap`，中等宽度换行后文字上下重叠、点击区域被遮挡。
- 新版拆成三段：**顶栏用户区**（通知 / 收藏 / 发布 / 管理后台 / 头像角色 / 退出）、**主导航两行**（品牌 + 搜索一行，链接条独占一行）、**分类条**；高度全部 `height:auto / min-height`，链接点击区 ≥ 38px，重复菜单精简，0 未读不再显示红点。
- 1000px 与 1280px 宽度下用真实浏览器（Edge headless）截图复核：三行分区清晰、无重叠、无遮挡。

### 14.4 实测（JDK 21）

- `mvn clean package` → **45 个测试全通过**（新增 `ChatMessageTests.java` 8 个），49 MB jar。
- 真实启动后端到端脚本 **30 / 30 PASS**：买家聊天页渲染真实会话 ID → REST 发送 → 轮询取回 → 表单兜底发送 → 卖家看到消息 → 管理员查看全站会话 / 任意会话 / 后台监管页 → 管理员回复 → 越权拦截 → 导航分区 → 照片可访问。


## 十五、图片放大 / 订单卡片咨询 / 退款售后（v5，本次优化）

对应需求：① 点击商品图片可放大；② 购买支付成功的订单页可咨询客服、把已购订单发给卖家；③ 增加合理的二手闲置退款功能。

### 15.1 商品图片点击放大（原生灯箱）

- `static/js/shop.js` 新增 `initLightbox()`：点击任意带 `data-zoom` 的商品图弹出全屏遮罩，显示高清大图；支持左右箭头 / 键盘 ← → 切换同组图片、缩略图条、ESC / 点击空白处 / 关闭按钮退出、计数器。
- 打开灯箱时通过自定义事件 `lightbox:open` 暂停自动轮播，关闭后恢复；`.gallery-stage img` 只有 `.active` 接收点击，避免叠放的透明图片抢走事件。
- 商品详情大图、订单封面、卖家图片管理、订单 / 商品 / 收藏 / 购物车列表图全部接入；列表卡片右上角新增 🔍 放大镜按钮，不破坏「点击卡片进详情页」的淘宝式跳转。

### 15.2 订单详情页带订单咨询卖家

- `tb_chat_message` 增加 `msg_type`（TEXT / ORDER）与 `order_id`，客服消息支持「订单卡片」类型。
- 订单详情页新增「📦 带订单咨询卖家」→ `/orders/consult/{id}`：校验订单参与人 → 复用该商品的买卖家会话 → 把订单号、宝贝、金额、状态、下单时间做成卡片发给对方；买家、卖家、管理员都能看到。
- 聊天页顶部显示「已关联订单」，可一键「再次附上订单」（`POST /api/chat/{sid}/send-order/{orderId}`）；卡片内可直达订单详情。

### 15.3 合理的二手闲置退款（新增第 12 张表 `tb_refund_apply`）

| 规则 | 说明 |
| --- | --- |
| 适用范围 | 仅「已支付待确认」「已完成」订单；二手闲置当面验货，**不支持七天无理由** |
| 申请窗口 | 交易完成（或支付）后 `app.refund.apply-window-days`（默认 15）天内 |
| 可选理由 | 描述不符 / 质量问题·功能故障 / 未收到货·卖家未交付 / 买卖双方协商一致 |
| 卖家处理 | `app.refund.seller-handle-hours`（默认 48）小时内同意或拒绝；超时由定时任务自动同意退款 |
| 争议处理 | 卖家拒绝后买家可申请平台介入，管理员在「后台 → 退款仲裁」裁定同意或驳回 |
| 退款成功 | 订单状态置为 5「已退款」、恢复库存并重新在售、站内信通知买卖双方（模拟支付，不涉及真实资金） |

状态机：`0 待卖家处理 → 1 退款成功 / 2 卖家拒绝 → 3 平台介入中 → 1 退款成功 / 4 平台驳回`，买家可把 0 撤销为 5。
新增页面：`/refunds`（退款中心）、`/refunds/apply/{orderId}`（申请）、`/refunds/detail/{id}`（进度与处理）、`/admin/refunds`（后台仲裁）；订单中心与订单详情均有入口。
所有读写在 Service 层校验买家 / 卖家 / 管理员归属，杜绝改 ID 查看他人申请。

### 15.4 新增文件与验证（JDK 21）

- 新增 `RefundApply.java`、`RefundApplyMapper.java`、`RefundService.java`、`RefundServiceImpl.java`、`RefundController.java`、`RefundAndOrderCardTests.java` 与 4 个 Thymeleaf 页面；H2 / MySQL 脚本同步新增 `tb_refund_apply` 与 5 条覆盖各状态的演示申请。
- `mvn clean package` → **45 个测试全通过**（原 27 + v5 新增 9），BUILD SUCCESS，49 MB jar。
- 真实启动端到端 **35 / 35 PASS**：灯箱资源与页面标记、订单卡片发送与重发、退款申请 → 卖家同意 → 订单已退款、管理员仲裁、越权拦截、照片资源。
- Edge 无头浏览器截图复核：灯箱放大（4 张缩略图）、订单详情服务区块、退款中心表格均无重叠错位。


## 十六、账号角色字幕三态（v6 修复）

- 顶栏账号字幕统一按 `tb_user.role` 直接渲染：`USER` → **普通用户**（中性灰），`SELLER` → **认证卖家**（橙色），`ADMIN` → 保持原有「超级管理员」昵称、不重复叠加徽章，与后台 `roleBadge` 片段文案完全一致。
- **修复的问题**：旧模板写成 `${isAdmin} ? '管理员' : (isSeller ? '卖家' : '买家')`，属于「表达式外部嵌套三元」，嵌套的 `isSeller` 被 Thymeleaf 当作字面量恒为真，于是 `role=USER` 的「张同学」被错标成「卖家」。数据库种子数据、注册默认角色（`UserServiceImpl#register` 设为 `USER`）与 Spring Security 权限配置均无误，问题只出在展示层。
- 现改为 `th:switch="${currentUser.role}"`，不再依赖 `isAdmin / isSeller` 推断；新增 `RoleBadgeTests.java`（4 个用例）回归普通用户、认证卖家、超级管理员、后台用户列表四处渲染。
- `mvn clean package` → **45 个测试全通过**。


## 十七、订单待办通知与淘宝式状态分组（v7）

- 需求：未支付订单要像「客服消息」右上角那样有红点数字提醒，其他通知也要齐全。
- **顶栏红点**：`GlobalModelAdvice` 实时统计 `pendingPayCount`（买家待支付）、`sellerPendingCount`（卖家已支付待确认），「我的订单」复用 `.badge-dot` 显示待支付数量；「通知」（未读站内信）与「客服消息」（未读私信）红点保持原样。
- **关键设计**：角标读的是订单状态，不是站内信的 `is_read`。用户一键「全部标记已读」后，只要订单仍未支付，红点、订单中心提醒条、通知中心常驻提醒都继续存在——和淘宝「待付款」待办一致。
- **订单中心**：新增带实时数量的状态分组 Tab（全部 / 待支付 / 待确认 / 已完成 / 已退款），以及买家「⏰ 待支付」、卖家「📦 待确认交付」醒目提醒条，点击直达筛选结果。
- **站内通知**：下单事件 `order.created` 给买家的通知标题由「下单成功」改为明确的「订单待支付」（含金额与 30 分钟时限）；支付、确认交易、取消、超时取消、退款、审核、留言、客服消息、平台日统计等原有通知链路全部保留。通知中心 `user/notices.html` 增加常驻待支付提醒，并把 `ORDER / AUDIT / MESSAGE / SYSTEM` 类型标签改为中文。
- 后端新增 `TradeOrderService#countByStatus` / `countGroupByStatus`（按买家或卖家身份统计，避免多次查库）；新增 `OrderNoticeTests.java` 5 个回归用例。
- `mvn clean package` → **45 个测试全通过**。
