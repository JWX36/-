#!/usr/bin/env bash
# ============================================================
# 校园二手闲置交易平台 · Linux 生产环境启动脚本
# 用法：bash start.sh start|stop|restart|status
# 日志按天切割由 application-prod.yml 的 logback rollingpolicy 完成
# ============================================================
set -e

APP_NAME="campus-market"
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
JAR_FILE="$APP_DIR/target/demo-0.0.1-SNAPSHOT.jar"
LOG_DIR="/var/log/${APP_NAME}"
PID_FILE="$APP_DIR/app.pid"
JAVA_OPTS="-Xms512m -Xmx1024m -Dfile.encoding=UTF-8 -Duser.timezone=Asia/Shanghai"
PROFILE="prod"

mkdir -p "$LOG_DIR"

start() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        echo "$APP_NAME 已在运行，PID=$(cat "$PID_FILE")"
        return
    fi
    if [ ! -f "$JAR_FILE" ]; then
        echo "未找到 $JAR_FILE，请先执行 mvn -DskipTests package"
        exit 1
    fi
    nohup java $JAVA_OPTS -jar "$JAR_FILE" \
        --spring.profiles.active="$PROFILE" \
        --server.port=8080 \
        > "$LOG_DIR/stdout.log" 2>&1 &
    echo $! > "$PID_FILE"
    echo "$APP_NAME 已启动，PID=$(cat "$PID_FILE")，日志目录：$LOG_DIR"
}

stop() {
    if [ -f "$PID_FILE" ]; then
        PID="$(cat "$PID_FILE")"
        kill "$PID" 2>/dev/null || true
        rm -f "$PID_FILE"
        echo "$APP_NAME 已停止"
    else
        echo "未找到 PID 文件，进程可能未运行"
    fi
}

status() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        echo "$APP_NAME 运行中，PID=$(cat "$PID_FILE")"
    else
        echo "$APP_NAME 未运行"
    fi
}

case "$1" in
    start)   start ;;
    stop)    stop ;;
    restart) stop; sleep 2; start ;;
    status)  status ;;
    *) echo "用法：bash start.sh start|stop|restart|status"; exit 1 ;;
esac
