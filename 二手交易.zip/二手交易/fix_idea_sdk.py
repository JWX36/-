"""Fix IntelliJ IDEA SDK configuration for this project.

Run it AFTER closing IntelliJ IDEA, then reopen the project.
It is idempotent: running it any number of times is safe.

It does two things:
1. Registers three valid JDKs in IDEA's global jdk.table.xml
   (ms-21 / 21 -> JDK 21, 17 -> JDK 17).
2. Points this project's .idea/misc.xml at JDK 21 while keeping
   language level 17 (pom.xml java.version=17, required by Spring Boot 2.7).
"""
import glob
import io
import os
import re
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
USER_HOME = os.path.expanduser("~")
JDK_BASE = os.path.join(USER_HOME, ".jdks")
JDK_TABLE = os.path.join(
    USER_HOME, "AppData", "Roaming", "JetBrains", "IntelliJIdea2026.1",
    "options", "jdk.table.xml")
MISC = os.path.join(ROOT, ".idea", "misc.xml")

ENTRIES = [
    ("ms-21", "$USER_HOME$/.jdks/ms-21.0.13.0.2", "21.0.0", "ms-21.0.13.0.2"),
    ("21", "$USER_HOME$/.jdks/jdk-21", "21.0.0", "jdk-21"),
    ("17", "$USER_HOME$/.jdks/jdk-17", "17.0.0", "jdk-17"),
]


def jdk_entry(name, home, version, folder):
    real = os.path.join(JDK_BASE, folder)
    java_exe = os.path.join(real, "bin", "java.exe")
    if not os.path.isfile(java_exe):
        return "", 0
    mods = sorted(os.path.basename(f)[:-5]
                  for f in glob.glob(os.path.join(real, "jmods", "*.jmod")))
    out = io.StringIO()
    w = out.write
    w('    <jdk version="2">\n')
    w('      <name value="%s" />\n' % name)
    w('      <type value="JavaSDK" />\n')
    w('      <version value="java version &quot;%s&quot;" />\n' % version)
    w('      <homePath value="%s" />\n' % home)
    w('      <roots>\n        <annotationsPath>\n          <root type="composite">\n')
    w('            <root url="jar://$APPLICATION_HOME_DIR$/plugins/java/lib/resources/jdkAnnotations.jar!/" type="simple" />\n')
    w('          </root>\n        </annotationsPath>\n        <classPath>\n          <root type="composite">\n')
    for m in mods:
        w('            <root url="jrt://%s!/%s" type="simple" />\n' % (home, m))
    w('          </root>\n        </classPath>\n')
    w('        <javadocPath>\n          <root type="composite" />\n        </javadocPath>\n')
    w('        <sourcePath>\n          <root type="composite">\n')
    w('            <root url="jar://%s/lib/src.zip!/" type="simple" />\n' % home)
    w('          </root>\n        </sourcePath>\n      </roots>\n    </jdk>\n')
    return out.getvalue(), len(mods)


def fix_jdk_table():
    if not os.path.isdir(os.path.dirname(JDK_TABLE)):
        print("[SKIP] IDEA options folder not found:", JDK_TABLE)
        return
    xml = ('<?xml version="1.0" encoding="UTF-8"?>\n<application>\n'
           '  <component name="ProjectJdkTable">\n')
    count = 0
    for name, home, version, folder in ENTRIES:
        body, n = jdk_entry(name, home, version, folder)
        if body:
            xml += body
            count += 1
            print("[OK] registered JDK %-8s -> %s (%d modules)" % (name, folder, n))
        else:
            print("[SKIP] JDK not installed:", folder)
    xml += '  </component>\n</application>\n'
    if count == 0:
        print("[FAIL] no valid JDK found, nothing changed")
        return
    with open(JDK_TABLE, "w", encoding="utf-8", newline="\n") as f:
        f.write(xml)
    print("[OK] wrote", JDK_TABLE)


def fix_misc():
    if not os.path.isfile(MISC):
        print("[SKIP] misc.xml not found:", MISC)
        return
    with open(MISC, "r", encoding="utf-8") as f:
        text = f.read()
    text, n1 = re.subn(r'project-jdk-name="[^"]+"',
                       'project-jdk-name="ms-21"', text)
    text, n2 = re.subn(r'languageLevel="[^"]+"',
                       'languageLevel="JDK_17"', text)
    with open(MISC, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    print("[OK] project SDK = ms-21 (JDK 21), language level = 17")


if __name__ == "__main__":
    print("=== Fix IDEA SDK (close IDEA before running) ===")
    fix_jdk_table()
    fix_misc()
    print("=== Done. Reopen the project in IntelliJ IDEA. ===")
    sys.exit(0)
